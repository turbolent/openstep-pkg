#import <driverkit/IOEthernet.h>
#import <driverkit/i386/directDevice.h>
#import <driverkit/kernelDriver.h>
#import <mach/machine/simple_lock.h>

#import "rtl8139_hw.h"

#define RTL8139_MAR_MAX 32

struct rtl8139_mar_entry {
    BOOL valid;
    enet_addr_t addr;
};

@interface RTL8139 : IOEthernet
{
    IOEISAPortAddress ioaddr;
    int irq;
    IORange portRange;

    enet_addr_t myAddress;
    IONetwork *network;
    id transmitQueue;

    unsigned char *rxBuffer;
    unsigned int rxBufferPhys;
    unsigned int rxOffset;

    unsigned char *txBufferBlock;
    unsigned int txBufferPhys[RTL8139_NUM_TX_DESC];
    BOOL txBusy[RTL8139_NUM_TX_DESC];
    unsigned int txCurrent;
    unsigned int txDirty;
    unsigned int txPending;
    unsigned long txFlag;
    simple_lock_data_t txLock;

    struct rtl8139_mar_entry marList[RTL8139_MAR_MAX];

    BOOL promMode;
    BOOL linkUp;
    int linkSpeedMbps;
    BOOL linkFullDuplex;
    BOOL autonegConfigured;
    unsigned int rxRestartCount;
    BOOL rxTimerFastMode;
    unsigned int rxTimerIdlePolls;
}

+ (BOOL)probe:(IODeviceDescription *)devDesc;

- initFromDeviceDescription:(IODeviceDescription *)devDesc;
- free;

- (IOReturn)enableAllInterrupts;
- (void)disableAllInterrupts;

- (BOOL)resetAndEnable:(BOOL)enable;
- (void)timeoutOccurred;
- (void)interruptOccurred;

- (void)transmit:(netbuf_t)pkt;

- (BOOL)enablePromiscuousMode;
- (void)disablePromiscuousMode;
- (BOOL)enableMulticastMode;
- (void)disableMulticastMode;
- (void)addMulticastAddress:(enet_addr_t *)address;
- (void)removeMulticastAddress:(enet_addr_t *)address;

@end
