
#define MACH_USER_API 1

#import <driverkit/generalFuncs.h>
#import <driverkit/IONetbufQueue.h>
#import <driverkit/kernelDriver.h>
#import <driverkit/i386/kernelDriver.h>
#import <driverkit/i386/ioPorts.h>
#import <driverkit/i386/IOPCIDeviceDescription.h>
#import <driverkit/i386/IOPCIDirectDevice.h>
#import <driverkit/i386/PCI.h>
#import <kernserv/i386/spl.h>

#import "RTL8139.h"

#define RTL8139_TX_LOCK(flags) do { flags = spl6(); simple_lock(&txLock); } while (0)
#define RTL8139_TX_UNLOCK(flags) do { simple_unlock(&txLock); splx(flags); } while (0)
#define RTL8139_TX_QUEUED 0
#define RTL8139_TX_SENT 1
#define RTL8139_TX_DROPPED 2

@interface RTL8139 (Private)
- (BOOL)_enablePCIBusMastering:(IODeviceDescription *)devDesc;
- (BOOL)_allocateDMABuffers;
- (void)_freeDMABuffers;
- (BOOL)_resetChip;
- (void)_stopChip;
- (void)_resetTransmitStateWithErrors:(BOOL)countErrors;
- (void)_restartAutoNegotiation;
- (void)_programReceiveConfig;
- (void)_programMulticastFilter;
- (void)_updateLinkState;
- (void)_serviceTransmitQueue;
- (void)_transmitPacketLocked:(netbuf_t)pkt
                       result:(int *)result;
- (void)_queueTransmitPacketLocked:(netbuf_t)pkt
                            result:(int *)result;
- (unsigned int)_handleReceive;
- (void)_restartReceiverAfterBadPacket;
- (BOOL)_tryResyncReceiveCursor;
- (void)_handleTransmit;
- (void)_recoverAfterError:(unsigned short)interruptStatus;
@end

static unsigned int rtl_crc32_le(const unsigned char *buf, unsigned int len);
extern void bcopy(const void *src, void *dst, unsigned int count);
extern void bzero(void *dst, unsigned int count);

static __inline__ int rtl_compare_addr(enet_addr_t *a1, enet_addr_t *a2)
{
    int i;

    for (i = 0; i < 6; i++) {
        if (a1->ether_addr_octet[i] != a2->ether_addr_octet[i]) {
            return 0;
        }
    }

    return 1;
}

static __inline__ unsigned long rtl_read_ring_header32(unsigned char *ring,
                                                       unsigned int offset)
{
    unsigned int start;

    start = offset & (RTL8139_RX_BUF_LEN - 1);
    return *((volatile unsigned long *)(ring + start));
}

static __inline__ unsigned short rtl_read_ring16(unsigned char *ring,
                                                 unsigned int offset)
{
    unsigned short value;
    unsigned int a;
    unsigned int b;

    a = offset & (RTL8139_RX_BUF_LEN - 1);
    b = a + 1;
    if (b >= RTL8139_RX_BUF_TOT_LEN) {
        b = 0;
    }

    value = ring[a];
    value |= ((unsigned short)ring[b]) << 8;
    return value;
}

static __inline__ void rtl_copy_from_ring(unsigned char *ring,
                                          unsigned int offset,
                                          unsigned char *dest,
                                          unsigned int count)
{
    unsigned int start;
    unsigned int firstPart;

    start = offset & (RTL8139_RX_BUF_LEN - 1);
    if ((start + count) <= RTL8139_RX_BUF_LEN) {
        bcopy(ring + start, dest, count);
        return;
    }

    firstPart = RTL8139_RX_BUF_LEN - start;
    bcopy(ring + start, dest, firstPart);
    bcopy(ring, dest + firstPart, count - firstPart);
}

static __inline__ int rtl_physical_address(void *virtualAddress,
                                           unsigned int *physicalAddress)
{
    return (IOPhysicalFromVirtual(IOVmTaskSelf(),
                                  (vm_address_t)virtualAddress,
                                  physicalAddress) == IO_R_SUCCESS);
}

static __inline__ int rtl_plausible_receive_header(unsigned char *ring,
                                                   unsigned int cursor,
                                                   unsigned short *length)
{
    unsigned short status;

    status = rtl_read_ring16(ring, cursor);
    *length = rtl_read_ring16(ring, cursor + 2);

    if (status == 0xffff || *length == 0 || *length >= 0xfff0) {
        return 0;
    }

    if ((status & RTL8139_RX_STATUS_OK) == 0) {
        return 0;
    }

    if (*length < 4 || *length > (RTL8139_MAX_FRAME_SIZE + 4)) {
        return 0;
    }

    if ((status & (RTL8139_RX_STATUS_BROADCAST |
                   RTL8139_RX_STATUS_PHYSICAL |
                   RTL8139_RX_STATUS_MULTICAST)) == 0) {
        return 0;
    }

    return 1;
}

typedef struct RTL8139PCIId {
    unsigned short vendorID;
    unsigned short deviceID;
} RTL8139PCIId;

static const RTL8139PCIId gRTL8139PCIIds[] = {
    {0x10ec, 0x8139},
    {0x10ec, 0x8138},
    {0x1113, 0x1211},
    {0x1500, 0x1360},
    {0x4033, 0x1360},
    {0x1186, 0x1300},
    {0x1186, 0x1340},
    {0x13d1, 0xab06},
    {0x1259, 0xa117},
    {0x1259, 0xa11e},
    {0x14ea, 0xab06},
    {0x14ea, 0xab07},
    {0x11db, 0x1234},
    {0x1432, 0x9130},
    {0x02ac, 0x1012},
    {0x018a, 0x0106},
    {0x126c, 0x1211},
    {0x1743, 0x8139},
    {0x021b, 0x8139},
    {0x16ec, 0xab06}
};

@implementation RTL8139

+ (BOOL)probe:(IODeviceDescription *)devDesc
{
    RTL8139 *driver;

    driver = [self alloc];
    if (driver == nil) {
        return NO;
    }

    return ([driver initFromDeviceDescription:devDesc] != nil);
}

- initFromDeviceDescription:(IODeviceDescription *)devDesc
{
    IOPCIDeviceDescription *deviceDescription;
    IOPCIConfigSpace configSpace;
    unsigned char *mac;
    BOOL supported;
    int i;

    deviceDescription = (IOPCIDeviceDescription *)devDesc;
    [self setName:"RTL8139"];

    bzero(&configSpace, sizeof(configSpace));
    if ([IODirectDevice getPCIConfigSpace:&configSpace
                    withDeviceDescription:devDesc] != IO_R_SUCCESS) {
        IOLog("%s: unable to read PCI configuration space\n", [self name]);
        return [self free];
    }

    supported = NO;
    for (i = 0; i < (sizeof(gRTL8139PCIIds) / sizeof(gRTL8139PCIIds[0])); i++) {
        if (gRTL8139PCIIds[i].vendorID == configSpace.VendorID &&
            gRTL8139PCIIds[i].deviceID == configSpace.DeviceID) {
            supported = YES;
            break;
        }
    }
    if (!supported) {
        return [self free];
    }

    ioaddr = ((IOEISAPortAddress)configSpace.BaseAddress[0]) & 0xfffffffc;
    irq = (int)configSpace.InterruptLine;
    portRange.start = ioaddr;
    portRange.size = 0x100;

    if ([deviceDescription setPortRangeList:&portRange num:1] != IO_R_SUCCESS) {
        IOLog("%s: unable to reserve port range 0x%x\n", [self name], portRange.start);
        return [self free];
    }

    if ([deviceDescription setInterruptList:&irq num:1] != IO_R_SUCCESS) {
        IOLog("%s: unable to reserve irq %d\n", [self name], irq);
        return [self free];
    }

    if (![self _enablePCIBusMastering:devDesc]) {
        return [self free];
    }

    if ([super initFromDeviceDescription:devDesc] == nil) {
        return nil;
    }

    if (![self _allocateDMABuffers]) {
        return [self free];
    }

    if (![self _resetChip]) {
        IOLog("%s: reset failed during initialization\n", [self name]);
        return [self free];
    }

    mac = (unsigned char *)&myAddress;
    for (i = 0; i < 6; i++) {
        mac[i] = inb(ioaddr + RTL8139_MAC0 + i);
    }

    promMode = NO;
    simple_lock_init(&txLock);
    txFlag = RTL8139_TX_FLAG;
    linkUp = NO;
    linkSpeedMbps = 0;
    linkFullDuplex = NO;
    autonegConfigured = NO;
    rxRestartCount = 0;
    rxTimerFastMode = NO;
    rxTimerIdlePolls = 0;
    for (i = 0; i < RTL8139_MAR_MAX; i++) {
        marList[i].valid = NO;
    }

    if (![self resetAndEnable:NO]) {
        return [self free];
    }

    transmitQueue = [[IONetbufQueue alloc] initWithMaxCount:32];
    if (transmitQueue == nil) {
        IOLog("%s: unable to allocate transmit queue\n", [self name]);
        return [self free];
    }

    network = [super attachToNetworkWithAddress:myAddress];
    if (network == nil) {
        IOLog("%s: unable to attach to network stack\n", [self name]);
        [transmitQueue free];
        transmitQueue = nil;
        return [self free];
    }

    IOLog("%s: driver revision %s\n", [self name], RTL8139_DRIVER_REVISION);

    return self;
}

- free
{
    [self disableAllInterrupts];
    [self _stopChip];

    if (transmitQueue != nil) {
        netbuf_t pkt;

        while ((pkt = [transmitQueue dequeue]) != NULL) {
            nb_free(pkt);
        }
        [transmitQueue free];
        transmitQueue = nil;
    }

    [self _freeDMABuffers];

    return [super free];
}

- (IOReturn)enableAllInterrupts
{
    unsigned short intrMask;

    intrMask = RTL8139_INTR_MASK_DEFAULT;
    if (linkSpeedMbps == 100) {
        outl(ioaddr + RTL8139_TIMER_INT,
             rxTimerFastMode ? RTL8139_TIMER_INT_125US : RTL8139_TIMER_INT_1MS);
        outl(ioaddr + RTL8139_TIMER, 0);
        intrMask = RTL8139_INTR_MASK_TIMER_POLL;
    } else {
        outl(ioaddr + RTL8139_TIMER_INT, 0);
        rxTimerFastMode = NO;
        rxTimerIdlePolls = 0;
    }
    outw(ioaddr + RTL8139_INTR_MASK, intrMask);
    return [super enableAllInterrupts];
}

- (void)disableAllInterrupts
{
    outw(ioaddr + RTL8139_INTR_MASK, 0x0000);
    outl(ioaddr + RTL8139_TIMER_INT, 0);
    [super disableAllInterrupts];
}

- (BOOL)resetAndEnable:(BOOL)enable
{
    unsigned short pendingStatus;
    int i;

    [self disableAllInterrupts];

    if (![self _resetChip]) {
        IOLog("%s: reset failed while enabling device\n", [self name]);
        [self setRunning:NO];
        return NO;
    }

    [self _resetTransmitStateWithErrors:NO];
    rxOffset = 0;
    rxRestartCount = 0;

    outl(ioaddr + RTL8139_RX_BUF, rxBufferPhys);
    outw(ioaddr + RTL8139_RX_BUF_PTR, 0);
    outl(ioaddr + RTL8139_RX_MISSED, 0);

    for (i = 0; i < RTL8139_NUM_TX_DESC; i++) {
        outl(ioaddr + RTL8139_TX_ADDR0 + (i * 4), txBufferPhys[i]);
    }

    if (enable) {
        if (!autonegConfigured) {
            [self _restartAutoNegotiation];
            autonegConfigured = YES;
        }
        outb(ioaddr + RTL8139_CHIP_CMD, RTL8139_CMD_RX_ENABLE | RTL8139_CMD_TX_ENABLE);
        outl(ioaddr + RTL8139_TX_CONFIG, (RTL8139_TX_DMA_BURST << 8) |
                                      (RTL8139_TX_RETRY << 4) |
                                      0x03000000);
        [self _programReceiveConfig];
        outw(ioaddr + RTL8139_MULTI_INTR,
             inw(ioaddr + RTL8139_MULTI_INTR) & RTL8139_MULTI_INTR_EARLY_RX_MASK);
        [self _programMulticastFilter];
        [self _updateLinkState];
        pendingStatus = inw(ioaddr + RTL8139_INTR_STATUS);
        if (pendingStatus & RTL8139_INTR_RX_UNDERRUN) {
            outw(ioaddr + RTL8139_INTR_STATUS, RTL8139_INTR_RX_UNDERRUN);
        }
        outw(ioaddr + RTL8139_INTR_STATUS, 0xffff);
        if ([self enableAllInterrupts] != IO_R_SUCCESS) {
            IOLog("%s: unable to enable interrupts\n", [self name]);
            [self setRunning:NO];
            return NO;
        }
        [self setRunning:YES];
        [self _serviceTransmitQueue];
    } else {
        outw(ioaddr + RTL8139_INTR_STATUS, 0xffff);
        outb(ioaddr + RTL8139_CHIP_CMD, 0x00);
        [self setRunning:NO];
    }

    return YES;
}

- (void)timeoutOccurred
{
    netbuf_t pkt;
    unsigned int pending;
    unsigned long flags;

    if ([self isRunning]) {
        IOLog("%s: transmit timeout, attempting recovery\n", [self name]);
        [self _handleTransmit];
        RTL8139_TX_LOCK(flags);
        pending = txPending;
        RTL8139_TX_UNLOCK(flags);
        if (pending != 0) {
            [self _recoverAfterError:RTL8139_INTR_TX_ERR];
        } else {
            [self _serviceTransmitQueue];
        }
    }

    if (![self isRunning]) {
        while ((pkt = [transmitQueue dequeue]) != NULL) {
            nb_free(pkt);
        }
    }
}

- (void)interruptOccurred
{
    unsigned short status;
    unsigned short ackStatus;
    unsigned short cscr;
    unsigned short fatalStatus;
    unsigned int rxDelta;
    int count;
    BOOL useRxTimerPoll;

    useRxTimerPoll = (linkSpeedMbps == 100);
    status = inw(ioaddr + RTL8139_INTR_STATUS);
    if ((status & RTL8139_INTR_HANDLED) == 0) {
        [self enableAllInterrupts];
        return;
    }

    if (status == 0xffff) {
        [self enableAllInterrupts];
        return;
    }

    if (![self isRunning]) {
        [self enableAllInterrupts];
        return;
    }

    outw(ioaddr + RTL8139_INTR_MASK, 0x0000);

    fatalStatus = 0;

    for (count = 0; count < RTL8139_INTR_MAX_SERVICE; count++) {
        status &= RTL8139_INTR_HANDLED;
        if (status == 0) {
            break;
        }

        if (useRxTimerPoll && (status & RTL8139_INTR_TIMER)) {
            outl(ioaddr + RTL8139_TIMER, 0);
        }

        ackStatus = status;
        if (status & (RTL8139_INTR_RX_OVERFLOW | RTL8139_INTR_RX_FIFO_OVER)) {
            ackStatus |= RTL8139_INTR_RX_OVERFLOW | RTL8139_INTR_RX_FIFO_OVER;
        }
        outw(ioaddr + RTL8139_INTR_STATUS, ackStatus);

        if ((status & (RTL8139_INTR_RX_OK | RTL8139_INTR_RX_ERR |
                       RTL8139_INTR_RX_OVERFLOW | RTL8139_INTR_RX_FIFO_OVER)) ||
            (useRxTimerPoll && (status & RTL8139_INTR_TIMER))) {
            if (status & (RTL8139_INTR_RX_ERR | RTL8139_INTR_RX_OVERFLOW |
                          RTL8139_INTR_RX_FIFO_OVER)) {
                [network incrementInputErrors];
            }
            rxDelta = [self _handleReceive];
            if (useRxTimerPoll && (status & RTL8139_INTR_TIMER)) {
                if (rxDelta != 0) {
                    rxTimerIdlePolls = 0;
                    if (!rxTimerFastMode) {
                        outl(ioaddr + RTL8139_TIMER_INT, RTL8139_TIMER_INT_125US);
                        outl(ioaddr + RTL8139_TIMER, 0);
                        rxTimerFastMode = YES;
                    }
                } else if (rxTimerFastMode) {
                    if (rxTimerIdlePolls < RTL8139_RX_TIMER_IDLE_POLLS) {
                        rxTimerIdlePolls++;
                    }
                    if (rxTimerIdlePolls >= RTL8139_RX_TIMER_IDLE_POLLS) {
                        outl(ioaddr + RTL8139_TIMER_INT, RTL8139_TIMER_INT_1MS);
                        outl(ioaddr + RTL8139_TIMER, 0);
                        rxTimerFastMode = NO;
                    }
                }
            }
        }

        if (status & (RTL8139_INTR_TX_OK | RTL8139_INTR_TX_ERR)) {
            if (status & RTL8139_INTR_TX_ERR) {
                IOLog("%s: transmit interrupt reported error status 0x%x\n",
                      [self name], status);
            }
            [self _handleTransmit];
            if (status & RTL8139_INTR_TX_ERR) {
                [network incrementOutputErrors];
            }
        }

        if (status & RTL8139_INTR_RX_UNDERRUN) {
            cscr = inw(ioaddr + RTL8139_CSCR);
            if (cscr & RTL8139_CSCR_LINK_CHANGE) {
                [self _updateLinkState];
            } else {
                [network incrementInputErrors];
            }
        }

        if ((status & RTL8139_INTR_PCS_TIMEOUT) && !useRxTimerPoll) {
            [network incrementInputErrors];
        }

        if (status & RTL8139_INTR_PCI_ERR) {
            IOLog("%s: PCI/system interrupt error status 0x%x\n", [self name], status);
            fatalStatus |= RTL8139_INTR_PCI_ERR;
        }

        if (fatalStatus) {
            break;
        }

        status = inw(ioaddr + RTL8139_INTR_STATUS);
        if (status == 0xffff || (status & RTL8139_INTR_HANDLED) == 0) {
            break;
        }
    }

    if (fatalStatus) {
        IOLog("%s: fatal interrupt bits set 0x%x from status 0x%x\n",
              [self name], fatalStatus, status);
        [self _recoverAfterError:fatalStatus];
    } else {
        [self _serviceTransmitQueue];
        [self enableAllInterrupts];
    }
}

- (void)transmit:(netbuf_t)pkt
{
    unsigned long flags;
    int txResult;

    if (pkt == NULL) {
        return;
    }

    RTL8139_TX_LOCK(flags);
    [self _transmitPacketLocked:pkt result:&txResult];
    RTL8139_TX_UNLOCK(flags);

    if (txResult == RTL8139_TX_SENT || txResult == RTL8139_TX_DROPPED) {
        nb_free(pkt);
    }
}

- (BOOL)enablePromiscuousMode
{
    promMode = YES;
    [self _programMulticastFilter];
    return YES;
}

- (void)disablePromiscuousMode
{
    promMode = NO;
    [self _programMulticastFilter];
}

- (BOOL)enableMulticastMode
{
    /*
     * DriverKit calls these mode hooks, but receive config intentionally keeps
     * multicast acceptance enabled. Specific multicast addresses still update
     * the MAR hash through add/removeMulticastAddress.
     */
    return YES;
}

- (void)disableMulticastMode
{
    /*
     * No hardware change: see enableMulticastMode.
     */
}

- (void)addMulticastAddress:(enet_addr_t *)address
{
    int i;

    for (i = 0; i < RTL8139_MAR_MAX; i++) {
        if (!marList[i].valid) {
            marList[i].valid = YES;
            bcopy(address, &marList[i].addr, sizeof(enet_addr_t));
            [self _programMulticastFilter];
            return;
        }
    }

    IOLog("%s: multicast address list full\n", [self name]);
}

- (void)removeMulticastAddress:(enet_addr_t *)address
{
    int i;

    for (i = 0; i < RTL8139_MAR_MAX; i++) {
        if (marList[i].valid && rtl_compare_addr(address, &marList[i].addr)) {
            marList[i].valid = NO;
            [self _programMulticastFilter];
            return;
        }
    }
}

@end

@implementation RTL8139 (Private)

- (void)_transmitPacketLocked:(netbuf_t)pkt result:(int *)result
{
    unsigned int slot;
    unsigned int pktLen;
    unsigned int sendLen;
    unsigned char *txSlot;
    BOOL startTimer;

    if (![self isRunning]) {
        if (transmitQueue == nil) {
            IOLog("%s: dropping transmit packet while stopped with no queue\n",
                  [self name]);
            [network incrementOutputErrors];
            *result = RTL8139_TX_DROPPED;
            return;
        }
        [self _queueTransmitPacketLocked:pkt
                                  result:result];
        return;
    }

    if (txPending >= RTL8139_NUM_TX_DESC) {
        if (transmitQueue == nil) {
            IOLog("%s: dropping transmit packet with descriptors full and no queue\n",
                  [self name]);
            [network incrementOutputErrors];
            *result = RTL8139_TX_DROPPED;
            return;
        }
        [self _queueTransmitPacketLocked:pkt
                                  result:result];
        return;
    }

    slot = txCurrent % RTL8139_NUM_TX_DESC;
    if (txBusy[slot]) {
        if (transmitQueue == nil) {
            IOLog("%s: dropping transmit packet with busy slot %u and no queue\n",
                  [self name], slot);
            [network incrementOutputErrors];
            *result = RTL8139_TX_DROPPED;
            return;
        }
        [self _queueTransmitPacketLocked:pkt
                                  result:result];
        return;
    }

    pktLen = nb_size(pkt);
    sendLen = (pktLen < RTL8139_MIN_FRAME_SIZE) ? RTL8139_MIN_FRAME_SIZE : pktLen;
    if (sendLen > RTL8139_TX_BUF_SIZE) {
        IOLog("%s: dropping oversized transmit packet (%u bytes)\n",
              [self name], sendLen);
        [network incrementOutputErrors];
        *result = RTL8139_TX_DROPPED;
        return;
    }

    txSlot = txBufferBlock + (slot * RTL8139_TX_BUF_SIZE);
    bcopy(nb_map(pkt), txSlot, pktLen);
    if (sendLen > pktLen) {
        bzero(txSlot + pktLen, sendLen - pktLen);
    }

    startTimer = (txPending == 0);
    txBusy[slot] = YES;
    txCurrent++;
    txPending++;

    outl(ioaddr + RTL8139_TX_ADDR0 + (slot * 4), txBufferPhys[slot]);
    outl(ioaddr + RTL8139_TX_STATUS0 + (slot * 4), txFlag | sendLen);

    if (startTimer) {
        [self setRelativeTimeout:RTL8139_TX_TIMEOUT_MS];
    }

    *result = RTL8139_TX_SENT;
}

- (void)_queueTransmitPacketLocked:(netbuf_t)pkt
                             result:(int *)result
{
    if ([transmitQueue count] >= [transmitQueue maxCount]) {
        [network incrementOutputErrors];
    }
    [transmitQueue enqueue:pkt];
    *result = RTL8139_TX_QUEUED;
}

- (BOOL)_enablePCIBusMastering:(IODeviceDescription *)devDesc
{
    unsigned long command;
    unsigned long cacheLatency;
    IOReturn irtn;

    irtn = [IODirectDevice getPCIConfigData:&command
                                 atRegister:RTL8139_PCI_COMMAND
                      withDeviceDescription:devDesc];
    if (irtn != IO_R_SUCCESS) {
        IOLog("%s: unable to read PCI command register\n", [self name]);
        return NO;
    }

    command |= RTL8139_PCI_COMMAND_IO |
               RTL8139_PCI_COMMAND_MEMORY |
               RTL8139_PCI_COMMAND_MASTER |
               RTL8139_PCI_COMMAND_MWI;
    irtn = [IODirectDevice setPCIConfigData:command
                                 atRegister:RTL8139_PCI_COMMAND
                      withDeviceDescription:devDesc];
    if (irtn != IO_R_SUCCESS) {
        IOLog("%s: unable to enable PCI bus mastering\n", [self name]);
        return NO;
    }

    irtn = [IODirectDevice getPCIConfigData:&cacheLatency
                                 atRegister:RTL8139_PCI_CACHE_LATENCY
                      withDeviceDescription:devDesc];
    if (irtn == IO_R_SUCCESS) {
        cacheLatency &= ~(RTL8139_PCI_CACHE_LINE_MASK | RTL8139_PCI_LATENCY_MASK);
        cacheLatency |= RTL8139_PCI_CACHE_LINE_16 |
                        (RTL8139_PCI_LATENCY_248 << RTL8139_PCI_LATENCY_SHIFT);
        irtn = [IODirectDevice setPCIConfigData:cacheLatency
                                     atRegister:RTL8139_PCI_CACHE_LATENCY
                          withDeviceDescription:devDesc];
        if (irtn != IO_R_SUCCESS) {
            IOLog("%s: unable to set PCI cache/latency register\n", [self name]);
        }
    }

    return YES;
}

- (BOOL)_allocateDMABuffers
{
    int i;

    if (rxBuffer != NULL && txBufferBlock != NULL) {
        return YES;
    }

    if (rxBuffer == NULL) {
        rxBuffer = (unsigned char *)IOMallocLow(RTL8139_RX_BUF_TOT_LEN);
        if (rxBuffer == NULL) {
            IOLog("%s: unable to allocate RX ring\n", [self name]);
            return NO;
        }
        bzero(rxBuffer, RTL8139_RX_BUF_TOT_LEN);
    }

    if (rxBufferPhys == 0 && !rtl_physical_address(rxBuffer, &rxBufferPhys)) {
        IOLog("%s: unable to translate RX ring physical address\n", [self name]);
        return NO;
    }

    if (txBufferBlock == NULL) {
        txBufferBlock = (unsigned char *)IOMallocLow(RTL8139_TX_BUF_TOT_LEN);
        if (txBufferBlock == NULL) {
            IOLog("%s: unable to allocate TX buffer block (%u bytes)\n",
                  [self name], RTL8139_TX_BUF_TOT_LEN);
            return NO;
        }
        bzero(txBufferBlock, RTL8139_TX_BUF_TOT_LEN);
    }

    for (i = 0; i < RTL8139_NUM_TX_DESC; i++) {
        if (!rtl_physical_address(txBufferBlock + (i * RTL8139_TX_BUF_SIZE),
                                  &txBufferPhys[i])) {
            IOLog("%s: unable to translate TX buffer %d physical address\n",
                  [self name], i);
            return NO;
        }
        txBusy[i] = NO;
    }

    return YES;
}

- (void)_freeDMABuffers
{
    int i;

    if (rxBuffer != NULL) {
        IOFreeLow(rxBuffer, RTL8139_RX_BUF_TOT_LEN);
        rxBuffer = NULL;
        rxBufferPhys = 0;
    }

    if (txBufferBlock != NULL) {
        IOFreeLow(txBufferBlock, RTL8139_TX_BUF_TOT_LEN);
        txBufferBlock = NULL;
    }

    for (i = 0; i < RTL8139_NUM_TX_DESC; i++) {
        txBufferPhys[i] = 0;
        txBusy[i] = NO;
    }
}

- (BOOL)_resetChip
{
    ns_time_t startTime;
    ns_time_t currentTime;

    outb(ioaddr + RTL8139_HLTCLK, RTL8139_HLTCLK_RUN);
    outb(ioaddr + RTL8139_CHIP_CMD, RTL8139_CMD_RESET);
    IOGetTimestamp(&startTime);
    while (inb(ioaddr + RTL8139_CHIP_CMD) & RTL8139_CMD_RESET) {
        IOGetTimestamp(&currentTime);
        if ((currentTime - startTime) > RTL8139_RESET_TIMEOUT_NS) {
            IOLog("%s: chip reset timed out\n", [self name]);
            return NO;
        }
    }

    outw(ioaddr + RTL8139_INTR_MASK, 0x0000);
    outw(ioaddr + RTL8139_INTR_STATUS, 0xffff);
    return YES;
}

- (void)_stopChip
{
    outw(ioaddr + RTL8139_INTR_MASK, 0x0000);
    outl(ioaddr + RTL8139_TIMER_INT, 0);
    outb(ioaddr + RTL8139_CHIP_CMD, 0x00);
    outw(ioaddr + RTL8139_INTR_STATUS, 0xffff);
}

- (void)_resetTransmitStateWithErrors:(BOOL)countErrors
{
    unsigned int i;
    unsigned int lostPackets;
    unsigned long flags;

    RTL8139_TX_LOCK(flags);
    lostPackets = 0;
    for (i = 0; i < RTL8139_NUM_TX_DESC; i++) {
        if (txBusy[i]) {
            lostPackets++;
        }
        txBusy[i] = NO;
    }

    txCurrent = 0;
    txDirty = 0;
    txPending = 0;
    txFlag = RTL8139_TX_FLAG;
    RTL8139_TX_UNLOCK(flags);

    [self clearTimeout];

    if (countErrors && lostPackets != 0) {
        IOLog("%s: transmit reset discarded %u pending packet(s)\n",
              [self name], lostPackets);
        [network incrementOutputErrorsBy:lostPackets];
    }
}

- (void)_restartAutoNegotiation
{
    unsigned int elapsed;
    unsigned short bmsr;
    unsigned short oldAdvertise;
    unsigned short advertise;

    oldAdvertise = inw(ioaddr + RTL8139_NWAY_ADVERT);
    advertise = RTL8139_NWAY_ADVERT_ALL | (oldAdvertise & RTL8139_NWAY_PAUSE);

    outw(ioaddr + RTL8139_NWAY_ADVERT, advertise);
    outb(ioaddr + RTL8139_CFG9346, RTL8139_CFG9346_UNLOCK);
    outw(ioaddr + RTL8139_TX_BASIC_MODE_CTRL,
         RTL8139_BMCR_AUTONEG_ENABLE | RTL8139_BMCR_RESTART_AUTONEG);
    outb(ioaddr + RTL8139_CFG9346, RTL8139_CFG9346_LOCK);

    bmsr = 0;
    for (elapsed = 0; elapsed < RTL8139_AUTONEG_TIMEOUT_MS; elapsed += 20) {
        bmsr = inw(ioaddr + RTL8139_BASIC_MODE_STATUS);
        bmsr = inw(ioaddr + RTL8139_BASIC_MODE_STATUS);
        if (bmsr & RTL8139_BMSR_AUTONEG_DONE) {
            return;
        }
        IOSleep(20);
    }

    IOLog("%s: autonegotiation did not complete within %u ms (bmsr 0x%x)\n",
          [self name], RTL8139_AUTONEG_TIMEOUT_MS, bmsr);
}

- (void)_programReceiveConfig
{
    unsigned long rxConfig;

    rxConfig = (RTL8139_RX_FIFO_THRESH << 13) |
               (RTL8139_RX_BUF_IDX << 11) |
               (RTL8139_RX_DMA_BURST << 8);

    if (promMode) {
        rxConfig |= RTL8139_ACCEPT_ERR |
                    RTL8139_ACCEPT_RUNT |
                    RTL8139_ACCEPT_BROADCAST |
                    RTL8139_ACCEPT_MULTICAST |
                    RTL8139_ACCEPT_MY_PHYS |
                    RTL8139_ACCEPT_ALL_PHYS;
    } else {
        rxConfig |= RTL8139_ACCEPT_BROADCAST |
                    RTL8139_ACCEPT_MULTICAST |
                    RTL8139_ACCEPT_MY_PHYS;
    }

    outl(ioaddr + RTL8139_RX_CONFIG, rxConfig);
}

- (void)_programMulticastFilter
{
    unsigned char hash[8];
    unsigned int crc;
    unsigned int bit;
    int i;

    for (i = 0; i < 8; i++) {
        hash[i] = promMode ? 0xff : 0x00;
    }

    if (!promMode) {
        for (i = 0; i < RTL8139_MAR_MAX; i++) {
            if (!marList[i].valid) {
                continue;
            }
            crc = rtl_crc32_le((unsigned char *)&marList[i].addr, 6);
            bit = (crc >> 26) & 0x3f;
            hash[bit >> 3] |= (1 << (bit & 7));
        }
    }

    for (i = 0; i < 8; i++) {
        outb(ioaddr + RTL8139_MAR0 + i, hash[i]);
    }

    [self _programReceiveConfig];
}

- (void)_updateLinkState
{
    unsigned char media;
    unsigned short bmcr;
    unsigned short bmsr;
    unsigned short anar;
    unsigned short lpar;
    unsigned short negotiated;
    BOOL newLinkUp;
    int newSpeedMbps;
    BOOL newFullDuplex;
    BOOL autonegComplete;
    const char *speedText;
    const char *duplexText;
    const char *autonegText;

    media = inb(ioaddr + RTL8139_MEDIA_STATUS);
    bmcr = inw(ioaddr + RTL8139_TX_BASIC_MODE_CTRL);
    bmsr = inw(ioaddr + RTL8139_BASIC_MODE_STATUS);
    bmsr = inw(ioaddr + RTL8139_BASIC_MODE_STATUS);
    anar = inw(ioaddr + RTL8139_NWAY_ADVERT);
    lpar = inw(ioaddr + RTL8139_NWAY_LPAR);

    newLinkUp = ((media & RTL8139_MSR_LINK_FAIL) == 0);

    if (!newLinkUp) {
        if (linkUp) {
            IOLog("%s: link down\n", [self name]);
        }
        linkUp = NO;
        linkSpeedMbps = 0;
        linkFullDuplex = NO;
        return;
    }

    autonegComplete = ((bmsr & RTL8139_BMSR_AUTONEG_DONE) != 0);
    newSpeedMbps = (media & RTL8139_MSR_SPEED_10) ? 10 : 100;
    newFullDuplex = ((bmcr & RTL8139_BMCR_FULL_DUPLEX) != 0);

    if ((bmcr & RTL8139_BMCR_AUTONEG_ENABLE) && autonegComplete) {
        negotiated = anar & lpar;

        if (negotiated & RTL8139_NWAY_100BASE_TX_FD) {
            newSpeedMbps = 100;
            newFullDuplex = YES;
        } else if (negotiated & RTL8139_NWAY_100BASE_TX_HD) {
            newSpeedMbps = 100;
            newFullDuplex = NO;
        } else if (negotiated & RTL8139_NWAY_10BASE_T_FD) {
            newSpeedMbps = 10;
            newFullDuplex = YES;
        } else if (negotiated & RTL8139_NWAY_10BASE_T_HD) {
            newSpeedMbps = 10;
            newFullDuplex = NO;
        } else {
            newFullDuplex = NO;
        }
    }

    speedText = (newSpeedMbps == 10) ? "10baseT" : "100baseTX";
    duplexText = newFullDuplex ? "full-duplex" : "half-duplex";
    autonegText = autonegComplete ? "autoneg complete" : "autoneg incomplete";

    if (!linkUp ||
        newSpeedMbps != linkSpeedMbps ||
        newFullDuplex != linkFullDuplex) {
        IOLog("%s: link up %s %s, %s\n",
              [self name],
              speedText,
              duplexText,
              autonegText);
    }

    linkUp = YES;
    linkSpeedMbps = newSpeedMbps;
    linkFullDuplex = newFullDuplex;
}

- (void)_serviceTransmitQueue
{
    netbuf_t pkt;
    unsigned long flags;
    int txResult;

    while (1) {
        RTL8139_TX_LOCK(flags);
        if (transmitQueue == nil ||
            txPending >= RTL8139_NUM_TX_DESC ||
            ![self isRunning]) {
            RTL8139_TX_UNLOCK(flags);
            break;
        }
        pkt = [transmitQueue dequeue];
        if (pkt == NULL) {
            RTL8139_TX_UNLOCK(flags);
            break;
        }
        [self _transmitPacketLocked:pkt result:&txResult];
        RTL8139_TX_UNLOCK(flags);

        if (txResult == RTL8139_TX_SENT || txResult == RTL8139_TX_DROPPED) {
            nb_free(pkt);
        } else {
            break;
        }
    }
}

- (unsigned int)_handleReceive
{
    unsigned int serviceCount;
    unsigned int serviceBytes;

    serviceCount = 0;
    serviceBytes = 0;

    while (!(inb(ioaddr + RTL8139_CHIP_CMD) & RTL8139_CMD_RX_EMPTY) &&
           serviceCount < RTL8139_RX_MAX_SERVICE &&
           serviceBytes < RTL8139_RX_MAX_SERVICE_BYTES) {
        unsigned int ringOffset;
        unsigned long receiveHeader;
        unsigned short packetStatus;
        unsigned short packetLength;
        unsigned int frameLength;
        unsigned int nextOffset;
        netbuf_t pkt;

        ringOffset = rxOffset & (RTL8139_RX_BUF_LEN - 1);
        receiveHeader = rtl_read_ring_header32(rxBuffer, ringOffset);
        packetStatus = (unsigned short)(receiveHeader & 0xffff);
        packetLength = (unsigned short)((receiveHeader >> 16) & 0xffff);

        if (packetStatus == 0xffff || packetLength == 0 ||
            packetLength >= 0xfff0) {
            break;
        }

        serviceBytes += packetLength;
        if (serviceBytes > RTL8139_RX_MAX_SERVICE_BYTES) {
            break;
        }

        if ((packetStatus & RTL8139_RX_STATUS_OK) == 0 ||
            packetLength < 4 ||
            packetLength > (RTL8139_MAX_FRAME_SIZE + 4)) {
            if ([self _tryResyncReceiveCursor]) {
                continue;
            }
            IOLog("%s: dropping bad receive packet status 0x%x length %u offset %u capr 0x%x cbr 0x%x\n",
                  [self name],
                  packetStatus,
                  packetLength,
                  rxOffset,
                  inw(ioaddr + RTL8139_RX_BUF_PTR),
                  inw(ioaddr + RTL8139_RX_BUF_ADDR));
            [network incrementInputErrors];
            [self _restartReceiverAfterBadPacket];
            return serviceCount;
        }

        rxRestartCount = 0;
        frameLength = packetLength - 4;
        pkt = nb_alloc(frameLength);
        if (pkt == NULL) {
            IOLog("%s: unable to allocate netbuf for receive frame (%u bytes)\n",
                  [self name], frameLength);
            [network incrementInputErrors];
        } else {
            rtl_copy_from_ring(rxBuffer, ringOffset + 4,
                               (unsigned char *)nb_map(pkt), frameLength);
            [network handleInputPacket:pkt extra:0];
        }

        nextOffset = (rxOffset + packetLength + 4 + 3) & ~3;
        rxOffset = nextOffset;
        outw(ioaddr + RTL8139_RX_BUF_PTR,
             (rxOffset - RTL8139_RX_BUF_PAD) & 0xffff);

        serviceCount++;
    }

    return serviceCount;
}

- (void)_restartReceiverAfterBadPacket
{
    unsigned char command;

    rxRestartCount++;
    if (rxRestartCount >= RTL8139_RX_RESTART_FULL_RESET_LIMIT) {
        IOLog("%s: receiver restart limit reached; full reset\n", [self name]);
        rxRestartCount = 0;
        [self _recoverAfterError:RTL8139_INTR_RX_OVERFLOW];
        return;
    }

    IOLog("%s: restarting receiver after bad packet\n", [self name]);

    command = inb(ioaddr + RTL8139_CHIP_CMD);
    rxOffset = 0;

    outb(ioaddr + RTL8139_CHIP_CMD, command & ~RTL8139_CMD_RX_ENABLE);
    IODelay(100);
    outl(ioaddr + RTL8139_RX_BUF, rxBufferPhys);
    outw(ioaddr + RTL8139_RX_BUF_PTR, 0);
    outl(ioaddr + RTL8139_RX_MISSED, 0);
    outb(ioaddr + RTL8139_CHIP_CMD, command | RTL8139_CMD_RX_ENABLE);
    [self _programReceiveConfig];
}

- (BOOL)_tryResyncReceiveCursor
{
    int delta;
    unsigned int candidate;
    unsigned int candidateNext;
    unsigned int bestCursor;
    int validCount;
    unsigned short candidateLength;

    bestCursor = 0;
    validCount = 0;

    for (delta = 16; delta >= 4; delta -= 4) {
        if (rxOffset < (unsigned int)delta) {
            continue;
        }

        candidate = rxOffset - (unsigned int)delta;
        if (!rtl_plausible_receive_header(rxBuffer,
                                          candidate,
                                          &candidateLength)) {
            continue;
        }

        candidateNext = (candidate + candidateLength + 4 + 3) & ~3;
        if (candidateNext <= rxOffset) {
            continue;
        }

        validCount++;
        bestCursor = candidate;
    }

    if (validCount == 1) {
        rxOffset = bestCursor;
        rxRestartCount = 0;
        return YES;
    }

    return NO;
}

- (void)_handleTransmit
{
    unsigned long flags;
    BOOL clearTimer;

    clearTimer = NO;
    RTL8139_TX_LOCK(flags);
    while (txPending != 0) {
        unsigned int slot;
        unsigned long txStatus;

        slot = txDirty % RTL8139_NUM_TX_DESC;
        if (!txBusy[slot]) {
            txDirty++;
            txPending--;
            continue;
        }

        txStatus = inl(ioaddr + RTL8139_TX_STATUS0 + (slot * 4));
        if ((txStatus & (RTL8139_TX_STATUS_OK |
                         RTL8139_TX_STATUS_ABORT |
                         RTL8139_TX_STATUS_UNDERRUN)) == 0) {
            break;
        }

        if (txStatus & RTL8139_TX_STATUS_OK) {
            [network incrementOutputPackets];
        } else {
            IOLog("%s: transmit descriptor %u failed status 0x%lx\n",
                  [self name], slot, txStatus);
            [network incrementOutputErrors];
            if (txStatus & RTL8139_TX_STATUS_ABORT) {
                outl(ioaddr + RTL8139_TX_CONFIG, inl(ioaddr + RTL8139_TX_CONFIG) |
                                               RTL8139_TX_CONFIG_CLEAR_ABORT);
            }
            if ((txStatus & RTL8139_TX_STATUS_UNDERRUN) &&
                txFlag < RTL8139_TX_FLAG_MAX) {
                txFlag += RTL8139_TX_FLAG_INCREMENT;
                IOLog("%s: increasing transmit FIFO threshold to flag 0x%lx after underrun\n",
                      [self name], txFlag);
            }
            if (txStatus & RTL8139_TX_STATUS_OUT_WIN) {
                [network incrementCollisions];
            }
        }

        txBusy[slot] = NO;
        txDirty++;
        txPending--;
    }

    if (txPending == 0) {
        clearTimer = YES;
    }
    RTL8139_TX_UNLOCK(flags);

    if (clearTimer) {
        [self clearTimeout];
    }
}

- (void)_recoverAfterError:(unsigned short)interruptStatus
{
    interruptStatus &= RTL8139_INTR_FATAL;
    if (interruptStatus == 0) {
        return;
    }

    IOLog("%s: recovering from interrupt status 0x%x\n",
          [self name], interruptStatus);

    if (interruptStatus & (RTL8139_INTR_RX_ERR |
                           RTL8139_INTR_RX_OVERFLOW |
                           RTL8139_INTR_RX_FIFO_OVER)) {
        [network incrementInputErrors];
    }

    if (interruptStatus & (RTL8139_INTR_TX_ERR |
                           RTL8139_INTR_PCI_ERR)) {
        [network incrementOutputErrors];
    }

    [self _resetTransmitStateWithErrors:YES];
    if (![self resetAndEnable:YES]) {
        [self setRunning:NO];
    }
}

@end

static unsigned int rtl_crc32_le(const unsigned char *buf, unsigned int len)
{
    unsigned int crc;
    unsigned int i;
    unsigned int bit;
    unsigned char current;

    crc = 0xffffffff;
    for (i = 0; i < len; i++) {
        current = buf[i];
        for (bit = 0; bit < 8; bit++) {
            if ((crc ^ current) & 1) {
                crc = (crc >> 1) ^ 0xedb88320;
            } else {
                crc >>= 1;
            }
            current >>= 1;
        }
    }

    return crc;
}
