#ifndef NVME_TYPES_H
#define NVME_TYPES_H

#import <driverkit/scsiTypes.h>
#import <kernserv/queue.h>
#import <machkit/NXLock.h>
#import "NVMeRegs.h"
#import "NVMeSNTL.h"

typedef struct NVMePage {
    void *allocation;
    unsigned allocationLength;
    void *virtualAddress;
    unsigned physicalAddress;
} NVMePage;

typedef struct NVMeQueue {
    NVMePage submission;
    NVMePage completion;
    unsigned short queueId;
    unsigned short depth;
    unsigned short submissionHead;
    unsigned short submissionTail;
    unsigned short completionHead;
    unsigned char completionPhase;
} NVMeQueue;

typedef enum NVMeCommandOperation {
    NVME_COMMAND_EXECUTE,
    NVME_COMMAND_RESET,
    NVME_COMMAND_SHUTDOWN,
    NVME_COMMAND_ABORT_THREAD
} NVMeCommandOperation;

typedef struct NVMeCommandBuffer {
    queue_chain_t link;
    NVMeCommandOperation operation;
    NXConditionLock *completionLock;

    void *originalRequest;
    int requestIsSCSI3;
    unsigned long long target;
    unsigned long long lun;
    unsigned char cdb[16];
    unsigned cdbLength;
    int requestIsRead;
    int commandQueueDisabled;
    int timeoutSeconds;
    void *buffer;
    vm_task_t client;

    sc_status_t driverStatus;
    unsigned char scsiStatus;
    int bytesTransferred;
    esense_reply_t senseData;
    NVMeSNTLResult translation;

    unsigned short commandId;
    int prpPage;
    int active;
    int adminCommand;
    int barrier;
    int completed;
    ns_time_t startTime;
} NVMeCommandBuffer;

#define NVME_CMD_PENDING  0
#define NVME_CMD_COMPLETE 1

#endif
