#ifndef NVME_QUEUE_POLICY_H
#define NVME_QUEUE_POLICY_H

typedef struct NVMeQueuePolicyState {
    unsigned activeCommands;
    int recoveryBlocked;
    int barrierActive;
    int serializedActive;
    int olderCommandPending;
    int adminBusy;
} NVMeQueuePolicyState;

typedef struct NVMeQueuePolicyCommand {
    int barrier;
    int serialized;
    int usesAdminQueue;
} NVMeQueuePolicyCommand;

int NVMeQueueCommandMayStart(const NVMeQueuePolicyState *state,
                             const NVMeQueuePolicyCommand *command);

#endif
