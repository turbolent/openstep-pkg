#ifndef NVME_PRIVATE_H
#define NVME_PRIVATE_H

#import "NVMeSCSI.h"

#define NVME_INTX_POLL_GRACE_MS 10U
#define NVME_QUIESCE_FAILED      0
#define NVME_QUIESCE_STOPPED     1
#define NVME_QUIESCE_DMA_FENCED  2
#import "NVMePRP.h"
#import "NVMeRecovery.h"

@interface NVMeSCSI (CommandThreadPrivate)

- (IOReturn)executeCommandBuffer:(NVMeCommandBuffer *)command;
- (void)dispatchCommand:(NVMeCommandBuffer *)command;
- (void)startPendingCommands;
- (int)canStartCommand:(NVMeCommandBuffer *)command
          olderPending:(int)olderPending;
- (void)completeCommand:(NVMeCommandBuffer *)command;
- (void)completeCommand:(NVMeCommandBuffer *)command
             withStatus:(sc_status_t)status;
- (void)abortOutstanding:(sc_status_t)activeStatus
            pendingStatus:(sc_status_t)pendingStatus;
- (unsigned)abortTimedOutCommandsAt:(ns_time_t)now;
- (void)armWatchdog;
- (void)sendWatchdogMessage;
- (int)startPollingThread;
- (void)pollingLoop;

@end

@interface NVMeSCSI (Private)

- initializeFromDeviceDescription:deviceDescription;

- (int)allocatePage:(NVMePage *)page length:(unsigned)length;
- (void)freePage:(NVMePage *)page;
- (int)allocateControllerMemory;
- (void)freeControllerMemory;

- (unsigned)readRegister32:(unsigned)offset;
- (unsigned long long)readRegister64:(unsigned)offset;
- (void)writeRegister32:(unsigned)offset value:(unsigned)value;
- (void)writeRegister64:(unsigned)offset value:(unsigned long long)value;
- (void)ringSubmissionDoorbell:(NVMeQueue *)queue;
- (void)ringCompletionDoorbell:(NVMeQueue *)queue;
- (int)enableInterruptDelivery;
- (int)setBusMasterEnabled:(int)enabled;

- (int)initializeController;
- (int)quiesceController;
- (int)resetController;
- (int)shutdownController;
- (int)waitForReady:(int)ready;
- (int)submitAdminCommand:(NVMeCommand *)command
               commandId:(unsigned short)commandId;
- (int)submitIOCommand:(NVMeCommandBuffer *)command;
- (int)processAdminCompletions;
- (int)processIOCompletions;
- (int)buildPRPsForCommand:(NVMeCommandBuffer *)command
                nvmeCommand:(NVMeCommand *)nvmeCommand;
- (void)releaseCommandResources:(NVMeCommandBuffer *)command;
- (int)allocatePRPPage;
- (void)freePRPPage:(int)pageIndex;

@end

#endif
