#include "NVMeCompatibility.h"

static unsigned roundQueueDepth(unsigned depth)
{
    unsigned rounded = 1;

    if (depth > NVME_MAX_QUEUE_DEPTH)
        depth = NVME_MAX_QUEUE_DEPTH;
    while ((rounded << 1) <= depth)
        rounded <<= 1;
    return rounded;
}

unsigned NVMeSelectQueueDepth(unsigned requested,
                              unsigned controllerEntries)
{
    unsigned depth;

    if (requested < 2 || controllerEntries < 2)
        return 0;
    depth = roundQueueDepth(requested);
    if (depth > controllerEntries)
        depth = roundQueueDepth(controllerEntries);
    return depth < 2 ? 0 : depth;
}

unsigned NVMeMaximumTransferForMDTS(unsigned mdts)
{
    unsigned maximumShift;

    if (mdts == 0)
        return NVME_MAX_TRANSFER;
    maximumShift = 0;
    while ((NVME_PAGE_SIZE << maximumShift) < NVME_MAX_TRANSFER)
        maximumShift++;
    if (mdts >= maximumShift)
        return NVME_MAX_TRANSFER;
    return NVME_PAGE_SIZE << mdts;
}

unsigned NVMeNamespaceBlockSize(unsigned metadataSize,
                                unsigned lbaDataSize)
{
    if (metadataSize != 0 || lbaDataSize < 9 || lbaDataSize > 12)
        return 0;
    return 1U << lbaDataSize;
}

int NVMeControllerNeedsPollingOnly(unsigned vendorId,
                                   unsigned deviceId)
{
    return vendorId == 0x15adU && deviceId == 0x07f0U;
}

int NVMePCIInterruptIsUsable(unsigned interruptLine)
{
    return interruptLine != 0 && interruptLine != 0xffU;
}

int NVMeControllerUsesPollingOnly(unsigned vendorId,
                                  unsigned deviceId,
                                  unsigned interruptLine,
                                  int forcedPolling)
{
    return forcedPolling ||
           NVMeControllerNeedsPollingOnly(vendorId, deviceId) ||
           !NVMePCIInterruptIsUsable(interruptLine);
}
