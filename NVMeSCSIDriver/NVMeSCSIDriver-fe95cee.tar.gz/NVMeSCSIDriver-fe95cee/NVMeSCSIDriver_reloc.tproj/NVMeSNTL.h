#ifndef NVME_SNTL_H
#define NVME_SNTL_H

#include "NVMeRegs.h"

#define SNTL_OP_TEST_UNIT_READY       0x00U
#define SNTL_OP_REQUEST_SENSE         0x03U
#define SNTL_OP_READ6                 0x08U
#define SNTL_OP_WRITE6                0x0aU
#define SNTL_OP_INQUIRY               0x12U
#define SNTL_OP_VERIFY6               0x13U
#define SNTL_OP_MODE_SENSE6           0x1aU
#define SNTL_OP_START_STOP            0x1bU
#define SNTL_OP_PREVENT_ALLOW         0x1eU
#define SNTL_OP_READ_CAPACITY10       0x25U
#define SNTL_OP_READ10                0x28U
#define SNTL_OP_WRITE10               0x2aU
#define SNTL_OP_VERIFY10              0x2fU
#define SNTL_OP_SYNCHRONIZE_CACHE10   0x35U
#define SNTL_OP_READ_DEFECT_DATA10    0x37U
#define SNTL_OP_WRITE12               0xaaU
#define SNTL_OP_READ12                0xa8U
#define SNTL_OP_REPORT_LUNS           0xa0U
#define SNTL_OP_ATA_PASSTHROUGH12     0xa1U
#define SNTL_OP_MODE_SENSE10          0x5aU
#define SNTL_OP_LOG_SENSE             0x4dU
#define SNTL_OP_READ16                0x88U
#define SNTL_OP_WRITE16               0x8aU
#define SNTL_OP_VERIFY16              0x8fU
#define SNTL_OP_SYNCHRONIZE_CACHE16   0x91U
#define SNTL_OP_ATA_PASSTHROUGH16     0x85U
#define SNTL_OP_SERVICE_ACTION_IN16   0x9eU

#define SNTL_SA_READ_CAPACITY16       0x10U

#define SNTL_SENSE_NO_SENSE           0x00U
#define SNTL_SENSE_NOT_READY          0x02U
#define SNTL_SENSE_MEDIUM_ERROR       0x03U
#define SNTL_SENSE_HARDWARE_ERROR     0x04U
#define SNTL_SENSE_ILLEGAL_REQUEST    0x05U
#define SNTL_SENSE_DATA_PROTECT       0x07U
#define SNTL_SENSE_ABORTED_COMMAND    0x0bU

#define SNTL_ASC_INVALID_OPCODE       0x20U
#define SNTL_ASC_LBA_OUT_OF_RANGE     0x21U
#define SNTL_ASC_INVALID_CDB_FIELD    0x24U
#define SNTL_ASC_INVALID_LUN          0x25U
#define SNTL_ASC_LUN_NOT_READY        0x04U
#define SNTL_ASC_WRITE_FAULT          0x03U
#define SNTL_ASC_UNRECOVERED_READ     0x11U
#define SNTL_ASC_WRITE_ERROR          0x0cU
#define SNTL_ASC_WRITE_PROTECTED      0x27U
#define SNTL_ASC_INTERNAL_FAILURE     0x44U
#define SNTL_ASC_COMMAND_ABORTED      0x47U

typedef enum NVMeSNTLAction {
    NVME_SNTL_COMPLETE,
    NVME_SNTL_SUBMIT_IO,
    NVME_SNTL_SUBMIT_FLUSH,
    NVME_SNTL_SUBMIT_SMART,
    NVME_SNTL_CHECK_CONDITION
} NVMeSNTLAction;

typedef struct NVMeSNTLDevice {
    unsigned long long namespaceBlocks;
    unsigned int blockSize;
    unsigned int maxTransfer;
    unsigned char volatileWriteCache;
    unsigned char compareSupported;
    char serial[21];
    char model[41];
    char firmware[9];
    unsigned char nguid[16];
    unsigned char eui64[8];
} NVMeSNTLDevice;

typedef struct NVMeSNTLResult {
    NVMeSNTLAction action;
    unsigned char nvmeOpcode;
    unsigned char dataIn;
    unsigned char fua;
    unsigned char senseKey;
    unsigned char asc;
    unsigned char ascq;
    unsigned long long lba;
    unsigned int blockCount;
    unsigned int transferBytes;
} NVMeSNTLResult;

void NVMeSNTLSetSense(unsigned char *sense, unsigned key,
                      unsigned asc, unsigned ascq);

NVMeSNTLResult NVMeSNTLTranslate(const unsigned char *cdb,
                                 unsigned cdbLength,
                                 int requestIsRead,
                                 void *buffer,
                                 unsigned bufferLength,
                                 const NVMeSNTLDevice *device,
                                 const unsigned char *lastSense);

NVMeSNTLResult NVMeSNTLMapStatus(unsigned statusType,
                                 unsigned statusCode,
                                 int wasWrite);

unsigned NVMeSNTLBuildSmartLog(void *buffer, unsigned bufferLength,
                               const unsigned char *smartLog);

#endif
