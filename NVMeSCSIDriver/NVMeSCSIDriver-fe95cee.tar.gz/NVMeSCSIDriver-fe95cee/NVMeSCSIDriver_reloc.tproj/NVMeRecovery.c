#include "NVMeRecovery.h"
#include "NVMeRegs.h"

unsigned NVMeRecoveryTimeoutSeconds(int requestedSeconds,
                                    int adminCommand)
{
    if (adminCommand)
        return NVME_ADMIN_TIMEOUT_SECONDS;
    if (requestedSeconds > 0)
        return (unsigned)requestedSeconds;
    return NVME_DEFAULT_IO_TIMEOUT_SECONDS;
}

int NVMeRecoveryCommandExpired(unsigned long long now,
                               unsigned long long startTime,
                               int requestedSeconds,
                               int adminCommand)
{
    unsigned long long elapsed;
    unsigned long long timeout;

    if (startTime == 0 || now < startTime)
        return 0;
    elapsed = now - startTime;
    timeout = (unsigned long long)NVMeRecoveryTimeoutSeconds(
                  requestedSeconds, adminCommand) *
              NVME_NANOSECONDS_PER_SECOND;
    return elapsed >= timeout;
}

int NVMeRecoveryReadyState(unsigned controllerStatus, int ready)
{
    int isReady;

    isReady = (controllerStatus & NVME_CSTS_READY) != 0;
    if (!ready && !isReady)
        return NVME_READY_REACHED;
    if (ready && (controllerStatus & NVME_CSTS_FATAL) != 0)
        return NVME_READY_FATAL;
    if (ready && isReady)
        return NVME_READY_REACHED;
    return NVME_READY_WAITING;
}
