#ifndef NVME_SCSI_H
#define NVME_SCSI_H

#import <driverkit/IOSCSIController.h>
#import <driverkit/i386/IOPCIDirectDevice.h>
#import <driverkit/i386/IOPCIDeviceDescription.h>
#import "NVMeTypes.h"
#import "NVMeVersion.h"

@interface NVMeSCSI : IOSCSIController
{
    vm_address_t registers;
    unsigned registerLength;
    unsigned barPhysicalAddress;
    unsigned char busNumber;
    unsigned char deviceNumber;
    unsigned char functionNumber;
    port_t interruptPortKern;

    unsigned long long capabilities;
    unsigned controllerVersion;
    unsigned doorbellStride;
    unsigned maximumTransfer;
    unsigned configuredQueueDepth;
    unsigned configuredPRPPages;
    unsigned faultTimeoutAfter;
    unsigned faultTimeoutSeconds;
    unsigned faultSubmissionCount;

    NVMeQueue adminQueue;
    NVMeQueue ioQueue;
    NVMePage identifyPage;
    NVMePage prpPages[NVME_DEFAULT_PRP_PAGES];
    unsigned prpPageCount;
    unsigned prpBitmap;

    queue_head_t commandQueue;
    queue_head_t pendingQueue;
    NXLock *commandLock;
    void *pollingThread;
    NVMeCommandBuffer *ioSlots[NVME_MAX_QUEUE_DEPTH];
    NVMeCommandBuffer *adminActive;
    volatile unsigned activeCommands;

    volatile int pollingThreadRunning;
    volatile int pollingThreadExited;
    volatile int pollMessagePending;

    NVMeSNTLDevice sntlDevice;
    unsigned char lastSense[18];

    unsigned ioThreadRunning:1;
    unsigned controllerReady:1;
    unsigned shuttingDown:1;
    unsigned barrierActive:1;
    unsigned serializedActive:1;
    unsigned watchdogScheduled:1;
    unsigned recoveryInProgress:1;
    unsigned faultTimeoutActive:1;
    unsigned faultTimeoutInjected:1;
    unsigned completionPollingOnly:1;
    unsigned interruptQualificationMode:1;
    unsigned pollingPathLogged:1;
    unsigned padFlags:20;

    unsigned totalCommands;
    unsigned queueLengthTotal;
    unsigned maximumQueueLength;
    unsigned currentQueueLength;
    unsigned rejectedCommands;
    unsigned interruptSignalCount;
    unsigned interruptCount;
    unsigned fallbackPollCount;
    unsigned fallbackCompletionCount;
    unsigned recoveryAttempts;
    unsigned recoverySuccesses;
    unsigned recoveryFailures;
    unsigned long long bytesRead;
    unsigned long long bytesWritten;
}

+ (BOOL)probe:deviceDescription;
- free;

- (sc_status_t)executeRequest:(IOSCSIRequest *)request
                         buffer:(void *)buffer
                         client:(vm_task_t)client;
- (sc_status_t)executeSCSI3Request:(IOSCSI3Request *)request
                              buffer:(void *)buffer
                              client:(vm_task_t)client;
- (sc_status_t)resetSCSIBus;
- (unsigned)maxTransfer;
- (void)getDMAAlignment:(IODMAAlignment *)alignment;
- (int)numberOfTargets;

- (void)commandRequestOccurred;
- (void)interruptOccurred;
- (void)timeoutOccurred;

@end

#endif
