#import "NVMeSCSI.h"
#import "NVMePrivate.h"
#import "NVMeQueuePolicy.h"
#import <driverkit/generalFuncs.h>
#import <driverkit/interruptMsg.h>
#import <driverkit/kernelDriver.h>
#import <kernserv/prototypes.h>
#import <mach/message.h>
#import <string.h>

static void NVMeWatchdog(void *argument);
static void NVMePoller(void *argument);

#define NVME_INTX_DIAGNOSTIC_POLLS 32U

static msg_header_t commandMessageTemplate = {
    0, 1, sizeof(msg_header_t), MSG_TYPE_NORMAL,
    PORT_NULL, PORT_NULL, IO_COMMAND_MSG
};

static msg_header_t watchdogMessageTemplate = {
    0, 1, sizeof(msg_header_t), MSG_TYPE_NORMAL,
    PORT_NULL, PORT_NULL, IO_TIMEOUT_MSG
};

static unsigned NVMeCDBLength(const unsigned char *cdb, unsigned supplied)
{
    unsigned group;
    if (supplied != 0)
        return supplied > 16 ? 16 : supplied;
    group = (cdb[0] >> 5) & 7;
    if (group == 0)
        return 6;
    if (group == 1 || group == 2)
        return 10;
    if (group == 4)
        return 16;
    if (group == 5)
        return 12;
    return 6;
}

static void NVMeInitializeCommand(NVMeCommandBuffer *command)
{
    bzero(command, sizeof(*command));
    command->operation = NVME_COMMAND_EXECUTE;
    command->driverStatus = SR_IOST_INVALID;
    command->scsiStatus = STAT_GOOD;
    command->prpPage = -1;
}

@implementation NVMeSCSI

+ (BOOL)probe:deviceDescription
{
    NVMeSCSI *instance;
    instance = [self alloc];
    if ([instance initializeFromDeviceDescription:deviceDescription] == nil)
        return NO;
    return YES;
}

- free
{
    NVMeCommandBuffer command;
    int controllerStopped;

    if (commandLock != nil) {
        [commandLock lock];
        shuttingDown = 1;
        [commandLock unlock];
    } else {
        shuttingDown = 1;
    }
    if (registers != 0)
        [self writeRegister32:NVME_REG_INTMS value:0xffffffffU];
    if (ioThreadRunning)
        [self disableAllInterrupts];
    if (pollingThreadRunning) {
        pollingThreadRunning = 0;
        while (!pollingThreadExited)
            IOSleep(1);
        pollingThread = 0;
    }
    if (watchdogScheduled) {
        IOUnscheduleFunc(NVMeWatchdog, self);
        watchdogScheduled = 0;
    }
    controllerStopped = 0;
    if (ioThreadRunning && commandLock != nil) {
        NVMeInitializeCommand(&command);
        command.operation = NVME_COMMAND_ABORT_THREAD;
        [self executeCommandBuffer:&command];
        controllerStopped = command.driverStatus == SR_IOST_GOOD;
        ioThreadRunning = 0;
    } else {
        controllerStopped = [self shutdownController];
    }
    if (controllerStopped) {
        [self freeControllerMemory];
    } else {
        IOLog("%s: controller did not stop; preserving DMA memory\n",
              [self name]);
    }
    if (registers != 0) {
        [self unmapMemoryRange:0 from:registers];
        registers = 0;
    }
    if (commandLock != nil) {
        [commandLock free];
        commandLock = nil;
    }
    return [super free];
}

- (sc_status_t)executeRequest:(IOSCSIRequest *)request
                         buffer:(void *)buffer
                         client:(vm_task_t)client
{
    NVMeCommandBuffer command;
    ns_time_t now;

    NVMeInitializeCommand(&command);
    command.originalRequest = request;
    command.target = request->target;
    command.lun = request->lun;
    command.requestIsRead = request->read;
    command.commandQueueDisabled = request->cmdQueueDisable;
    command.timeoutSeconds = request->timeoutLength;
    command.buffer = buffer;
    command.client = client;
    command.cdbLength = NVMeCDBLength((unsigned char *)&request->cdb,
                                      request->cdbLength);
    bcopy(&request->cdb, command.cdb, command.cdbLength);

    request->driverStatus = SR_IOST_INVALID;
    [self executeCommandBuffer:&command];
    request->driverStatus = command.driverStatus;
    request->scsiStatus = command.scsiStatus;
    request->bytesTransferred = command.bytesTransferred;
    request->senseData = command.senseData;
    IOGetTimestamp(&now);
    request->totalTime = command.startTime == 0 ? 0 : now - command.startTime;
    request->latentTime = 0;
    return request->driverStatus;
}

- (sc_status_t)executeSCSI3Request:(IOSCSI3Request *)request
                              buffer:(void *)buffer
                              client:(vm_task_t)client
{
    NVMeCommandBuffer command;
    ns_time_t now;

    NVMeInitializeCommand(&command);
    command.originalRequest = request;
    command.requestIsSCSI3 = 1;
    command.target = request->target;
    command.lun = request->lun;
    command.requestIsRead = request->read;
    command.commandQueueDisabled = request->cmdQueueDisable;
    command.timeoutSeconds = request->timeoutLength;
    command.buffer = buffer;
    command.client = client;
    command.cdbLength = NVMeCDBLength((unsigned char *)&request->cdb,
                                      request->cdbLength);
    bcopy(&request->cdb, command.cdb, command.cdbLength);

    request->driverStatus = SR_IOST_INVALID;
    [self executeCommandBuffer:&command];
    request->driverStatus = command.driverStatus;
    request->scsiStatus = command.scsiStatus;
    request->bytesTransferred = command.bytesTransferred;
    request->senseData = command.senseData;
    IOGetTimestamp(&now);
    request->totalTime = command.startTime == 0 ? 0 : now - command.startTime;
    request->latentTime = 0;
    return request->driverStatus;
}

- (sc_status_t)resetSCSIBus
{
    NVMeCommandBuffer command;
    NVMeInitializeCommand(&command);
    command.operation = NVME_COMMAND_RESET;
    [self executeCommandBuffer:&command];
    return command.driverStatus;
}

- (unsigned)maxTransfer
{
    return maximumTransfer == 0 ? NVME_MAX_TRANSFER : maximumTransfer;
}

- (void)getDMAAlignment:(IODMAAlignment *)alignment
{
    alignment->readStart = 4;
    alignment->writeStart = 4;
    alignment->readLength = 4;
    alignment->writeLength = 4;
}

- (int)numberOfTargets
{
    return 1;
}

- (unsigned)numQueueSamples
{
    return totalCommands;
}

- (unsigned)sumQueueLengths
{
    return queueLengthTotal;
}

- (unsigned)maxQueueLength
{
    return maximumQueueLength;
}

- (void)resetStats
{
    totalCommands = 0;
    queueLengthTotal = 0;
    maximumQueueLength = 0;
}

- (IOReturn)getCharValues:(unsigned char *)values
               forParameter:(IOParameterName)parameterName
                       count:(unsigned *)count
{
    unsigned needed;
    if (strcmp(parameterName, "NVMeDriverVersion") != 0)
        return [super getCharValues:values forParameter:parameterName count:count];
    needed = strlen(NVME_DRIVER_VERSION) + 1;
    if (*count < needed) {
        *count = needed;
        return IO_R_INVALID_ARG;
    }
    bcopy(NVME_DRIVER_VERSION, values, needed);
    *count = needed;
    return IO_R_SUCCESS;
}

- (IOReturn)getIntValues:(unsigned *)values
              forParameter:(IOParameterName)parameterName
                     count:(unsigned *)count
{
    if (strcmp(parameterName, "NVMeCompletionStats") != 0)
        return [super getIntValues:values forParameter:parameterName
                             count:count];
    if (*count < 6) {
        *count = 6;
        return IO_R_INVALID_ARG;
    }
    values[0] = completionPollingOnly;
    values[1] = interruptQualificationMode;
    values[2] = interruptSignalCount;
    values[3] = interruptCount;
    values[4] = fallbackPollCount;
    values[5] = fallbackCompletionCount;
    *count = 6;
    return IO_R_SUCCESS;
}

- (IOReturn)executeCommandBuffer:(NVMeCommandBuffer *)command
{
    msg_header_t message;
    kern_return_t result;

    command->completionLock = [[NXConditionLock alloc]
                               initWith:NVME_CMD_PENDING];
    if (command->completionLock == nil) {
        command->driverStatus = SR_IOST_INT;
        return IO_R_NO_MEMORY;
    }
    [commandLock lock];
    if (shuttingDown && command->operation != NVME_COMMAND_ABORT_THREAD) {
        [commandLock unlock];
        command->driverStatus = SR_IOST_INT;
        [command->completionLock free];
        command->completionLock = nil;
        return IO_R_SUCCESS;
    }
    queue_enter(&commandQueue, command, NVMeCommandBuffer *, link);

    message = commandMessageTemplate;
    message.msg_remote_port = interruptPortKern;
    result = msg_send_from_kernel(&message, MSG_OPTION_NONE, 0);
    if (result != KERN_SUCCESS) {
        queue_remove(&commandQueue, command, NVMeCommandBuffer *, link);
        [commandLock unlock];
        command->driverStatus = SR_IOST_INT;
        [command->completionLock free];
        command->completionLock = nil;
        return IO_R_IPC_FAILURE;
    }
    [commandLock unlock];
    [command->completionLock lockWhen:NVME_CMD_COMPLETE];
    [command->completionLock free];
    command->completionLock = nil;
    return IO_R_SUCCESS;
}

- (int)canStartCommand:(NVMeCommandBuffer *)command
          olderPending:(int)olderPending
{
    NVMeQueuePolicyState state;
    NVMeQueuePolicyCommand policyCommand;

    state.activeCommands = activeCommands;
    state.recoveryBlocked = shuttingDown || !controllerReady ||
                            recoveryInProgress || faultTimeoutActive;
    state.barrierActive = barrierActive;
    state.serializedActive = serializedActive;
    state.olderCommandPending = olderPending;
    state.adminBusy = adminActive != 0;
    policyCommand.barrier = command->barrier;
    policyCommand.serialized = command->commandQueueDisabled;
    policyCommand.usesAdminQueue =
        command->translation.action == NVME_SNTL_SUBMIT_SMART;
    return NVMeQueueCommandMayStart(&state, &policyCommand);
}

- (void)commandRequestOccurred
{
    NVMeCommandBuffer *command;
    int adminHandled;
    int ioHandled;
    int pollWasPending;

    pollWasPending = pollMessagePending;
    if (pollWasPending) {
        pollMessagePending = 0;
        fallbackPollCount++;
    }
    adminHandled = [self processAdminCompletions];
    ioHandled = [self processIOCompletions];
    if (pollWasPending && (adminHandled || ioHandled)) {
        fallbackCompletionCount++;
        if (!completionPollingOnly && !pollingPathLogged &&
            interruptCount == 0 &&
            fallbackCompletionCount >= NVME_INTX_DIAGNOSTIC_POLLS) {
            pollingPathLogged = 1;
            IOLog("%s: no legacy INTx completion observed after %u "
                  "polled completion batches; polling fallback is active\n",
                  [self name], fallbackCompletionCount);
        }
    }
    [self startPendingCommands];

    [commandLock lock];
    while (!queue_empty(&commandQueue)) {
        command = (NVMeCommandBuffer *)queue_first(&commandQueue);
        queue_remove(&commandQueue, command, NVMeCommandBuffer *, link);
        [commandLock unlock];

        if (command->operation == NVME_COMMAND_EXECUTE) {
            currentQueueLength++;
            totalCommands++;
            queueLengthTotal += currentQueueLength;
            if (currentQueueLength > maximumQueueLength)
                maximumQueueLength = currentQueueLength;
            [self dispatchCommand:command];
        } else if (command->operation == NVME_COMMAND_RESET) {
            int quiesceResult;
            recoveryInProgress = 1;
            faultTimeoutActive = 0;
            quiesceResult = [self quiesceController];
            if (quiesceResult != NVME_QUIESCE_FAILED) {
                [self abortOutstanding:SR_IOST_RESET
                            pendingStatus:SR_IOST_RESET];
                if (quiesceResult == NVME_QUIESCE_STOPPED)
                    command->driverStatus = [self resetController] ?
                                            SR_IOST_GOOD : SR_IOST_INT;
                else
                    command->driverStatus = SR_IOST_INT;
            } else {
                command->driverStatus = SR_IOST_INT;
            }
            recoveryInProgress = 0;
            [self completeCommand:command];
        } else if (command->operation == NVME_COMMAND_SHUTDOWN) {
            [commandLock lock];
            shuttingDown = 1;
            [commandLock unlock];
            command->driverStatus = [self shutdownController] ?
                                    SR_IOST_GOOD : SR_IOST_INT;
            if (command->driverStatus == SR_IOST_GOOD)
                [self abortOutstanding:SR_IOST_RESET
                            pendingStatus:SR_IOST_RESET];
            [self completeCommand:command];
        } else {
            command->driverStatus = [self shutdownController] ?
                                    SR_IOST_GOOD : SR_IOST_INT;
            if (command->driverStatus == SR_IOST_GOOD)
                [self abortOutstanding:SR_IOST_INT
                            pendingStatus:SR_IOST_INT];
            [command->completionLock lock];
            [command->completionLock unlockWith:NVME_CMD_COMPLETE];
            IOExitThread();
        }

        [commandLock lock];
    }
    [commandLock unlock];
    [self processAdminCompletions];
    [self processIOCompletions];
    [self startPendingCommands];
}

- (void)dispatchCommand:(NVMeCommandBuffer *)command
{
    unsigned char *sense;
    int requestedLength;
    unsigned bufferLength;
    int submitResult;

    if (command->target != 0) {
        command->driverStatus = SR_IOST_SELTO;
        [self completeCommand:command];
        return;
    }
    if (command->lun != 0) {
        sense = (unsigned char *)&command->senseData;
        NVMeSNTLSetSense(sense, SNTL_SENSE_ILLEGAL_REQUEST,
                         SNTL_ASC_INVALID_LUN, 0);
        bcopy(sense, lastSense, 18);
        command->driverStatus = SR_IOST_CHKSV;
        command->scsiStatus = STAT_CHECK;
        [self completeCommand:command];
        return;
    }
    if (!controllerReady) {
        sense = (unsigned char *)&command->senseData;
        NVMeSNTLSetSense(sense, SNTL_SENSE_NOT_READY,
                         SNTL_ASC_LUN_NOT_READY, 1);
        bcopy(sense, lastSense, 18);
        command->driverStatus = SR_IOST_CHKSV;
        command->scsiStatus = STAT_CHECK;
        [self completeCommand:command];
        return;
    }

    requestedLength = command->originalRequest == 0 ? 0 :
                      (command->requestIsSCSI3 ?
                       ((IOSCSI3Request *)command->originalRequest)->maxTransfer :
                       ((IOSCSIRequest *)command->originalRequest)->maxTransfer);
    bufferLength = requestedLength > 0 ? (unsigned)requestedLength : 0;
    command->translation = NVMeSNTLTranslate(command->cdb,
                                command->cdbLength,
                                command->requestIsRead,
                                command->buffer,
                                bufferLength,
                                &sntlDevice, lastSense);

    if (command->translation.action == NVME_SNTL_COMPLETE) {
        command->driverStatus = SR_IOST_GOOD;
        command->scsiStatus = STAT_GOOD;
        command->bytesTransferred = command->translation.transferBytes;
        [self completeCommand:command];
        return;
    }
    if (command->translation.action == NVME_SNTL_CHECK_CONDITION) {
        sense = (unsigned char *)&command->senseData;
        NVMeSNTLSetSense(sense, command->translation.senseKey,
                         command->translation.asc, command->translation.ascq);
        bcopy(sense, lastSense, 18);
        command->driverStatus = SR_IOST_CHKSV;
        command->scsiStatus = STAT_CHECK;
        rejectedCommands++;
        [self completeCommand:command];
        return;
    }

    command->barrier = command->translation.action == NVME_SNTL_SUBMIT_FLUSH;
    if (![self canStartCommand:command
                    olderPending:!queue_empty(&pendingQueue)]) {
        queue_enter(&pendingQueue, command, NVMeCommandBuffer *, link);
        return;
    }

    submitResult = [self submitIOCommand:command];
    if (submitResult == 0) {
        queue_enter(&pendingQueue, command, NVMeCommandBuffer *, link);
    } else if (submitResult < 0) {
        IOLog("%s: DMA mapping failed for SCSI opcode 0x%02x, %u bytes\n",
              [self name], command->cdb[0],
              command->translation.transferBytes);
        sense = (unsigned char *)&command->senseData;
        NVMeSNTLSetSense(sense, SNTL_SENSE_HARDWARE_ERROR,
                         SNTL_ASC_INTERNAL_FAILURE, 0);
        bcopy(sense, lastSense, 18);
        command->driverStatus = SR_IOST_CHKSV;
        command->scsiStatus = STAT_CHECK;
        [self completeCommand:command];
    }
}

- (void)startPendingCommands
{
    NVMeCommandBuffer *command;
    int result;

    while (!queue_empty(&pendingQueue)) {
        command = (NVMeCommandBuffer *)queue_first(&pendingQueue);
        if (![self canStartCommand:command olderPending:0])
            break;
        queue_remove(&pendingQueue, command, NVMeCommandBuffer *, link);
        result = [self submitIOCommand:command];
        if (result == 0) {
            queue_enter_first(&pendingQueue, command,
                              NVMeCommandBuffer *, link);
            break;
        }
        if (result < 0) {
            unsigned char *sense = (unsigned char *)&command->senseData;
            IOLog("%s: DMA mapping failed for pending SCSI opcode 0x%02x, "
                  "%u bytes\n", [self name], command->cdb[0],
                  command->translation.transferBytes);
            NVMeSNTLSetSense(sense, SNTL_SENSE_HARDWARE_ERROR,
                             SNTL_ASC_INTERNAL_FAILURE, 0);
            bcopy(sense, lastSense, 18);
            command->driverStatus = SR_IOST_CHKSV;
            command->scsiStatus = STAT_CHECK;
            [self completeCommand:command];
            continue;
        }
    }
}

- (void)completeCommand:(NVMeCommandBuffer *)command
{
    if (command->completed) {
        IOLog("%s: ignored duplicate command completion\n", [self name]);
        return;
    }
    command->completed = 1;
    if (command->operation == NVME_COMMAND_EXECUTE && currentQueueLength != 0)
        currentQueueLength--;
    [command->completionLock lock];
    [command->completionLock unlockWith:NVME_CMD_COMPLETE];
}

- (void)completeCommand:(NVMeCommandBuffer *)command
             withStatus:(sc_status_t)status
{
    command->driverStatus = status;
    [self completeCommand:command];
}

- (void)abortOutstanding:(sc_status_t)activeStatus
            pendingStatus:(sc_status_t)pendingStatus
{
    NVMeCommandBuffer *command;
    unsigned i;

    for (i = 0; i < NVME_MAX_QUEUE_DEPTH; i++) {
        command = ioSlots[i];
        if (command != 0) {
            ioSlots[i] = 0;
            [self releaseCommandResources:command];
            command->driverStatus = activeStatus;
            [self completeCommand:command];
        }
    }
    if (adminActive != 0) {
        command = adminActive;
        adminActive = 0;
        [self releaseCommandResources:command];
        command->driverStatus = activeStatus;
        [self completeCommand:command];
    }
    while (!queue_empty(&pendingQueue)) {
        command = (NVMeCommandBuffer *)queue_first(&pendingQueue);
        queue_remove(&pendingQueue, command, NVMeCommandBuffer *, link);
        command->driverStatus = pendingStatus;
        [self completeCommand:command];
    }
    activeCommands = 0;
    barrierActive = 0;
    serializedActive = 0;
    faultTimeoutActive = 0;
}

- (unsigned)abortTimedOutCommandsAt:(ns_time_t)now
{
    NVMeCommandBuffer *command;
    sc_status_t status;
    unsigned timedOut;
    unsigned i;

    timedOut = 0;
    for (i = 0; i < NVME_MAX_QUEUE_DEPTH; i++) {
        command = ioSlots[i];
        if (command != 0) {
            ioSlots[i] = 0;
            if (NVMeRecoveryCommandExpired(now, command->startTime,
                                           command->timeoutSeconds, 0)) {
                status = SR_IOST_IOTO;
                timedOut++;
            } else {
                status = SR_IOST_RESET;
            }
            [self releaseCommandResources:command];
            command->driverStatus = status;
            [self completeCommand:command];
        }
    }
    if (adminActive != 0) {
        command = adminActive;
        adminActive = 0;
        if (NVMeRecoveryCommandExpired(now, command->startTime,
                                       command->timeoutSeconds, 1)) {
            status = SR_IOST_IOTO;
            timedOut++;
        } else {
            status = SR_IOST_RESET;
        }
        [self releaseCommandResources:command];
        command->driverStatus = status;
        [self completeCommand:command];
    }
    while (!queue_empty(&pendingQueue)) {
        command = (NVMeCommandBuffer *)queue_first(&pendingQueue);
        queue_remove(&pendingQueue, command, NVMeCommandBuffer *, link);
        command->driverStatus = SR_IOST_RESET;
        [self completeCommand:command];
    }
    activeCommands = 0;
    barrierActive = 0;
    serializedActive = 0;
    faultTimeoutActive = 0;
    return timedOut;
}

- (void)interruptOccurred
{
    int handled;
    interruptSignalCount++;
    handled = [self processAdminCompletions];
    handled |= [self processIOCompletions];
    if (handled)
        interruptCount++;
    [self startPendingCommands];
    if (!shuttingDown && controllerReady && !recoveryInProgress)
        [self enableInterruptDelivery];
}

- (void)timeoutOccurred
{
    ns_time_t now;
    NVMeCommandBuffer *command;
    unsigned i;
    int expired;
    int fatal;
    int recovered;
    int quiesceResult;
    unsigned timedOut;
    unsigned controllerStatus;

    watchdogScheduled = 0;
    [self processAdminCompletions];
    [self processIOCompletions];
    IOGetTimestamp(&now);
    expired = 0;
    for (i = 0; i < ioQueue.depth && !expired; i++) {
        command = ioSlots[i];
        if (command != 0 &&
            NVMeRecoveryCommandExpired(now, command->startTime,
                                       command->timeoutSeconds, 0))
            expired = 1;
    }
    if (adminActive != 0 &&
        NVMeRecoveryCommandExpired(now, adminActive->startTime,
                                   adminActive->timeoutSeconds, 1))
        expired = 1;
    controllerStatus = [self readRegister32:NVME_REG_CSTS];
    fatal = controllerReady &&
            (controllerStatus & NVME_CSTS_FATAL) != 0;
    if (expired || fatal) {
        recoveryInProgress = 1;
        faultTimeoutActive = 0;
        recoveryAttempts++;
        quiesceResult = [self quiesceController];
        if (quiesceResult == NVME_QUIESCE_FAILED) {
            recoveryFailures++;
            IOLog("%s: controller recovery could not stop DMA (%u/%u)\n",
                  [self name], recoveryFailures, recoveryAttempts);
        } else {
            if (expired) {
                timedOut = [self abortTimedOutCommandsAt:now];
                IOLog("%s: %u command(s) timed out; recovery attempt %u\n",
                      [self name], timedOut, recoveryAttempts);
            } else {
                IOLog("%s: controller fatal status 0x%08x; "
                      "recovery attempt %u\n",
                      [self name], controllerStatus, recoveryAttempts);
                [self abortOutstanding:SR_IOST_RESET
                            pendingStatus:SR_IOST_RESET];
            }
            recovered = quiesceResult == NVME_QUIESCE_STOPPED &&
                        [self resetController];
            if (recovered) {
                recoverySuccesses++;
                IOLog("%s: controller recovery succeeded (%u/%u)\n",
                      [self name], recoverySuccesses, recoveryAttempts);
            } else {
                recoveryFailures++;
                if (quiesceResult == NVME_QUIESCE_DMA_FENCED)
                    IOLog("%s: controller remained active; PCI DMA stays "
                          "fenced\n", [self name]);
                IOLog("%s: controller recovery failed (%u/%u)\n",
                      [self name], recoveryFailures, recoveryAttempts);
            }
        }
        recoveryInProgress = 0;
    }
    [self startPendingCommands];
    [self armWatchdog];
}

- (void)armWatchdog
{
    if (activeCommands != 0 && !watchdogScheduled && !shuttingDown) {
        watchdogScheduled = 1;
        IOScheduleFunc(NVMeWatchdog, self, 1);
    }
}

- (void)sendWatchdogMessage
{
    msg_header_t message;
    kern_return_t result;

    message = watchdogMessageTemplate;
    message.msg_remote_port = interruptPortKern;
    result = msg_send_from_kernel(&message, MSG_OPTION_NONE, 0);
    if (result != KERN_SUCCESS) {
        watchdogScheduled = 0;
        [self armWatchdog];
    }
}

static void NVMeWatchdog(void *argument)
{
    [(NVMeSCSI *)argument sendWatchdogMessage];
}

- (int)startPollingThread
{
    pollingThreadExited = 0;
    pollMessagePending = 0;
    pollingThreadRunning = 1;
    pollingThread = IOForkThread(NVMePoller, self);
    if (pollingThread == 0) {
        pollingThreadRunning = 0;
        pollingThreadExited = 1;
        return 0;
    }
    return 1;
}

- (void)pollingLoop
{
    msg_header_t message;
    kern_return_t result;

    while (pollingThreadRunning) {
        if (activeCommands != 0 && !pollMessagePending) {
            if (interruptQualificationMode) {
                IOSleep(NVME_INTX_POLL_GRACE_MS);
                if (!pollingThreadRunning)
                    break;
                if (activeCommands == 0 || pollMessagePending)
                    continue;
            }
            pollMessagePending = 1;
            message = commandMessageTemplate;
            message.msg_remote_port = interruptPortKern;
            result = msg_send_from_kernel(&message, MSG_OPTION_NONE, 0);
            if (result != KERN_SUCCESS)
                pollMessagePending = 0;
            IOSleep(1);
        } else {
            IOSleep(completionPollingOnly ? 1 :
                    NVME_INTX_POLL_GRACE_MS);
        }
    }
    pollingThreadExited = 1;
    IOExitThread();
}

static void NVMePoller(void *argument)
{
    [(NVMeSCSI *)argument pollingLoop];
}

@end
