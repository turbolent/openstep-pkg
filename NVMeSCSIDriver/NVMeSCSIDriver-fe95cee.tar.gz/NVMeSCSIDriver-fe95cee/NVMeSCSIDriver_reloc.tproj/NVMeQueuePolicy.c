#include "NVMeQueuePolicy.h"

int NVMeQueueCommandMayStart(const NVMeQueuePolicyState *state,
                             const NVMeQueuePolicyCommand *command)
{
    if (state == 0 || command == 0)
        return 0;
    if (state->recoveryBlocked || state->barrierActive ||
        state->serializedActive || state->olderCommandPending)
        return 0;
    if ((command->barrier || command->serialized) &&
        state->activeCommands != 0)
        return 0;
    if (command->usesAdminQueue && state->adminBusy)
        return 0;
    return 1;
}
