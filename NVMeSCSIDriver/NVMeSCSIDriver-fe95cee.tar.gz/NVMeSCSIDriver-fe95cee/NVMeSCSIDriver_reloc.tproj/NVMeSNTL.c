#include <string.h>
#include "NVMeSNTL.h"

static unsigned sntlMin(unsigned a, unsigned b)
{
    return a < b ? a : b;
}

static unsigned sntlGet16(const unsigned char *p)
{
    return ((unsigned)p[0] << 8) | p[1];
}

static unsigned sntlGet32(const unsigned char *p)
{
    return ((unsigned)p[0] << 24) | ((unsigned)p[1] << 16) |
           ((unsigned)p[2] << 8) | p[3];
}

static unsigned long long sntlGet64(const unsigned char *p)
{
    return ((unsigned long long)p[0] << 56) |
           ((unsigned long long)p[1] << 48) |
           ((unsigned long long)p[2] << 40) |
           ((unsigned long long)p[3] << 32) |
           ((unsigned long long)p[4] << 24) |
           ((unsigned long long)p[5] << 16) |
           ((unsigned long long)p[6] << 8) | p[7];
}

static void sntlPut16(unsigned char *p, unsigned value)
{
    p[0] = (unsigned char)(value >> 8);
    p[1] = (unsigned char)value;
}

static void sntlPut32(unsigned char *p, unsigned value)
{
    p[0] = (unsigned char)(value >> 24);
    p[1] = (unsigned char)(value >> 16);
    p[2] = (unsigned char)(value >> 8);
    p[3] = (unsigned char)value;
}

static void sntlPut64(unsigned char *p, unsigned long long value)
{
    p[0] = (unsigned char)(value >> 56);
    p[1] = (unsigned char)(value >> 48);
    p[2] = (unsigned char)(value >> 40);
    p[3] = (unsigned char)(value >> 32);
    p[4] = (unsigned char)(value >> 24);
    p[5] = (unsigned char)(value >> 16);
    p[6] = (unsigned char)(value >> 8);
    p[7] = (unsigned char)value;
}

static int sntlNonzero(const unsigned char *p, unsigned length)
{
    while (length != 0) {
        if (*p++ != 0)
            return 1;
        length--;
    }
    return 0;
}

static void sntlCopyPadded(unsigned char *out, unsigned length,
                           const char *in, unsigned inLength)
{
    unsigned i;
    for (i = 0; i < length; i++) {
        if (i < inLength && in[i] != 0)
            out[i] = (unsigned char)in[i];
        else
            out[i] = ' ';
    }
}

static NVMeSNTLResult sntlComplete(unsigned bytes)
{
    NVMeSNTLResult result;
    memset(&result, 0, sizeof(result));
    result.action = NVME_SNTL_COMPLETE;
    result.transferBytes = bytes;
    return result;
}

static NVMeSNTLResult sntlCheck(unsigned key, unsigned asc, unsigned ascq)
{
    NVMeSNTLResult result;
    memset(&result, 0, sizeof(result));
    result.action = NVME_SNTL_CHECK_CONDITION;
    result.senseKey = (unsigned char)key;
    result.asc = (unsigned char)asc;
    result.ascq = (unsigned char)ascq;
    return result;
}

void NVMeSNTLSetSense(unsigned char *sense, unsigned key,
                      unsigned asc, unsigned ascq)
{
    memset(sense, 0, 18);
    sense[0] = 0x70;
    sense[2] = (unsigned char)key;
    sense[7] = 10;
    sense[12] = (unsigned char)asc;
    sense[13] = (unsigned char)ascq;
}

static NVMeSNTLResult sntlInquiry(const unsigned char *cdb,
                                  void *buffer, unsigned bufferLength,
                                  const NVMeSNTLDevice *device)
{
    unsigned char data[96];
    unsigned allocation;
    unsigned length;
    unsigned page;
    unsigned modelOffset;
    unsigned i;
    int evpd;

    allocation = cdb[4];
    evpd = cdb[1] & 1;
    page = cdb[2];
    memset(data, 0, sizeof(data));

    if (!evpd) {
        if (page != 0)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        data[0] = 0;
        data[2] = 5;
        data[3] = 2;
        data[4] = 31;
        data[7] = 2;
        modelOffset = 0;
        while (modelOffset < 40 && device->model[modelOffset] == ' ')
            modelOffset++;
        for (i = 0; i < 8 && modelOffset < 40 &&
                    device->model[modelOffset] != 0; i++, modelOffset++)
            data[8 + i] = (unsigned char)device->model[modelOffset];
        while (i < 8)
            data[8 + i++] = ' ';
        for (i = 0; i < 16 && modelOffset < 40 &&
                    device->model[modelOffset] != 0; i++, modelOffset++)
            data[16 + i] = (unsigned char)device->model[modelOffset];
        while (i < 16)
            data[16 + i++] = ' ';
        sntlCopyPadded(data + 32, 4, device->firmware, 8);
        length = 36;
    } else if (page == 0x00) {
        data[1] = 0x00;
        data[3] = 5;
        data[4] = 0x00;
        data[5] = 0x80;
        data[6] = 0x83;
        data[7] = 0xb0;
        data[8] = 0xb1;
        length = 9;
    } else if (page == 0x80) {
        unsigned serialLength = 0;
        while (serialLength < 20 && device->serial[serialLength] != 0)
            serialLength++;
        data[1] = 0x80;
        sntlPut16(data + 2, serialLength);
        memcpy(data + 4, device->serial, serialLength);
        length = 4 + serialLength;
    } else if (page == 0x83) {
        unsigned descriptorLength;
        data[1] = 0x83;
        if (sntlNonzero(device->eui64, 8)) {
            data[4] = 0x01;
            data[5] = 0x02;
            data[7] = 8;
            memcpy(data + 8, device->eui64, 8);
            descriptorLength = 12;
        } else if (sntlNonzero(device->nguid, 16)) {
            data[4] = 0x01;
            data[5] = 0x03;
            data[7] = 16;
            memcpy(data + 8, device->nguid, 16);
            descriptorLength = 20;
        } else {
            data[4] = 0x02;
            data[5] = 0x01;
            data[7] = 20;
            sntlCopyPadded(data + 8, 20, device->serial, 20);
            descriptorLength = 24;
        }
        sntlPut16(data + 2, descriptorLength);
        length = 4 + descriptorLength;
    } else if (page == 0xb0) {
        unsigned maximumBlocks;
        data[1] = 0xb0;
        sntlPut16(data + 2, 60);
        maximumBlocks = device->blockSize == 0 ? 0 :
                        device->maxTransfer / device->blockSize;
        sntlPut32(data + 8, maximumBlocks);
        sntlPut32(data + 12, maximumBlocks);
        length = 64;
    } else if (page == 0xb1) {
        data[1] = 0xb1;
        sntlPut16(data + 2, 60);
        data[5] = 1;
        data[7] = 0x0c;
        length = 64;
    } else {
        return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                         SNTL_ASC_INVALID_CDB_FIELD, 0);
    }

    length = sntlMin(length, sntlMin(allocation, bufferLength));
    if (length != 0) {
        if (buffer == 0)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        memcpy(buffer, data, length);
    }
    return sntlComplete(length);
}

static unsigned sntlAppendModePage(unsigned char *data, unsigned offset,
                                   unsigned page, unsigned pageControl,
                                   const NVMeSNTLDevice *device)
{
    unsigned length;
    unsigned i;
    if (page == 0x03) {
        length = 24;
        memset(data + offset, 0, length);
        data[offset] = 0x03;
        data[offset + 1] = 22;
        sntlPut16(data + offset + 10, 63);
        sntlPut16(data + offset + 12, (unsigned short)device->blockSize);
    } else if (page == 0x04) {
        unsigned long long cylinders;
        length = 24;
        memset(data + offset, 0, length);
        data[offset] = 0x04;
        data[offset + 1] = 22;
        cylinders = device->namespaceBlocks / (64U * 63U);
        if (cylinders == 0)
            cylinders = 1;
        if (cylinders > 0xffffffULL)
            cylinders = 0xffffffULL;
        data[offset + 2] = (unsigned char)(cylinders >> 16);
        data[offset + 3] = (unsigned char)(cylinders >> 8);
        data[offset + 4] = (unsigned char)cylinders;
        data[offset + 5] = 64;
        data[offset + 21] = 1;
    } else if (page == 0x08) {
        length = 20;
        memset(data + offset, 0, length);
        data[offset] = 0x08;
        data[offset + 1] = 18;
        if (device->volatileWriteCache)
            data[offset + 2] |= 0x04;
    } else if (page == 0x0a || page == 0x1a || page == 0x1c) {
        length = 12;
        memset(data + offset, 0, length);
        data[offset] = (unsigned char)page;
        data[offset + 1] = 10;
        if (page == 0x1c) {
            data[offset + 3] = 6;
            data[offset + 11] = 1;
        }
    } else {
        return offset;
    }
    if (pageControl == 1)
        for (i = 2; i < length; i++)
            data[offset + i] = 0;
    return offset + length;
}

static NVMeSNTLResult sntlModeSense(const unsigned char *cdb,
                                    void *buffer, unsigned bufferLength,
                                    const NVMeSNTLDevice *device,
                                    int tenByte)
{
    unsigned char data[160];
    unsigned allocation;
    unsigned page;
    unsigned pageControl;
    unsigned offset;
    unsigned blockDescriptorLength;
    unsigned length;
    int dbd;

    memset(data, 0, sizeof(data));
    page = cdb[2] & 0x3f;
    pageControl = (cdb[2] >> 6) & 3;
    dbd = cdb[1] & 0x08;
    allocation = tenByte ? sntlGet16(cdb + 7) : cdb[4];
    offset = tenByte ? 8 : 4;
    blockDescriptorLength = dbd ? 0 : 8;
    if (blockDescriptorLength != 0) {
        unsigned long long blocks = device->namespaceBlocks;
        if (tenByte) {
            unsigned shown = blocks > 0xffffffffULL ? 0xffffffffU :
                             (unsigned)blocks;
            sntlPut32(data + offset, shown);
        } else {
            unsigned shown = blocks > 0xffffffULL ? 0xffffffU :
                             (unsigned)blocks;
            data[offset] = (unsigned char)(shown >> 16);
            data[offset + 1] = (unsigned char)(shown >> 8);
            data[offset + 2] = (unsigned char)shown;
        }
        data[offset + 5] = (unsigned char)(device->blockSize >> 16);
        data[offset + 6] = (unsigned char)(device->blockSize >> 8);
        data[offset + 7] = (unsigned char)device->blockSize;
        offset += 8;
    }

    if (page == 0x00) {
        /* OPENSTEP probes page zero to obtain the block descriptor only. */
    } else if (page == 0x3f) {
        offset = sntlAppendModePage(data, offset, 0x03, pageControl, device);
        offset = sntlAppendModePage(data, offset, 0x04, pageControl, device);
        offset = sntlAppendModePage(data, offset, 0x08, pageControl, device);
        offset = sntlAppendModePage(data, offset, 0x0a, pageControl, device);
        offset = sntlAppendModePage(data, offset, 0x1a, pageControl, device);
        offset = sntlAppendModePage(data, offset, 0x1c, pageControl, device);
    } else {
        unsigned oldOffset = offset;
        offset = sntlAppendModePage(data, offset, page, pageControl, device);
        if (offset == oldOffset)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
    }

    if (tenByte) {
        sntlPut16(data, offset - 2);
        sntlPut16(data + 6, blockDescriptorLength);
    } else {
        data[0] = (unsigned char)(offset - 1);
        data[3] = (unsigned char)blockDescriptorLength;
    }
    length = sntlMin(offset, sntlMin(allocation, bufferLength));
    if (length != 0) {
        if (buffer == 0)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        memcpy(buffer, data, length);
    }
    return sntlComplete(length);
}

static NVMeSNTLResult sntlReadWrite(const unsigned char *cdb,
                                    unsigned cdbLength,
                                    int requestIsRead,
                                    void *buffer,
                                    unsigned bufferLength,
                                    const NVMeSNTLDevice *device)
{
    NVMeSNTLResult result;
    unsigned opcode = cdb[0];
    unsigned long long lba;
    unsigned blocks;
    unsigned long long bytes;
    int write;

    memset(&result, 0, sizeof(result));
    if (opcode == SNTL_OP_READ6 || opcode == SNTL_OP_WRITE6) {
        if (cdbLength < 6)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        lba = ((unsigned long long)(cdb[1] & 0x1f) << 16) |
              ((unsigned)cdb[2] << 8) | cdb[3];
        blocks = cdb[4] == 0 ? 256 : cdb[4];
    } else if (opcode == SNTL_OP_READ10 || opcode == SNTL_OP_WRITE10) {
        if (cdbLength < 10)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        lba = sntlGet32(cdb + 2);
        blocks = sntlGet16(cdb + 7);
        result.fua = (cdb[1] & 0x08) != 0;
    } else if (opcode == SNTL_OP_READ12 || opcode == SNTL_OP_WRITE12) {
        if (cdbLength < 12)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        lba = sntlGet32(cdb + 2);
        blocks = sntlGet32(cdb + 6);
        result.fua = (cdb[1] & 0x08) != 0;
    } else {
        if (cdbLength < 16)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        lba = sntlGet64(cdb + 2);
        blocks = sntlGet32(cdb + 10);
        result.fua = (cdb[1] & 0x08) != 0;
    }

    write = opcode == SNTL_OP_WRITE6 || opcode == SNTL_OP_WRITE10 ||
            opcode == SNTL_OP_WRITE12 || opcode == SNTL_OP_WRITE16;
    if ((!write && !requestIsRead) || (write && requestIsRead))
        return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                         SNTL_ASC_INVALID_CDB_FIELD, 0);
    if (blocks == 0)
        return sntlComplete(0);
    if (lba >= device->namespaceBlocks ||
        (unsigned long long)blocks > device->namespaceBlocks - lba)
        return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                         SNTL_ASC_LBA_OUT_OF_RANGE, 0);
    bytes = (unsigned long long)blocks * device->blockSize;
    if (bytes > bufferLength || bytes > device->maxTransfer ||
        bytes > 0xffffffffULL || buffer == 0)
        return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                         SNTL_ASC_INVALID_CDB_FIELD, 0);

    result.action = NVME_SNTL_SUBMIT_IO;
    result.nvmeOpcode = write ? NVME_NVM_WRITE : NVME_NVM_READ;
    result.dataIn = write ? 0 : 1;
    result.lba = lba;
    result.blockCount = blocks;
    result.transferBytes = (unsigned)bytes;
    return result;
}

NVMeSNTLResult NVMeSNTLTranslate(const unsigned char *cdb,
                                 unsigned cdbLength,
                                 int requestIsRead,
                                 void *buffer,
                                 unsigned bufferLength,
                                 const NVMeSNTLDevice *device,
                                 const unsigned char *lastSense)
{
    unsigned char data[32];
    unsigned opcode;
    unsigned length;
    NVMeSNTLResult result;

    if (cdb == 0 || cdbLength == 0 || device == 0)
        return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                         SNTL_ASC_INVALID_CDB_FIELD, 0);
    opcode = cdb[0];

    switch (opcode) {
    case SNTL_OP_TEST_UNIT_READY:
    case SNTL_OP_START_STOP:
    case SNTL_OP_PREVENT_ALLOW:
        if (cdbLength < 6)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        return sntlComplete(0);
    case SNTL_OP_REQUEST_SENSE:
        if (cdbLength < 6 || !requestIsRead)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        length = sntlMin(cdb[4], bufferLength);
        length = sntlMin(length, 18);
        if (length != 0) {
            if (buffer == 0)
                return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                                 SNTL_ASC_INVALID_CDB_FIELD, 0);
            if (lastSense != 0)
                memcpy(buffer, lastSense, length);
            else {
                NVMeSNTLSetSense(data, SNTL_SENSE_NO_SENSE, 0, 0);
                memcpy(buffer, data, length);
            }
        }
        return sntlComplete(length);
    case SNTL_OP_INQUIRY:
        if (cdbLength < 6 || !requestIsRead)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        return sntlInquiry(cdb, buffer, bufferLength, device);
    case SNTL_OP_READ_CAPACITY10:
        if (cdbLength < 10 || !requestIsRead || bufferLength < 8 ||
            buffer == 0)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        memset(data, 0, 8);
        if (device->namespaceBlocks - 1 > 0xffffffffULL)
            sntlPut32(data, 0xffffffffU);
        else
            sntlPut32(data, (unsigned)(device->namespaceBlocks - 1));
        sntlPut32(data + 4, device->blockSize);
        memcpy(buffer, data, 8);
        return sntlComplete(8);
    case SNTL_OP_SERVICE_ACTION_IN16:
        if (cdbLength < 16 || !requestIsRead ||
            (cdb[1] & 0x1f) != SNTL_SA_READ_CAPACITY16)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        length = sntlMin(sntlGet32(cdb + 10), bufferLength);
        length = sntlMin(length, 32);
        if (length != 0 && buffer == 0)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        memset(data, 0, 32);
        sntlPut64(data, device->namespaceBlocks - 1);
        sntlPut32(data + 8, device->blockSize);
        if (length != 0)
            memcpy(buffer, data, length);
        return sntlComplete(length);
    case SNTL_OP_MODE_SENSE6:
        if (cdbLength < 6 || !requestIsRead)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        return sntlModeSense(cdb, buffer, bufferLength, device, 0);
    case SNTL_OP_MODE_SENSE10:
        if (cdbLength < 10 || !requestIsRead)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        return sntlModeSense(cdb, buffer, bufferLength, device, 1);
    case SNTL_OP_READ6:
    case SNTL_OP_WRITE6:
    case SNTL_OP_READ10:
    case SNTL_OP_WRITE10:
    case SNTL_OP_READ12:
    case SNTL_OP_WRITE12:
    case SNTL_OP_READ16:
    case SNTL_OP_WRITE16:
        return sntlReadWrite(cdb, cdbLength, requestIsRead, buffer,
                             bufferLength, device);
    case SNTL_OP_SYNCHRONIZE_CACHE10:
    case SNTL_OP_SYNCHRONIZE_CACHE16:
        if (cdbLength < (opcode == SNTL_OP_SYNCHRONIZE_CACHE10 ? 10 : 16))
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        memset(&result, 0, sizeof(result));
        result.action = NVME_SNTL_SUBMIT_FLUSH;
        result.nvmeOpcode = NVME_NVM_FLUSH;
        return result;
    case SNTL_OP_REPORT_LUNS:
        if (cdbLength < 12 || !requestIsRead)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        length = sntlMin(sntlGet32(cdb + 6), bufferLength);
        length = sntlMin(length, 16);
        if (length != 0 && buffer == 0)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        memset(data, 0, 16);
        sntlPut32(data, 8);
        if (length != 0)
            memcpy(buffer, data, length);
        return sntlComplete(length);
    case SNTL_OP_READ_DEFECT_DATA10:
        if (cdbLength < 10 || !requestIsRead)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        length = sntlMin(sntlGet16(cdb + 7), bufferLength);
        length = sntlMin(length, 4);
        if (length != 0 && buffer == 0)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        memset(data, 0, 4);
        data[1] = cdb[2] & 0x1f;
        if (length != 0)
            memcpy(buffer, data, length);
        return sntlComplete(length);
    case SNTL_OP_LOG_SENSE:
        if (cdbLength < 10 || !requestIsRead)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        if ((cdb[2] & 0x3f) == 0x2f) {
            length = sntlMin(sntlGet16(cdb + 7), bufferLength);
            if (length == 0)
                return sntlComplete(0);
            if (buffer == 0)
                return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                                 SNTL_ASC_INVALID_CDB_FIELD, 0);
            memset(&result, 0, sizeof(result));
            result.action = NVME_SNTL_SUBMIT_SMART;
            result.dataIn = 1;
            result.transferBytes = length;
            return result;
        }
        return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                         SNTL_ASC_INVALID_CDB_FIELD, 0);
    case SNTL_OP_VERIFY6:
    case SNTL_OP_VERIFY10:
    case SNTL_OP_VERIFY16:
        if (cdbLength < (opcode == SNTL_OP_VERIFY6 ? 6 :
                         (opcode == SNTL_OP_VERIFY10 ? 10 : 16)))
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        if ((cdb[1] & 0x06) == 0)
            return sntlComplete(0);
        return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                         SNTL_ASC_INVALID_CDB_FIELD, 0);
    default:
        return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                         SNTL_ASC_INVALID_OPCODE, 0);
    }
}

NVMeSNTLResult NVMeSNTLMapStatus(unsigned statusType,
                                 unsigned statusCode,
                                 int wasWrite)
{
    if (statusType == 0 && statusCode == 0)
        return sntlComplete(0);
    if (statusType == 0) {
        switch (statusCode) {
        case 0x01:
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_OPCODE, 0);
        case 0x02:
        case 0x0c:
        case 0x0d:
        case 0x0e:
        case 0x0f:
        case 0x10:
        case 0x11:
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        case 0x04:
            return sntlCheck(SNTL_SENSE_MEDIUM_ERROR, 0, 0);
        case 0x0b:
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_LUN, 0);
        case 0x07:
        case 0x08:
        case 0x05:
        case 0x09:
        case 0x0a:
            return sntlCheck(SNTL_SENSE_ABORTED_COMMAND,
                             SNTL_ASC_COMMAND_ABORTED, 0);
        case 0x80:
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_LBA_OUT_OF_RANGE, 0);
        case 0x81:
            return sntlCheck(SNTL_SENSE_MEDIUM_ERROR, 0, 0);
        case 0x82:
            return sntlCheck(SNTL_SENSE_NOT_READY,
                             SNTL_ASC_LUN_NOT_READY, 0);
        default:
            return sntlCheck(SNTL_SENSE_HARDWARE_ERROR,
                             SNTL_ASC_INTERNAL_FAILURE, 0);
        }
    }
    if (statusType == 1) {
        if (statusCode == 0x80)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        if (statusCode == 0x81)
            return sntlCheck(SNTL_SENSE_ILLEGAL_REQUEST,
                             SNTL_ASC_INVALID_CDB_FIELD, 0);
        if (statusCode == 0x82)
            return sntlCheck(SNTL_SENSE_DATA_PROTECT,
                             SNTL_ASC_WRITE_PROTECTED, 0);
    }
    if (statusType == 2) {
        if (statusCode == 0x80)
            return sntlCheck(SNTL_SENSE_MEDIUM_ERROR,
                             SNTL_ASC_WRITE_FAULT, 0);
        if (statusCode == 0x81)
            return sntlCheck(SNTL_SENSE_MEDIUM_ERROR,
                             SNTL_ASC_UNRECOVERED_READ, 0);
        return sntlCheck(SNTL_SENSE_MEDIUM_ERROR,
                         wasWrite ? SNTL_ASC_WRITE_ERROR :
                                    SNTL_ASC_UNRECOVERED_READ, 0);
    }
    return sntlCheck(SNTL_SENSE_HARDWARE_ERROR,
                     SNTL_ASC_INTERNAL_FAILURE, 0);
}

unsigned NVMeSNTLBuildSmartLog(void *buffer, unsigned bufferLength,
                               const unsigned char *smartLog)
{
    unsigned char data[12];
    unsigned kelvin;
    unsigned celsius;
    unsigned length;

    if (buffer == 0 || smartLog == 0)
        return 0;
    memset(data, 0, sizeof(data));
    data[0] = 0x2f;
    sntlPut16(data + 2, 8);
    data[6] = 0x23;
    data[7] = 4;
    kelvin = smartLog[1] | ((unsigned)smartLog[2] << 8);
    celsius = kelvin > 273 ? kelvin - 273 : 0;
    data[10] = (unsigned char)(celsius > 255 ? 255 : celsius);
    length = sntlMin(bufferLength, sizeof(data));
    memcpy(buffer, data, length);
    return length;
}
