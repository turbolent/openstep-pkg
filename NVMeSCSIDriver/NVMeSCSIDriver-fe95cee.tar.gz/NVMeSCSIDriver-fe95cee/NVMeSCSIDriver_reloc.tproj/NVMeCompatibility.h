#ifndef NVME_COMPATIBILITY_H
#define NVME_COMPATIBILITY_H

#include "NVMeRegs.h"

unsigned NVMeSelectQueueDepth(unsigned requested,
                              unsigned controllerEntries);
unsigned NVMeMaximumTransferForMDTS(unsigned mdts);
unsigned NVMeNamespaceBlockSize(unsigned metadataSize,
                                unsigned lbaDataSize);
int NVMeControllerNeedsPollingOnly(unsigned vendorId,
                                   unsigned deviceId);
int NVMePCIInterruptIsUsable(unsigned interruptLine);
int NVMeControllerUsesPollingOnly(unsigned vendorId,
                                  unsigned deviceId,
                                  unsigned interruptLine,
                                  int forcedPolling);

#endif
