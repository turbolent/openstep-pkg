#ifndef NVME_REGS_H
#define NVME_REGS_H

#define NVME_PAGE_SIZE             4096U
#define NVME_PAGE_MASK             (NVME_PAGE_SIZE - 1U)
#define NVME_PAGE_SHIFT            12U
#define NVME_MAX_QUEUE_DEPTH       64U
#define NVME_DEFAULT_PRP_PAGES     32U
#define NVME_MIN_PRP_PAGES         16U
#define NVME_MAX_TRANSFER          (2U * 1024U * 1024U)

#define NVME_REG_CAP               0x0000U
#define NVME_REG_VS                0x0008U
#define NVME_REG_INTMS             0x000cU
#define NVME_REG_INTMC             0x0010U
#define NVME_REG_CC                0x0014U
#define NVME_REG_CSTS              0x001cU
#define NVME_REG_AQA               0x0024U
#define NVME_REG_ASQ               0x0028U
#define NVME_REG_ACQ               0x0030U
#define NVME_REG_DOORBELL           0x1000U

#define NVME_CC_ENABLE             0x00000001U
#define NVME_CC_CSS_NVM            0x00000000U
#define NVME_CC_MPS_4K             0x00000000U
#define NVME_CC_AMS_RR             0x00000000U
#define NVME_CC_SHN_MASK           0x0000c000U
#define NVME_CC_SHN_NORMAL         0x00004000U
#define NVME_CC_IOSQES_64          0x00060000U
#define NVME_CC_IOCQES_16          0x00400000U

#define NVME_CSTS_READY            0x00000001U
#define NVME_CSTS_FATAL            0x00000002U
#define NVME_CSTS_SHST_MASK        0x0000000cU
#define NVME_CSTS_SHST_COMPLETE    0x00000008U

#define NVME_CAP_MQES(cap)         ((unsigned)((cap) & 0xffffULL) + 1U)
#define NVME_CAP_TIMEOUT(cap)      ((unsigned)(((cap) >> 24) & 0xffULL))
#define NVME_CAP_DSTRD(cap)        ((unsigned)(((cap) >> 32) & 0x0fULL))
#define NVME_CAP_CSS(cap)          ((unsigned)(((cap) >> 37) & 0xffULL))
#define NVME_CAP_MPSMIN(cap)       ((unsigned)(((cap) >> 48) & 0x0fULL))
#define NVME_CAP_MPSMAX(cap)       ((unsigned)(((cap) >> 52) & 0x0fULL))

#define NVME_ADMIN_DELETE_SQ       0x00U
#define NVME_ADMIN_CREATE_SQ       0x01U
#define NVME_ADMIN_GET_LOG_PAGE    0x02U
#define NVME_ADMIN_DELETE_CQ       0x04U
#define NVME_ADMIN_CREATE_CQ       0x05U
#define NVME_ADMIN_IDENTIFY        0x06U
#define NVME_ADMIN_SET_FEATURES    0x09U

#define NVME_NVM_FLUSH             0x00U
#define NVME_NVM_WRITE             0x01U
#define NVME_NVM_READ              0x02U
#define NVME_NVM_COMPARE           0x05U

#define NVME_IDENTIFY_NAMESPACE    0U
#define NVME_IDENTIFY_CONTROLLER   1U
#define NVME_LOG_SMART_HEALTH      2U
#define NVME_FEAT_NUMBER_OF_QUEUES 7U

#define NVME_CQ_PHYS_CONTIG        0x00000001U
#define NVME_CQ_IRQ_ENABLED        0x00000002U
#define NVME_SQ_PHYS_CONTIG        0x00000001U

#define NVME_NVM_CDW12_FUA         0x40000000U

typedef struct NVMeCommand {
    unsigned int cdw0;
    unsigned int nsid;
    unsigned int reserved2[2];
    unsigned long long mptr;
    unsigned long long prp1;
    unsigned long long prp2;
    unsigned int cdw10;
    unsigned int cdw11;
    unsigned int cdw12;
    unsigned int cdw13;
    unsigned int cdw14;
    unsigned int cdw15;
} NVMeCommand;

typedef struct NVMeCompletion {
    unsigned int result;
    unsigned int reserved;
    unsigned short sqHead;
    unsigned short sqId;
    unsigned short commandId;
    unsigned short status;
} NVMeCompletion;

#define NVME_CMD_DW0(opcode, cid) \
    (((unsigned int)(opcode) & 0xffU) | ((unsigned int)(cid) << 16))

#endif
