#ifndef NVME_VERSION_H
#define NVME_VERSION_H

#define NVME_DRIVER_VERSION "0.16"
#define NVME_DRIVER_NAME    "NVMeSCSIDriver"

#endif
