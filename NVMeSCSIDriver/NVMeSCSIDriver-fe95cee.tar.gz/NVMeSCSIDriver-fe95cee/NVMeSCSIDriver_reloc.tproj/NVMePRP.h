#ifndef NVME_PRP_H
#define NVME_PRP_H

#include "NVMeRegs.h"

typedef struct NVMePRPPlan {
    unsigned firstBytes;
    unsigned remainingPages;
    unsigned listEntries;
} NVMePRPPlan;

int NVMePRPPlanTransfer(unsigned firstPhysicalAddress,
                        unsigned transferBytes,
                        NVMePRPPlan *plan);

#endif
