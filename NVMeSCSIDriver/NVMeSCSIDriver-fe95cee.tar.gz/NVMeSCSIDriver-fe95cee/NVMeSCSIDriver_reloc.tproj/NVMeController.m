#import "NVMeSCSI.h"
#import "NVMePrivate.h"
#import "NVMeCompatibility.h"
#import <driverkit/generalFuncs.h>
#import <driverkit/kernelDriver.h>
#import <driverkit/i386/PCI.h>
#import <mach/mach_interface.h>
#import <mach/mach_traps.h>
#import <string.h>

#define PCI_COMMAND_MEMORY       0x0002U
#define PCI_COMMAND_MASTER       0x0004U
#define PCI_COMMAND_INT_DISABLE  0x0400U
#define PCI_BAR_IO               0x00000001U
#define PCI_BAR_TYPE_MASK        0x00000006U
#define PCI_BAR_TYPE_64          0x00000004U
#define PCI_BAR_MEMORY_MASK      0xfffffff0U

static unsigned getDecimal(const char *string)
{
    unsigned value = 0;
    while (string != 0 && *string >= '0' && *string <= '9') {
        value = value * 10 + (*string - '0');
        string++;
    }
    return value;
}

static unsigned loadLE16(const unsigned char *p)
{
    return p[0] | ((unsigned)p[1] << 8);
}

static unsigned loadLE32(const unsigned char *p)
{
    return p[0] | ((unsigned)p[1] << 8) |
           ((unsigned)p[2] << 16) | ((unsigned)p[3] << 24);
}

static unsigned long long loadLE64(const unsigned char *p)
{
    return (unsigned long long)loadLE32(p) |
           ((unsigned long long)loadLE32(p + 4) << 32);
}

static void copyIdentifyString(char *destination, unsigned destinationLength,
                               const unsigned char *source,
                               unsigned sourceLength)
{
    unsigned length = sourceLength;
    unsigned i;
    while (length != 0 && (source[length - 1] == ' ' ||
                           source[length - 1] == 0))
        length--;
    if (length >= destinationLength)
        length = destinationLength - 1;
    for (i = 0; i < length; i++)
        destination[i] = (char)source[i];
    destination[length] = 0;
}

static int determineBAR(id deviceDescription, IOPCIConfigSpace *config,
                        unsigned *address, unsigned *length)
{
    unsigned long commandData;
    unsigned long low;
    unsigned long high;
    unsigned long maskLow;
    unsigned long maskHigh;
    unsigned long long mask;
    unsigned long long size;
    int is64;
    int barWritten;
    int valid;
    IOReturn result;

    low = config->BaseAddress[0];
    if (low == 0) {
        IOLog("NVMeSCSIDriver: PCI BAR0 is not assigned\n");
        return 0;
    }
    if ((low & PCI_BAR_IO) != 0) {
        IOLog("NVMeSCSIDriver: PCI BAR0 is an I/O BAR, not memory\n");
        return 0;
    }
    is64 = (low & PCI_BAR_TYPE_MASK) == PCI_BAR_TYPE_64;
    high = is64 ? config->BaseAddress[1] : 0;
    if (high != 0) {
        IOLog("NVMeSCSIDriver: PCI BAR0 is assigned above 4 GB\n");
        return 0;
    }

    result = [IODirectDevice getPCIConfigData:&commandData
                                   atRegister:0x04
                        withDeviceDescription:deviceDescription];
    if (result != IO_R_SUCCESS) {
        IOLog("NVMeSCSIDriver: cannot read PCI command register (%d)\n",
              result);
        return 0;
    }
    result = [IODirectDevice setPCIConfigData:
                               (commandData & 0xffffU) &
                               ~(PCI_COMMAND_MEMORY | PCI_COMMAND_MASTER)
                                  atRegister:0x04
                       withDeviceDescription:deviceDescription];
    if (result != IO_R_SUCCESS) {
        IOLog("NVMeSCSIDriver: cannot disable PCI decoding for BAR probe "
              "(%d)\n", result);
        return 0;
    }

    barWritten = 0;
    valid = 0;
    result = [IODirectDevice setPCIConfigData:0xffffffffU
                                  atRegister:0x10
                       withDeviceDescription:deviceDescription];
    if (result != IO_R_SUCCESS) {
        IOLog("NVMeSCSIDriver: cannot size PCI BAR0 (%d)\n", result);
        goto restoreCommand;
    }
    barWritten = 1;
    if (is64 &&
        (result = [IODirectDevice setPCIConfigData:0xffffffffU
                                      atRegister:0x14
                           withDeviceDescription:deviceDescription]) !=
        IO_R_SUCCESS) {
        IOLog("NVMeSCSIDriver: cannot size upper PCI BAR0 (%d)\n", result);
        goto restoreBAR;
    }
    result = [IODirectDevice getPCIConfigData:&maskLow
                                  atRegister:0x10
                       withDeviceDescription:deviceDescription];
    if (result != IO_R_SUCCESS) {
        IOLog("NVMeSCSIDriver: cannot read PCI BAR0 size (%d)\n", result);
        goto restoreBAR;
    }
    if (is64) {
        result = [IODirectDevice getPCIConfigData:&maskHigh
                                       atRegister:0x14
                            withDeviceDescription:deviceDescription];
        if (result != IO_R_SUCCESS) {
            IOLog("NVMeSCSIDriver: cannot read upper PCI BAR0 size (%d)\n",
                  result);
            goto restoreBAR;
        }
    } else {
        maskHigh = 0xffffffffU;
    }
    valid = 1;

restoreBAR:
    if (barWritten) {
        if ([IODirectDevice setPCIConfigData:low
                                  atRegister:0x10
                       withDeviceDescription:deviceDescription] !=
            IO_R_SUCCESS) {
            IOLog("NVMeSCSIDriver: cannot restore PCI BAR0\n");
            valid = 0;
        }
        if (is64 &&
            [IODirectDevice setPCIConfigData:high
                                  atRegister:0x14
                       withDeviceDescription:deviceDescription] !=
            IO_R_SUCCESS) {
            IOLog("NVMeSCSIDriver: cannot restore upper PCI BAR0\n");
            valid = 0;
        }
    }
restoreCommand:
    if ([IODirectDevice setPCIConfigData:commandData & 0xffffU
                              atRegister:0x04
                   withDeviceDescription:deviceDescription] != IO_R_SUCCESS) {
        IOLog("NVMeSCSIDriver: cannot restore PCI command register\n");
        valid = 0;
    }
    if (!valid)
        return 0;

    mask = ((unsigned long long)maskHigh << 32) |
           (maskLow & PCI_BAR_MEMORY_MASK);
    size = (~mask) + 1ULL;
    if (size == 0 || size > 0xffffffffULL) {
        IOLog("NVMeSCSIDriver: PCI BAR0 reports an invalid size\n");
        return 0;
    }
    *address = (unsigned)(low & PCI_BAR_MEMORY_MASK);
    *length = (unsigned)size;
    return *address != 0;
}

@implementation NVMeSCSI (Private)

- initializeFromDeviceDescription:deviceDescription
{
    IOPCIConfigSpace config;
    IORange memoryRange;
    unsigned interrupt;
    unsigned long commandData;
    unsigned requiredRegisters;
    unsigned lun;
    const char *value;
    const char *completionMode;
    id configTable;
    IOReturn result;
    int forceInterruptQualification;
    int forcePollingOnly;

    bzero(&config, sizeof(config));
    result = [IODirectDevice getPCIConfigSpace:&config
                         withDeviceDescription:deviceDescription];
    if (result != IO_R_SUCCESS) {
        IOLog("NVMeSCSIDriver: cannot read PCI configuration (%d)\n", result);
        return [self free];
    }
    if (config.ClassCode != 0x010802U) {
        IOLog("NVMeSCSIDriver: PCI class %06x is not NVMe 010802\n",
              config.ClassCode);
        return [self free];
    }
    if (!determineBAR(deviceDescription, &config,
                      &barPhysicalAddress, &registerLength)) {
        IOLog("NVMeSCSIDriver: BAR0 is absent, invalid, or above 4 GB\n");
        return [self free];
    }
    configTable = [deviceDescription configTable];
    forcePollingOnly = 0;
    value = [configTable valueForStringKey:"Polling Only"];
    if (value != 0) {
        forcePollingOnly = strcmp(value, "YES") == 0;
        [configTable freeString:value];
    }
    forceInterruptQualification = 0;
    value = [configTable valueForStringKey:"INTx Qualification"];
    if (value != 0) {
        forceInterruptQualification = strcmp(value, "YES") == 0;
        [configTable freeString:value];
    }
    interrupt = config.InterruptLine;
    completionPollingOnly = NVMeControllerUsesPollingOnly(
                                config.VendorID, config.DeviceID,
                                interrupt, forcePollingOnly);
    [deviceDescription getPCIdevice:&deviceNumber function:&functionNumber
                                bus:&busNumber];
    memoryRange.start = barPhysicalAddress;
    memoryRange.size = registerLength;
    result = [deviceDescription setMemoryRangeList:&memoryRange num:1];
    if (result != IO_R_SUCCESS) {
        IOLog("NVMeSCSIDriver: cannot claim BAR0 memory range (%d)\n",
              result);
        return [self free];
    }
    if (!completionPollingOnly) {
        result = [deviceDescription setInterruptList:&interrupt num:1];
        if (result != IO_R_SUCCESS) {
            IOLog("NVMeSCSIDriver: cannot claim legacy PCI IRQ %u (%d); "
                  "using polling\n", interrupt, result);
            completionPollingOnly = 1;
        }
    }
    interruptQualificationMode =
        forceInterruptQualification && !completionPollingOnly;

    queue_init(&commandQueue);
    queue_init(&pendingQueue);
    commandLock = [[NXLock alloc] init];
    if (commandLock == nil) {
        IOLog("NVMeSCSIDriver: cannot allocate command lock\n");
        return [self free];
    }
    if ([super initFromDeviceDescription:deviceDescription] == nil) {
        IOLog("NVMeSCSIDriver: DriverKit device initialization failed\n");
        return [self free];
    }
    interruptPortKern = IOConvertPort([self interruptPort],
                                      IO_KernelIOTask, IO_Kernel);
    port_set_backlog(task_self(), [self interruptPort], PORT_BACKLOG_MAX);
    ioThreadRunning = 1;

    result = [self mapMemoryRange:0 to:&registers findSpace:YES
                           cache:IO_CacheOff];
    if (result != IO_R_SUCCESS) {
        IOLog("NVMeSCSIDriver: cannot map BAR0 (%d)\n", result);
        return [self free];
    }
    result = [self getPCIConfigData:&commandData atRegister:0x04];
    if (result != IO_R_SUCCESS) {
        IOLog("NVMeSCSIDriver: cannot read live PCI command register (%d)\n",
              result);
        return [self free];
    }
    commandData = (commandData & 0xffffU) | PCI_COMMAND_MEMORY |
                  PCI_COMMAND_MASTER;
    if (completionPollingOnly)
        commandData |= PCI_COMMAND_INT_DISABLE;
    else
        commandData &= ~PCI_COMMAND_INT_DISABLE;
    result = [self setPCIConfigData:commandData atRegister:0x04];
    if (result != IO_R_SUCCESS) {
        IOLog("NVMeSCSIDriver: cannot enable PCI memory/bus master (%d)\n",
              result);
        return [self free];
    }

    capabilities = [self readRegister64:NVME_REG_CAP];
    controllerVersion = [self readRegister32:NVME_REG_VS];
    if ((NVME_CAP_CSS(capabilities) & 1U) == 0 ||
        NVME_CAP_MPSMIN(capabilities) > 0) {
        IOLog("NVMeSCSIDriver: unsupported CAP.CSS 0x%02x or MPSMIN %u\n",
              NVME_CAP_CSS(capabilities), NVME_CAP_MPSMIN(capabilities));
        return [self free];
    }
    doorbellStride = 4U << NVME_CAP_DSTRD(capabilities);
    requiredRegisters = NVME_REG_DOORBELL + 3U * doorbellStride + 4U;
    if (requiredRegisters > registerLength) {
        IOLog("NVMeSCSIDriver: BAR0 has %u bytes, needs %u for queue "
              "doorbells\n", registerLength, requiredRegisters);
        return [self free];
    }

    configuredQueueDepth = NVME_MAX_QUEUE_DEPTH;
    configuredPRPPages = NVME_DEFAULT_PRP_PAGES;
    faultTimeoutAfter = 0;
    faultTimeoutSeconds = 2;
    value = [configTable valueForStringKey:"Queue Depth"];
    if (value != 0) {
        unsigned requested = getDecimal(value);
        if (requested >= 2 && requested <= NVME_MAX_QUEUE_DEPTH)
            configuredQueueDepth = requested;
        [configTable freeString:value];
    }
    configuredQueueDepth = NVMeSelectQueueDepth(
        configuredQueueDepth, NVME_CAP_MQES(capabilities));
    if (configuredQueueDepth == 0) {
        IOLog("NVMeSCSIDriver: controller exposes only %u queue entries\n",
              NVME_CAP_MQES(capabilities));
        return [self free];
    }
    value = [configTable valueForStringKey:"PRP Pages"];
    if (value != 0) {
        unsigned requested = getDecimal(value);
        if (requested >= NVME_MIN_PRP_PAGES &&
            requested <= NVME_DEFAULT_PRP_PAGES)
            configuredPRPPages = requested;
        [configTable freeString:value];
    }
    value = [configTable valueForStringKey:"Test Timeout After"];
    if (value != 0) {
        faultTimeoutAfter = getDecimal(value);
        [configTable freeString:value];
    }
    value = [configTable valueForStringKey:"Test Timeout Seconds"];
    if (value != 0) {
        unsigned requested = getDecimal(value);
        if (requested >= 1U && requested <= 30U)
            faultTimeoutSeconds = requested;
        [configTable freeString:value];
    }

    if (![self allocateControllerMemory]) {
        IOLog("NVMeSCSIDriver: controller DMA allocation failed\n");
        return [self free];
    }
    if (![self initializeController]) {
        IOLog("NVMeSCSIDriver: controller initialization failed, "
              "CSTS=0x%08x\n", [self readRegister32:NVME_REG_CSTS]);
        return [self free];
    }

    if (![self startPollingThread]) {
        IOLog("NVMeSCSIDriver: fast completion poller unavailable\n");
        return [self free];
    }
    if (completionPollingOnly) {
        [self writeRegister32:NVME_REG_INTMS value:0xffffffffU];
        completionMode = "polling only";
    } else {
        [self enableInterruptDelivery];
        completionMode = completionPollingOnly ? "polling only" :
                         "legacy INTx with polling fallback";
    }

    for (lun = 0; lun < SCSI_NLUNS; lun++)
        [self reserveTarget:7 lun:lun forOwner:self];

    IOLog("%s %s: %s, %u MB, %u-byte blocks, queue %u, %s\n",
          NVME_DRIVER_NAME, NVME_DRIVER_VERSION, sntlDevice.model,
          (unsigned)((sntlDevice.namespaceBlocks * sntlDevice.blockSize) >> 20),
          sntlDevice.blockSize,
          ioQueue.depth, completionMode);
    IOLog("%s: PCI %04x:%04x at Bus:%u Dev:%u Func:%u, NVMe %u.%u.%u\n",
          [self name], config.VendorID, config.DeviceID, busNumber,
          deviceNumber, functionNumber, controllerVersion >> 16,
          (controllerVersion >> 8) & 0xffU, controllerVersion & 0xffU);
    if (faultTimeoutAfter != 0)
        IOLog("%s: test timeout armed after submission %u (%u seconds)\n",
              [self name], faultTimeoutAfter, faultTimeoutSeconds);
    [self registerDevice];
    return self;
}

- (int)allocatePage:(NVMePage *)page length:(unsigned)length
{
    vm_address_t aligned;
    unsigned physical;
    bzero(page, sizeof(*page));
    page->allocationLength = length + NVME_PAGE_SIZE;
    page->allocation = IOMalloc(page->allocationLength);
    if (page->allocation == 0) {
        IOLog("NVMeSCSIDriver: cannot allocate %u-byte DMA region\n",
              page->allocationLength);
        return 0;
    }
    aligned = ((vm_address_t)page->allocation + NVME_PAGE_MASK) &
              ~NVME_PAGE_MASK;
    if (IOPhysicalFromVirtual(IOVmTaskSelf(), aligned, &physical) !=
        IO_R_SUCCESS) {
        IOFree(page->allocation, page->allocationLength);
        bzero(page, sizeof(*page));
        IOLog("NVMeSCSIDriver: cannot translate DMA page to physical "
              "memory\n");
        return 0;
    }
    page->virtualAddress = (void *)aligned;
    page->physicalAddress = physical;
    bzero(page->virtualAddress, length);
    return 1;
}

- (void)freePage:(NVMePage *)page
{
    if (page->allocation != 0)
        IOFree(page->allocation, page->allocationLength);
    bzero(page, sizeof(*page));
}

- (int)allocateControllerMemory
{
    unsigned i;
    adminQueue.queueId = 0;
    adminQueue.depth = configuredQueueDepth;
    ioQueue.queueId = 1;
    ioQueue.depth = configuredQueueDepth;

    if (![self allocatePage:&adminQueue.submission
                      length:adminQueue.depth * sizeof(NVMeCommand)] ||
        ![self allocatePage:&adminQueue.completion
                      length:adminQueue.depth * sizeof(NVMeCompletion)] ||
        ![self allocatePage:&ioQueue.submission
                      length:ioQueue.depth * sizeof(NVMeCommand)] ||
        ![self allocatePage:&ioQueue.completion
                      length:ioQueue.depth * sizeof(NVMeCompletion)] ||
        ![self allocatePage:&identifyPage length:NVME_PAGE_SIZE])
        return 0;

    for (i = 0; i < configuredPRPPages; i++) {
        if (![self allocatePage:&prpPages[i] length:NVME_PAGE_SIZE])
            break;
    }
    prpPageCount = i;
    if (prpPageCount < NVME_MIN_PRP_PAGES) {
        IOLog("NVMeSCSIDriver: fewer than %u PRP pages available\n",
              NVME_MIN_PRP_PAGES);
        return 0;
    }
    prpBitmap = 0;
    return 1;
}

- (void)freeControllerMemory
{
    unsigned i;
    [self freePage:&adminQueue.submission];
    [self freePage:&adminQueue.completion];
    [self freePage:&ioQueue.submission];
    [self freePage:&ioQueue.completion];
    [self freePage:&identifyPage];
    for (i = 0; i < NVME_DEFAULT_PRP_PAGES; i++)
        [self freePage:&prpPages[i]];
    prpPageCount = 0;
    prpBitmap = 0;
}

- (unsigned)readRegister32:(unsigned)offset
{
    volatile unsigned *address;
    address = (volatile unsigned *)(registers + offset);
    return *address;
}

- (unsigned long long)readRegister64:(unsigned)offset
{
    unsigned low;
    unsigned high;
    low = [self readRegister32:offset];
    high = [self readRegister32:offset + 4];
    return (unsigned long long)low | ((unsigned long long)high << 32);
}

- (void)writeRegister32:(unsigned)offset value:(unsigned)value
{
    volatile unsigned *address;
    address = (volatile unsigned *)(registers + offset);
    *address = value;
}

- (void)writeRegister64:(unsigned)offset value:(unsigned long long)value
{
    [self writeRegister32:offset value:(unsigned)value];
    [self writeRegister32:offset + 4 value:(unsigned)(value >> 32)];
}

- (void)ringSubmissionDoorbell:(NVMeQueue *)queue
{
    unsigned offset = NVME_REG_DOORBELL +
                      (2U * queue->queueId) * doorbellStride;
    [self writeRegister32:offset value:queue->submissionTail];
}

- (void)ringCompletionDoorbell:(NVMeQueue *)queue
{
    unsigned offset = NVME_REG_DOORBELL +
                      (2U * queue->queueId + 1U) * doorbellStride;
    [self writeRegister32:offset value:queue->completionHead];
}

- (int)enableInterruptDelivery
{
    IOReturn result;

    if (completionPollingOnly)
        return 0;
    result = [self enableAllInterrupts];
    if (result == IO_R_SUCCESS) {
        [self writeRegister32:NVME_REG_INTMC value:0xffffffffU];
        return 1;
    }
    [self writeRegister32:NVME_REG_INTMS value:0xffffffffU];
    completionPollingOnly = 1;
    interruptQualificationMode = 0;
    IOLog("%s: cannot enable legacy INTx delivery (%d); using polling\n",
          [self name], result);
    return 0;
}

- (int)setBusMasterEnabled:(int)enabled
{
    unsigned long commandData;
    IOReturn result;

    result = [self getPCIConfigData:&commandData atRegister:0x04];
    if (result != IO_R_SUCCESS) {
        IOLog("%s: cannot read PCI command register (%d)\n",
              [self name], result);
        return 0;
    }
    commandData &= 0xffffU;
    if (enabled) {
        commandData |= PCI_COMMAND_MEMORY | PCI_COMMAND_MASTER;
        if (completionPollingOnly)
            commandData |= PCI_COMMAND_INT_DISABLE;
        else
            commandData &= ~PCI_COMMAND_INT_DISABLE;
    } else {
        commandData &= ~PCI_COMMAND_MASTER;
        commandData |= PCI_COMMAND_INT_DISABLE;
    }
    result = [self setPCIConfigData:commandData atRegister:0x04];
    if (result != IO_R_SUCCESS) {
        IOLog("%s: cannot %s PCI bus mastering (%d)\n", [self name],
              enabled ? "enable" : "disable", result);
        return 0;
    }
    return 1;
}

- (int)waitForReady:(int)ready
{
    unsigned timeout;
    unsigned elapsed;
    int state;
    timeout = NVME_CAP_TIMEOUT(capabilities);
    timeout = timeout == 0 ? 5000 : timeout * 500;
    if (timeout < 5000)
        timeout = 5000;
    for (elapsed = 0; elapsed < timeout; elapsed++) {
        unsigned status = [self readRegister32:NVME_REG_CSTS];
        state = NVMeRecoveryReadyState(status, ready);
        if (state == NVME_READY_REACHED)
            return 1;
        if (state == NVME_READY_FATAL) {
            IOLog("%s: controller fatal while waiting for RDY=%u, "
                  "CSTS=0x%08x\n", [self name], ready, status);
            return 0;
        }
        IODelay(1000);
    }
    IOLog("%s: timed out waiting for RDY=%u, CSTS=0x%08x\n",
          [self name], ready, [self readRegister32:NVME_REG_CSTS]);
    return 0;
}

- (int)initializeController
{
    NVMeCommand command;
    unsigned aqa;
    unsigned cc;
    unsigned char *identify;
    unsigned lbaFormat;
    unsigned lbaDataSize;
    unsigned metadataSize;
    unsigned mdts;
    unsigned blockSize;

    controllerReady = 0;
    [self writeRegister32:NVME_REG_INTMS value:0xffffffffU];
    cc = [self readRegister32:NVME_REG_CC];
    cc &= ~(NVME_CC_ENABLE | NVME_CC_SHN_MASK);
    [self writeRegister32:NVME_REG_CC value:cc];
    if (![self waitForReady:0])
        return 0;
    [self writeRegister32:NVME_REG_INTMS value:0xffffffffU];

    bzero(adminQueue.submission.virtualAddress,
          adminQueue.depth * sizeof(NVMeCommand));
    bzero(adminQueue.completion.virtualAddress,
          adminQueue.depth * sizeof(NVMeCompletion));
    bzero(ioQueue.submission.virtualAddress,
          ioQueue.depth * sizeof(NVMeCommand));
    bzero(ioQueue.completion.virtualAddress,
          ioQueue.depth * sizeof(NVMeCompletion));
    adminQueue.submissionHead = adminQueue.submissionTail = 0;
    adminQueue.completionHead = 0;
    adminQueue.completionPhase = 1;
    ioQueue.submissionHead = ioQueue.submissionTail = 0;
    ioQueue.completionHead = 0;
    ioQueue.completionPhase = 1;
    bzero(ioSlots, sizeof(ioSlots));
    adminActive = 0;
    activeCommands = 0;
    barrierActive = 0;
    serializedActive = 0;
    prpBitmap = 0;

    aqa = ((adminQueue.depth - 1U) << 16) |
          (adminQueue.depth - 1U);
    [self writeRegister32:NVME_REG_AQA value:aqa];
    [self writeRegister64:NVME_REG_ASQ
                    value:adminQueue.submission.physicalAddress];
    [self writeRegister64:NVME_REG_ACQ
                    value:adminQueue.completion.physicalAddress];
    cc = NVME_CC_ENABLE | NVME_CC_CSS_NVM | NVME_CC_MPS_4K |
         NVME_CC_AMS_RR | NVME_CC_IOSQES_64 | NVME_CC_IOCQES_16;
    [self writeRegister32:NVME_REG_CC value:cc];
    if (![self waitForReady:1])
        return 0;

    bzero(&command, sizeof(command));
    command.cdw0 = NVME_ADMIN_SET_FEATURES;
    command.cdw10 = NVME_FEAT_NUMBER_OF_QUEUES;
    command.cdw11 = 0;
    if (![self submitAdminCommand:&command commandId:1])
        return 0;

    bzero(&command, sizeof(command));
    command.cdw0 = NVME_ADMIN_CREATE_CQ;
    command.prp1 = ioQueue.completion.physicalAddress;
    command.cdw10 = ((ioQueue.depth - 1U) << 16) | 1U;
    command.cdw11 = NVME_CQ_PHYS_CONTIG;
    if (!completionPollingOnly)
        command.cdw11 |= NVME_CQ_IRQ_ENABLED;
    if (![self submitAdminCommand:&command commandId:2])
        return 0;

    bzero(&command, sizeof(command));
    command.cdw0 = NVME_ADMIN_CREATE_SQ;
    command.prp1 = ioQueue.submission.physicalAddress;
    command.cdw10 = ((ioQueue.depth - 1U) << 16) | 1U;
    command.cdw11 = NVME_SQ_PHYS_CONTIG | (1U << 16);
    if (![self submitAdminCommand:&command commandId:3])
        return 0;

    bzero(identifyPage.virtualAddress, NVME_PAGE_SIZE);
    bzero(&command, sizeof(command));
    command.cdw0 = NVME_ADMIN_IDENTIFY;
    command.prp1 = identifyPage.physicalAddress;
    command.cdw10 = NVME_IDENTIFY_CONTROLLER;
    if (![self submitAdminCommand:&command commandId:4])
        return 0;
    identify = (unsigned char *)identifyPage.virtualAddress;
    copyIdentifyString(sntlDevice.serial, sizeof(sntlDevice.serial),
                       identify + 4, 20);
    copyIdentifyString(sntlDevice.model, sizeof(sntlDevice.model),
                       identify + 24, 40);
    copyIdentifyString(sntlDevice.firmware, sizeof(sntlDevice.firmware),
                       identify + 64, 8);
    mdts = identify[77];
    sntlDevice.compareSupported = (loadLE16(identify + 520) & 1U) != 0;
    sntlDevice.volatileWriteCache = (identify[525] & 1U) != 0;
    if (loadLE32(identify + 516) < 1) {
        IOLog("NVMeSCSIDriver: controller has no namespaces\n");
        return 0;
    }
    maximumTransfer = NVMeMaximumTransferForMDTS(mdts);

    bzero(identifyPage.virtualAddress, NVME_PAGE_SIZE);
    bzero(&command, sizeof(command));
    command.cdw0 = NVME_ADMIN_IDENTIFY;
    command.nsid = 1;
    command.prp1 = identifyPage.physicalAddress;
    command.cdw10 = NVME_IDENTIFY_NAMESPACE;
    if (![self submitAdminCommand:&command commandId:5])
        return 0;
    identify = (unsigned char *)identifyPage.virtualAddress;
    sntlDevice.namespaceBlocks = loadLE64(identify);
    lbaFormat = identify[26] & 0x0f;
    metadataSize = loadLE16(identify + 128 + lbaFormat * 4);
    lbaDataSize = identify[130 + lbaFormat * 4];
    blockSize = NVMeNamespaceBlockSize(metadataSize, lbaDataSize);
    if (sntlDevice.namespaceBlocks == 0 || blockSize == 0) {
        IOLog("NVMeSCSIDriver: namespace 1 format %u unsupported "
              "(metadata %u, LBA shift %u)\n",
              lbaFormat, metadataSize, lbaDataSize);
        return 0;
    }
    sntlDevice.blockSize = blockSize;
    sntlDevice.maxTransfer = maximumTransfer;
    bcopy(identify + 104, sntlDevice.nguid, 16);
    bcopy(identify + 120, sntlDevice.eui64, 8);
    NVMeSNTLSetSense(lastSense, SNTL_SENSE_NO_SENSE, 0, 0);

    controllerReady = 1;
    [self writeRegister32:NVME_REG_INTMS value:0xffffffffU];
    return 1;
}

- (int)resetController
{
    int result;

    controllerReady = 0;
    if (![self setBusMasterEnabled:1])
        return 0;
    result = [self initializeController];
    if (result) {
        if (completionPollingOnly) {
            [self writeRegister32:NVME_REG_INTMS value:0xffffffffU];
        } else {
            [self enableInterruptDelivery];
        }
    } else {
        IOLog("%s: controller reset failed, CSTS=0x%08x\n",
              [self name], [self readRegister32:NVME_REG_CSTS]);
        [self shutdownController];
    }
    return result;
}

- (int)quiesceController
{
    unsigned cc;

    controllerReady = 0;
    [self writeRegister32:NVME_REG_INTMS value:0xffffffffU];
    [self disableAllInterrupts];
    cc = [self readRegister32:NVME_REG_CC];
    cc &= ~(NVME_CC_ENABLE | NVME_CC_SHN_MASK);
    [self writeRegister32:NVME_REG_CC value:cc];
    if ([self waitForReady:0])
        return NVME_QUIESCE_STOPPED;

    IOLog("%s: controller did not quiesce; fencing PCI bus mastering\n",
          [self name]);
    if ([self setBusMasterEnabled:0])
        return NVME_QUIESCE_DMA_FENCED;
    IOLog("%s: DMA could not be stopped; preserving active requests and "
          "DMA memory\n", [self name]);
    return 0;
}

- (int)shutdownController
{
    unsigned cc;
    unsigned status;
    unsigned elapsed;

    controllerReady = 0;
    if (registers == 0)
        return 1;
    [self writeRegister32:NVME_REG_INTMS value:0xffffffffU];
    cc = [self readRegister32:NVME_REG_CC];
    status = [self readRegister32:NVME_REG_CSTS];
    if ((cc & NVME_CC_ENABLE) != 0 ||
        (status & NVME_CSTS_READY) != 0) {
        if ((status & NVME_CSTS_READY) != 0 &&
            (status & NVME_CSTS_FATAL) == 0) {
            cc = (cc & ~NVME_CC_SHN_MASK) | NVME_CC_SHN_NORMAL;
            [self writeRegister32:NVME_REG_CC value:cc];
            for (elapsed = 0; elapsed < 5000; elapsed++) {
                status = [self readRegister32:NVME_REG_CSTS];
                if ((status & NVME_CSTS_SHST_MASK) ==
                    NVME_CSTS_SHST_COMPLETE)
                    break;
                IODelay(1000);
            }
        }
        cc = [self readRegister32:NVME_REG_CC];
        cc &= ~(NVME_CC_ENABLE | NVME_CC_SHN_MASK);
        [self writeRegister32:NVME_REG_CC value:cc];
        if (![self waitForReady:0]) {
            [self writeRegister32:NVME_REG_INTMS value:0xffffffffU];
            IOLog("%s: controller failed to stop, CSTS=0x%08x\n",
                  [self name], [self readRegister32:NVME_REG_CSTS]);
            if ([self setBusMasterEnabled:0]) {
                IOLog("%s: PCI bus mastering fenced after shutdown "
                      "failure\n", [self name]);
                return 1;
            }
            return 0;
        }
    }
    [self writeRegister32:NVME_REG_INTMS value:0xffffffffU];
    [self writeRegister32:NVME_REG_AQA value:0];
    [self writeRegister64:NVME_REG_ASQ value:0];
    [self writeRegister64:NVME_REG_ACQ value:0];
    return 1;
}

- (int)submitAdminCommand:(NVMeCommand *)command
               commandId:(unsigned short)commandId
{
    NVMeCommand *entry;
    volatile NVMeCompletion *completion;
    unsigned short nextTail;
    unsigned elapsed;
    unsigned short status;
    unsigned short completedId;
    unsigned opcode;

    opcode = command->cdw0 & 0xffU;
    nextTail = (adminQueue.submissionTail + 1U) &
               (adminQueue.depth - 1U);
    if (nextTail == adminQueue.submissionHead)
        return 0;
    command->cdw0 = (command->cdw0 & 0xffffU) |
                    ((unsigned)commandId << 16);
    entry = (NVMeCommand *)adminQueue.submission.virtualAddress +
            adminQueue.submissionTail;
    *entry = *command;
    adminQueue.submissionTail = nextTail;
    [self ringSubmissionDoorbell:&adminQueue];

    for (elapsed = 0; elapsed < 5000; elapsed++) {
        completion = (volatile NVMeCompletion *)
                     adminQueue.completion.virtualAddress +
                     adminQueue.completionHead;
        if ((completion->status & 1U) == adminQueue.completionPhase) {
            status = completion->status;
            completedId = completion->commandId;
            adminQueue.submissionHead = completion->sqHead;
            adminQueue.completionHead++;
            if (adminQueue.completionHead == adminQueue.depth) {
                adminQueue.completionHead = 0;
                adminQueue.completionPhase ^= 1;
            }
            [self ringCompletionDoorbell:&adminQueue];
            if (completedId != commandId) {
                IOLog("%s: admin opcode 0x%02x expected CID %u, got %u\n",
                      [self name], opcode, commandId, completedId);
                return 0;
            }
            if (((status >> 1) & 0x7ffU) != 0) {
                IOLog("%s: admin opcode 0x%02x CID %u failed, "
                      "SCT %u SC 0x%02x\n",
                      [self name], opcode, commandId,
                      (status >> 9) & 7U, (status >> 1) & 0xffU);
                return 0;
            }
            return 1;
        }
        IODelay(1000);
    }
    IOLog("%s: admin opcode 0x%02x CID %u timed out\n",
          [self name], opcode, commandId);
    return 0;
}

- (int)allocatePRPPage
{
    unsigned i;
    for (i = 0; i < prpPageCount; i++) {
        if ((prpBitmap & (1U << i)) == 0) {
            prpBitmap |= 1U << i;
            bzero(prpPages[i].virtualAddress, NVME_PAGE_SIZE);
            return (int)i;
        }
    }
    return -1;
}

- (void)freePRPPage:(int)pageIndex
{
    if (pageIndex >= 0 && (unsigned)pageIndex < prpPageCount)
        prpBitmap &= ~(1U << pageIndex);
}

- (int)buildPRPsForCommand:(NVMeCommandBuffer *)command
                nvmeCommand:(NVMeCommand *)nvmeCommand
{
    vm_address_t virtualAddress;
    vm_address_t current;
    unsigned physical;
    unsigned index;
    unsigned long long *list;
    NVMePRPPlan plan;

    if (command->translation.transferBytes == 0)
        return 1;
    virtualAddress = (vm_address_t)command->buffer;
    if (IOPhysicalFromVirtual(command->client, virtualAddress, &physical) !=
        IO_R_SUCCESS)
        return -1;
    if (!NVMePRPPlanTransfer(physical,
                             command->translation.transferBytes, &plan))
        return -1;
    nvmeCommand->prp1 = physical;
    if (plan.remainingPages == 0)
        return 1;

    current = virtualAddress + plan.firstBytes;
    if (IOPhysicalFromVirtual(command->client, current, &physical) !=
        IO_R_SUCCESS || (physical & NVME_PAGE_MASK) != 0)
        return -1;
    if (plan.remainingPages == 1U) {
        nvmeCommand->prp2 = physical;
        return 1;
    }

    command->prpPage = [self allocatePRPPage];
    if (command->prpPage < 0)
        return 0;
    list = (unsigned long long *)
           prpPages[command->prpPage].virtualAddress;
    nvmeCommand->prp2 = prpPages[command->prpPage].physicalAddress;
    for (index = 0; index < plan.listEntries; index++) {
        if (index != 0 &&
            IOPhysicalFromVirtual(command->client, current, &physical) !=
                IO_R_SUCCESS) {
            [self freePRPPage:command->prpPage];
            command->prpPage = -1;
            return -1;
        }
        if ((physical & NVME_PAGE_MASK) != 0) {
            [self freePRPPage:command->prpPage];
            command->prpPage = -1;
            return -1;
        }
        list[index] = physical;
        current += NVME_PAGE_SIZE;
    }
    return 1;
}

- (int)submitIOCommand:(NVMeCommandBuffer *)command
{
    NVMeCommand nvmeCommand;
    NVMeCommand *entry;
    unsigned short nextTail;
    unsigned i;
    int prpResult;

    if (command->translation.action == NVME_SNTL_SUBMIT_SMART) {
        if (adminActive != 0)
            return 0;
        nextTail = (adminQueue.submissionTail + 1U) &
                   (adminQueue.depth - 1U);
        if (nextTail == adminQueue.submissionHead)
            return 0;
        bzero(identifyPage.virtualAddress, NVME_PAGE_SIZE);
        bzero(&nvmeCommand, sizeof(nvmeCommand));
        command->commandId = 0x8000U;
        nvmeCommand.cdw0 = NVME_CMD_DW0(NVME_ADMIN_GET_LOG_PAGE,
                                        command->commandId);
        nvmeCommand.nsid = 0xffffffffU;
        nvmeCommand.prp1 = identifyPage.physicalAddress;
        nvmeCommand.cdw10 = NVME_LOG_SMART_HEALTH | (127U << 16);
        entry = (NVMeCommand *)adminQueue.submission.virtualAddress +
                adminQueue.submissionTail;
        *entry = nvmeCommand;
        adminQueue.submissionTail = nextTail;
        adminActive = command;
        command->active = 1;
        command->adminCommand = 1;
        activeCommands++;
        IOGetTimestamp(&command->startTime);
        [self ringSubmissionDoorbell:&adminQueue];
        [self armWatchdog];
        return 1;
    }

    nextTail = (ioQueue.submissionTail + 1U) & (ioQueue.depth - 1U);
    if (nextTail == ioQueue.submissionHead)
        return 0;
    for (i = 0; i < ioQueue.depth; i++)
        if (ioSlots[i] == 0)
            break;
    if (i == ioQueue.depth)
        return 0;

    bzero(&nvmeCommand, sizeof(nvmeCommand));
    command->commandId = (unsigned short)i;
    nvmeCommand.cdw0 = NVME_CMD_DW0(command->translation.nvmeOpcode, i);
    nvmeCommand.nsid = 1;
    nvmeCommand.cdw10 = (unsigned)command->translation.lba;
    nvmeCommand.cdw11 = (unsigned)(command->translation.lba >> 32);
    if (command->translation.blockCount != 0)
        nvmeCommand.cdw12 = command->translation.blockCount - 1U;
    if (command->translation.fua)
        nvmeCommand.cdw12 |= NVME_NVM_CDW12_FUA;
    prpResult = [self buildPRPsForCommand:command nvmeCommand:&nvmeCommand];
    if (prpResult <= 0)
        return prpResult;

    entry = (NVMeCommand *)ioQueue.submission.virtualAddress +
            ioQueue.submissionTail;
    *entry = nvmeCommand;
    ioQueue.submissionTail = nextTail;
    ioSlots[i] = command;
    command->active = 1;
    activeCommands++;
    if (command->barrier)
        barrierActive = 1;
    if (command->commandQueueDisabled)
        serializedActive = 1;
    IOGetTimestamp(&command->startTime);
    if (command->translation.nvmeOpcode == NVME_NVM_READ)
        bytesRead += command->translation.transferBytes;
    else if (command->translation.nvmeOpcode == NVME_NVM_WRITE)
        bytesWritten += command->translation.transferBytes;
    faultSubmissionCount++;
    if (!faultTimeoutInjected && faultTimeoutAfter != 0 &&
        faultSubmissionCount >= faultTimeoutAfter) {
        faultTimeoutInjected = 1;
        faultTimeoutActive = 1;
        command->timeoutSeconds = (int)faultTimeoutSeconds;
        IOLog("%s: injecting test timeout for CID %u at submission %u\n",
              [self name], i, faultSubmissionCount);
    } else {
        [self ringSubmissionDoorbell:&ioQueue];
    }
    [self armWatchdog];
    return 1;
}

- (void)releaseCommandResources:(NVMeCommandBuffer *)command
{
    if (command->prpPage >= 0) {
        [self freePRPPage:command->prpPage];
        command->prpPage = -1;
    }
    if (command->active && activeCommands != 0)
        activeCommands--;
    if (command->barrier)
        barrierActive = 0;
    if (command->commandQueueDisabled)
        serializedActive = 0;
    command->active = 0;
}

- (int)processIOCompletions
{
    volatile NVMeCompletion *completion;
    NVMeCommandBuffer *command;
    NVMeSNTLResult mapped;
    unsigned short status;
    unsigned commandId;
    unsigned statusType;
    unsigned statusCode;
    int processed = 0;
    int wasWrite;

    while (1) {
        completion = (volatile NVMeCompletion *)ioQueue.completion.virtualAddress +
                     ioQueue.completionHead;
        if ((completion->status & 1U) != ioQueue.completionPhase)
            break;
        processed = 1;
        status = completion->status;
        commandId = completion->commandId;
        ioQueue.submissionHead = completion->sqHead;
        ioQueue.completionHead++;
        if (ioQueue.completionHead == ioQueue.depth) {
            ioQueue.completionHead = 0;
            ioQueue.completionPhase ^= 1;
        }
        if (commandId >= ioQueue.depth || ioSlots[commandId] == 0) {
            IOLog("NVMeSCSIDriver: orphan completion CID %u\n", commandId);
            continue;
        }
        command = ioSlots[commandId];
        ioSlots[commandId] = 0;
        statusType = (status >> 9) & 7U;
        statusCode = (status >> 1) & 0xffU;
        wasWrite = command->translation.nvmeOpcode == NVME_NVM_WRITE;
        if (statusType == 0 && statusCode == 0) {
            command->driverStatus = SR_IOST_GOOD;
            command->scsiStatus = STAT_GOOD;
            command->bytesTransferred = command->translation.transferBytes;
        } else {
            unsigned char *sense = (unsigned char *)&command->senseData;
            IOLog("%s: I/O CID %u opcode 0x%02x failed, SCT %u SC 0x%02x "
                  "DNR %u\n", [self name], commandId,
                  command->translation.nvmeOpcode, statusType, statusCode,
                  (status >> 15) & 1U);
            mapped = NVMeSNTLMapStatus(statusType, statusCode, wasWrite);
            NVMeSNTLSetSense(sense, mapped.senseKey, mapped.asc, mapped.ascq);
            bcopy(sense, lastSense, 18);
            command->driverStatus = SR_IOST_CHKSV;
            command->scsiStatus = STAT_CHECK;
        }
        [self releaseCommandResources:command];
        [self completeCommand:command];
    }
    if (processed)
        [self ringCompletionDoorbell:&ioQueue];
    return processed;
}

- (int)processAdminCompletions
{
    volatile NVMeCompletion *completion;
    NVMeCommandBuffer *command;
    NVMeSNTLResult mapped;
    unsigned short status;
    unsigned statusType;
    unsigned statusCode;
    int processed = 0;

    while (1) {
        completion = (volatile NVMeCompletion *)
                     adminQueue.completion.virtualAddress +
                     adminQueue.completionHead;
        if ((completion->status & 1U) != adminQueue.completionPhase)
            break;
        processed = 1;
        status = completion->status;
        adminQueue.submissionHead = completion->sqHead;
        adminQueue.completionHead++;
        if (adminQueue.completionHead == adminQueue.depth) {
            adminQueue.completionHead = 0;
            adminQueue.completionPhase ^= 1;
        }
        command = adminActive;
        if (command == 0 || completion->commandId != command->commandId) {
            IOLog("NVMeSCSIDriver: unexpected admin completion CID %u\n",
                  completion->commandId);
            continue;
        }
        adminActive = 0;
        statusType = (status >> 9) & 7U;
        statusCode = (status >> 1) & 0xffU;
        if (statusType == 0 && statusCode == 0) {
            command->bytesTransferred = NVMeSNTLBuildSmartLog(
                                        command->buffer,
                                        command->translation.transferBytes,
                                        identifyPage.virtualAddress);
            command->driverStatus = SR_IOST_GOOD;
            command->scsiStatus = STAT_GOOD;
        } else {
            unsigned char *sense = (unsigned char *)&command->senseData;
            IOLog("%s: admin CID %u failed, SCT %u SC 0x%02x DNR %u\n",
                  [self name], completion->commandId, statusType,
                  statusCode, (status >> 15) & 1U);
            mapped = NVMeSNTLMapStatus(statusType, statusCode, 0);
            NVMeSNTLSetSense(sense, mapped.senseKey, mapped.asc, mapped.ascq);
            bcopy(sense, lastSense, 18);
            command->driverStatus = SR_IOST_CHKSV;
            command->scsiStatus = STAT_CHECK;
        }
        [self releaseCommandResources:command];
        [self completeCommand:command];
    }
    if (processed)
        [self ringCompletionDoorbell:&adminQueue];
    return processed;
}

@end
