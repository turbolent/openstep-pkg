#ifndef NVME_RECOVERY_H
#define NVME_RECOVERY_H

#define NVME_DEFAULT_IO_TIMEOUT_SECONDS 30U
#define NVME_ADMIN_TIMEOUT_SECONDS      30U
#define NVME_NANOSECONDS_PER_SECOND     1000000000ULL

#define NVME_READY_WAITING  0
#define NVME_READY_REACHED  1
#define NVME_READY_FATAL   -1

unsigned NVMeRecoveryTimeoutSeconds(int requestedSeconds,
                                    int adminCommand);
int NVMeRecoveryCommandExpired(unsigned long long now,
                               unsigned long long startTime,
                               int requestedSeconds,
                               int adminCommand);
int NVMeRecoveryReadyState(unsigned controllerStatus, int ready);

#endif
