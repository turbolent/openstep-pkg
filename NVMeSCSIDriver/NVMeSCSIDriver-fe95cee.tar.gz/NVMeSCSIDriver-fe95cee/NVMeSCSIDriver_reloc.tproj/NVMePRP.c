#include "NVMePRP.h"

int NVMePRPPlanTransfer(unsigned firstPhysicalAddress,
                        unsigned transferBytes,
                        NVMePRPPlan *plan)
{
    unsigned available;
    unsigned remaining;
    unsigned pages;

    if (plan == 0)
        return 0;
    plan->firstBytes = 0;
    plan->remainingPages = 0;
    plan->listEntries = 0;
    if (transferBytes == 0)
        return 1;
    if (transferBytes > NVME_MAX_TRANSFER)
        return 0;

    available = NVME_PAGE_SIZE -
                (firstPhysicalAddress & NVME_PAGE_MASK);
    plan->firstBytes = transferBytes < available ?
                       transferBytes : available;
    remaining = transferBytes - plan->firstBytes;
    if (remaining == 0)
        return 1;

    pages = 1U + (remaining - 1U) / NVME_PAGE_SIZE;
    if (pages > NVME_PAGE_SIZE / sizeof(unsigned long long))
        return 0;
    plan->remainingPages = pages;
    if (pages > 1U)
        plan->listEntries = pages;
    return 1;
}
