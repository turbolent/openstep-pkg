# NVMeSCSIDriver

NVMeSCSIDriver is an OPENSTEP 4.2 SCSI controller driver for NVMe storage.
It exposes NVMe namespace 1 as SCSI target 0, LUN 0 and translates the SCSI disk command set
used by OPENSTEP into NVMe commands.

## Hardware requirements

- PCI class `01:08:02` NVMe controller
- BAR0 assigned below 4 GB
- DMA memory addressable below 4 GB
- 4 KB NVMe controller memory-page support
- Namespace 1 formatted without metadata, using 512 to 4096-byte LBAs
- Legacy INTx interrupt delivery, or polling-only operation

The supplied table recognizes these tested controllers:

- VirtualBox `80ee:4e56`, legacy INTx
- QEMU `1b36:0010`, legacy INTx
- VMware `15ad:07f0`, polling-only compatibility mode
- Realtek RTS5765DL `10ec:5765`, physically tested with legacy INTx

Other NVMe controllers can be configured by PCI location.
The driver verifies the NVMe PCI class before accessing a configured device.

## Acknowledgements

NVMeSCSIDriver was developed with [nvme2k](https://github.com/techomancer/nvme2k)
as an important behavioral and architectural reference.
Thanks to Dominik Behr for making that work available.
