# Phase 0 상태 기록

갱신: 2026-08-11

| 항목 | 상태 | 근거/최종 처리 |
|---|---|---|
| SDL 원본 | 확보됨 | `upstream/SDL-1.2.15/`, SHA-256은 `upstream/SDL-1.2.15.SOURCE.md` 참조 |
| AppKit 코드 관례 | 확인됨 | 이 워크스페이스의 `openstep-mp3player`가 `NSApplication`, `NSWindow`, `NSView`, `-framework AppKit -framework Foundation`으로 실기 동작을 기록 |
| AppKit/DPS window spike | native build·GUI 통과 | 이후 SDL overlay WindowServer 실기에서 창, 입력, resize/expose와 close까지 확인; GUI 실행은 WindowServer console session에서 수행 |
| RGB bitmap presenter spike | native build·GUI 통과 | `NSBitmapImageRep initWithBitmapDataPlanes:...colorSpaceName:` + `drawInRect:` 경로와 bottom-up backing row를 실기 pattern으로 확인해 SDL presenter에 반영 |
| `/tmp/SDL12` | 생성·사용 중 | staging/build/bin/log가 모두 이 전용 경로에만 생성됨 |
| NFS root-squash | 작업 규칙 반영 | `/ndrv/openstep-sdl12`은 OPENSTEP에서 읽기 전용; `build/stage-openstep.csh`가 `/tmp/SDL12`에만 씀 |
| OPENSTEP tar 경로 한계 | 대응 완료 | full-tree archive 대신 SDL native build에 필요한 `include/`·`src/`만 `/tmp/SDL12/.stage.tar`로 staging |
| AppKit SDL overlay | 8/16/24/32bpp WindowServer 통과 | GUI Terminal에서 palette/RGB, redraw, arrows/F키/left mouse/drag/focus와 close를 확인. 물리적 right/modifier 일부는 console input path 제한으로 보류 |
| bpp visual smoke test | 8/16/24/32bpp GUI 통과 | 8bpp palette/RGB gradient, 16/24/32bpp RGB window와 32bpp 가림/노출 redraw를 console에서 확인 |
| AppKit 입력 확장 | 기본 key/mouse GUI 통과, modifier 보류 | arrows/F1/F2/F12/Home/End/Page/Insert/Delete, key up/down, focus, left drag/motion 확인. console input이 modifier와 right mouse를 left/0 flag로 전달해 해당 runtime 검증 보류 |
| OPENSTEP timer overlay | native compile/link/runtime 통과 | BSD `gettimeofday`/`setitimer` backend. `select()`/`EINTR` delay 보정 뒤 최종 run은 `SDL_TIMER_OK: 240 callback=1`, wrap 함수는 `SDL_TIMER_WRAP_OK: 1234` |
| OPENSTEP cthreads overlay | native compile/link/runtime 통과 | `SDL_CreateThread`, mutex, semaphore, join과 condition signal/timeout/two-waiter broadcast, 4-worker/400-lock contention, join 뒤 3회 SDL lifecycle이 `SDL_THREAD_OK`로 확인됨 |
| SoundKit audio overlay | 실제 PCM 재생 통과 | native `SNDStartPlaying` FCFS queue로 44.1 kHz/stereo/16-bit WAV를 정상 속도·무끊김 재생. 2026-08-11 GUI 300초 AV 실기에서 창 이동·가림/복원 중에도 음악·화면 모두 정상으로 자연 종료; 결과 기록 순서를 보정한 30초 harness도 `SDL_AV_OK`를 확인. 방식은 `openstep-mp3player` 실기 이력을 따름 |
| SDL audio 지속성 | 300초 실기 통과 | `sdl-audio-loop`가 callback 1,199회, 52,875,900 bytes, 300,833 ms로 자연 종료했고 process가 남지 않음; 30초 선행 회귀도 통과 |
| 실행 파일 CPU subtype | 대응 완료, 지속 적용 필요 | `cc`는 `-m486`에도 i586 Mach-O를 표기. i486 loader용 post-link header 보정 helper를 overlay/test Makefile에 포함 |

Phase 0의 아래 순서는 완료되어 역사적 절차로 남긴다.

1. `/ndrv/openstep-sdl12/build/stage-openstep.csh`로 `/tmp/SDL12`에만 staging한다.
2. `spikes/appkit-window`와 `spikes/bitmap-presenter`를 native `cc`로 빌드한다.
3. WindowServer가 있는 실기 console session에서 두 program을 실행해 창·resize·key/mouse 이벤트와 RGB bitmap 색/재표시를 확인했다. WindowServer가 없는 headless session에서 AppKit program을 실행하면 `DPS Error: Can't connect to server on host local host`로 끝난다.
4. 그 결과를 바탕으로 SDL software surface presenter와 event translator의 API를 확정했다.
