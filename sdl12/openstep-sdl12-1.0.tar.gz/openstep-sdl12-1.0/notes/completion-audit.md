# SDL 1.2 OPENSTEP 포트 완료 감사

갱신: 2026-08-11

이 표는 `PLAN_SDL12.md`의 최소 성공 기준을 실제 증거와 대조한다. 모든 항목은 대상
OPENSTEP 4.2의 실행, 바이너리 검사 또는 WindowServer 시각 판정까지 끝났다.

| 최소 성공 기준 | 상태 | 권위 있는 증거 |
|---|---|---|
| X11 없는 native build/run | 통과 | `SDL_config_openstep.h`와 `Makefile.openstep`은 OPENSTEP backend만 선택한다. 최종 7개 GUI executable의 대상 `otool -L`은 AppKit, Foundation, SoundKit, System만 기록했고 X11/Xlib가 없다. 세 bootstrap patch는 pristine tree에서 `patch --dry-run -p0`을 통과했다. |
| 8/16/24/32bpp software video와 expose | 통과 | 모든 bpp gradient/palette와 32bpp 가림·재노출을 WindowServer에서 확인했다. 원본 `testbitmap`/`graywin`으로 top-down SDL row와 bottom-up AppKit bitmap 경계를 확인했다. 상세 transcript는 `TESTING.md`에 있다. |
| `SDL_UpdateRect(s)` 손상 영역만 표시 | 통과 | target `NSView -displayRect:` 문서에 따라 각 rect를 변환·clip한다. 최종 실기에서 좌상단 빨강만 먼저 나타나고 다음 update에서 우하단 초록이 추가됐으며 `SDL_DIRTYRECT_OK`를 기록했다. |
| key/mouse/close/active event | 통과(장치 제한 기록) | `sdl-video-events`, `sdl-wait-event`, 원본 `testwm`/`testbitmap`/`graywin`으로 key down/up, F1–F12/Pause, motion/drag, left button, focus, expose, quit를 확인했다. 보존 로그 `sdl-wait-event-20260811.log`; F13–F15/keypad/Caps와 console이 전달하지 않는 right/modifier 일부는 장치 coverage 제한이다. |
| resize, cursor visibility/warp | 통과 | 서로 다른 resize 3회와 pattern 재표시, native custom/default cursor hide/show, 세 DPS warp 좌표 및 잔상·mirror 부재를 WindowServer에서 확인했다. grab/relative/fullscreen은 지원하지 않는 capability로 명시했다. |
| SoundKit callback 지속 공급 | 통과 | native `SNDStartPlaying(..., preempt=0)` FCFS queue로 15초 WAV, pause/resume/close, 원본 `loopwave`, audio-only 300초 및 audio+video 300초를 정상 청취·자연 종료했다. callback/byte/elapsed와 API 오류를 `TESTING.md`에 기록했다. |
| timer/thread 공개 API | 통과 | 최종 headless run: `SDL_TIMER_OK: 240 callback=1`, `SDL_TIMER_WRAP_OK: 1234`, `SDL_THREAD_OK`. delay/EINTR, one-shot timer, 약 49일 Uint32 wrap, recursive mutex, semaphore, condition timeout/signal/broadcast, contention과 join을 포함한다. |
| 실제 SDL 프로그램 2개 이상 | 통과 | 원본 `testwm`, `loopwave`, `testbitmap`, `graywin`, `testcursor`와 외부 `stars`/`xflame`을 실행했다. 마지막 세 프로그램도 cursor/animation/input 종료를 최종 화면에서 통과했다. `plasma`는 원본의 any-event 종료 loop 때문에 build probe로만 분류했다. |
| 라이선스·출처·재현 패키지 | 통과 | 루트 `COPYING`/`NOTICE`, pristine SDL URL/SHA-256, 외부 예제 commit/hash/license, 논리별 bootstrap patches가 있다. source package를 두 번 만들었을 때 archive SHA-256이 동일했고 media/build output은 제외됐다. |

## 최종 판정

`test/openstep/run-final-gui-tests.csh`의 7단계를 WindowServer console에서 실행하고
각 `/tmp/SDL12/log/*.log` 및 사용자 시각 관찰을 대조했다. dirty clipping, cursor
visibility, warp, resize, 원본 `testcursor`, 외부 `stars`/`xflame`이 모두 통과했다.
보존 transcript는 `final-gui-20260811.log`다.

의도적인 제한은 fullscreen/OpenGL/hardware blit, mouse grab/relative mode,
CD-ROM/joystick이다. 이는 요청된 native software AppKit/DPS, NSEvent, SoundKit,
BSD timer, Mach cthreads 포트의 범위를 축소하지 않으며 지원한다고 광고하지 않는다.
