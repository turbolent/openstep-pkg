#!/bin/csh -f
# Build SDL 1.2.15's unmodified test/loopwave.c for OPENSTEP audio.
# NFS is read-only input; generated files remain below /tmp/SDL12.

set upstream_test = /ndrv/openstep-sdl12/upstream/SDL-1.2.15/test
set build_dir = /tmp/SDL12/src/test/openstep/upstream-loopwave
set overlay = /tmp/SDL12/build/SDL-1.2.15-openstep

if (! -r $upstream_test/loopwave.c) then
    echo "build-upstream-loopwave: missing $upstream_test/loopwave.c"
    exit 1
endif
if (! -r $overlay/libSDL.a) then
    echo "build-upstream-loopwave: missing $overlay/libSDL.a"
    exit 1
endif

if (! -d $build_dir) mkdir $build_dir
cp $upstream_test/loopwave.c $build_dir/loopwave.c

cd $build_dir
cc -m486 -O -Wall -D__OPENSTEP__ -I$overlay/include -o sdl-loopwave loopwave.c $overlay/libSDL.a -framework AppKit -framework Foundation -framework SoundKit
if ($status != 0) exit 1
/bin/csh -f $overlay/fix-macho-i486-subtype.csh sdl-loopwave
if ($status != 0) exit 1

echo "build-upstream-loopwave: built $build_dir/sdl-loopwave"
exit 0
