/* SDL 1.2 OPENSTEP dirty-rectangle presentation regression. */
#include <stdio.h>

#include "SDL.h"

#define PHASE_MILLISECONDS 5000

static int wait_phase(Uint32 milliseconds)
{
    Uint32 start;
    SDL_Event event;

    start = SDL_GetTicks();
    while ((SDL_GetTicks() - start) < milliseconds) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) return 0;
            if ((event.type == SDL_KEYDOWN) &&
                (event.key.keysym.sym == SDLK_ESCAPE)) return 0;
        }
        SDL_Delay(10);
    }
    return 1;
}

int main(int argc, char **argv)
{
    SDL_Surface *screen;
    SDL_Rect red_rect;
    SDL_Rect green_rect;
    Uint32 background;
    Uint32 red;
    Uint32 green;
    int completed;

    (void)argc;
    (void)argv;
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0) {
        fprintf(stderr, "SDL_DIRTY_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    SDL_WM_SetCaption("SDL dirty rect: first red, then green", "SDL dirty rect");
    screen = SDL_SetVideoMode(360, 220, 24, SDL_SWSURFACE);
    if (screen == NULL) {
        fprintf(stderr, "SDL_DIRTY_VIDEO_FAILED: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    background = SDL_MapRGB(screen->format, 28, 32, 42);
    red = SDL_MapRGB(screen->format, 220, 45, 35);
    green = SDL_MapRGB(screen->format, 35, 210, 75);
    red_rect.x = 24;
    red_rect.y = 24;
    red_rect.w = 96;
    red_rect.h = 72;
    green_rect.x = 240;
    green_rect.y = 124;
    green_rect.w = 96;
    green_rect.h = 72;

    SDL_FillRect(screen, NULL, background);
    SDL_UpdateRect(screen, 0, 0, 0, 0);
    if (!wait_phase(1500)) {
        SDL_Quit();
        return 1;
    }

    /* Mutate both regions, but present only the upper-left one first. */
    SDL_FillRect(screen, &red_rect, red);
    SDL_FillRect(screen, &green_rect, green);
    SDL_UpdateRect(screen, red_rect.x, red_rect.y, red_rect.w, red_rect.h);
    printf("SDL_DIRTY_PHASE_1: red visible, green still background\n");
    fflush(stdout);
    completed = wait_phase(PHASE_MILLISECONDS);
    if (completed) {
        SDL_UpdateRect(screen, green_rect.x, green_rect.y,
                       green_rect.w, green_rect.h);
        printf("SDL_DIRTY_PHASE_2: red and green visible\n");
        fflush(stdout);
        completed = wait_phase(PHASE_MILLISECONDS);
    }

    if (completed) {
        printf("SDL_DIRTYRECT_OK\n");
    } else {
        fprintf(stderr, "SDL_DIRTYRECT_INCOMPLETE\n");
    }
    SDL_Quit();
    return completed ? 0 : 1;
}
