#!/bin/csh -f
# Run SDL 1.2.15's upstream loopwave from an OPENSTEP GUI Terminal.
# Control-C asks the original program to close audio and exit cleanly.

set program_dir = /tmp/SDL12/src/test/openstep/upstream-loopwave
set program = $program_dir/sdl-loopwave
set wav = /ndrv/openstep-sdl12/assets/hiyuki-openstep-test-15s-44100-s16.wav
set log = /tmp/SDL12/log/upstream-loopwave.log

if (! -x $program) then
    echo "run-upstream-loopwave: missing $program"
    echo "build it first: /bin/csh -f /tmp/SDL12/src/test/openstep/build-upstream-loopwave.csh"
    exit 1
endif
if (! -r $wav) then
    echo "run-upstream-loopwave: cannot read $wav"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

echo "SDL upstream loopwave: listen, then press Control-C to stop"
$program $wav >&! $log
set program_status = $status
echo "upstream loopwave exit status: $program_status (log: $log)"
exit $program_status
