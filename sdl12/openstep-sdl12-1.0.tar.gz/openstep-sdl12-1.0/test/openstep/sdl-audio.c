/* Headless SoundKit backend smoke test; callback writes silence. */
#include "SDL.h"
#include <stdio.h>

static int callbacks;

static void SDLCALL fill_silence(void *userdata, Uint8 *stream, int length)
{
    SDL_memset(stream, 0, length);
    ++callbacks;
}

int main(int argc, char **argv)
{
    SDL_AudioSpec wanted;
    SDL_AudioSpec obtained;

    SDL_memset(&wanted, 0, sizeof(wanted));
    wanted.freq = 22050;
    wanted.format = AUDIO_S16SYS;
    wanted.channels = 1;
    wanted.samples = 512;
    wanted.callback = fill_silence;
    if (SDL_Init(SDL_INIT_AUDIO | SDL_INIT_TIMER) != 0) {
        fprintf(stderr, "SDL_AUDIO_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    if (SDL_OpenAudio(&wanted, &obtained) != 0) {
        fprintf(stderr, "SDL_AUDIO_OPEN_FAILED: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
    SDL_PauseAudio(0);
    SDL_Delay(250);
    SDL_CloseAudio();
    SDL_Quit();
    if (callbacks == 0) {
        fprintf(stderr, "SDL_AUDIO_NO_CALLBACK\n");
        return 1;
    }
    fprintf(stderr, "SDL_AUDIO_OK: %d\n", callbacks);
    return 0;
}
