#!/bin/csh -f
# Run SDL_WarpMouse regression in the WindowServer session.

set program = /tmp/SDL12/src/test/openstep/sdl-warp-regression
set log = /tmp/SDL12/log/sdl-warp-regression.log

if (! -x $program) then
    echo "run-warp-regression: missing $program"
    echo "build it first: cd /tmp/SDL12/src/test/openstep; make sdl-warp-regression"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

echo "Watch the pointer follow three targets; the program exits automatically."
$program >&! $log
set program_status = $status
echo "warp regression exit status: $program_status (log: $log)"
exit $program_status
