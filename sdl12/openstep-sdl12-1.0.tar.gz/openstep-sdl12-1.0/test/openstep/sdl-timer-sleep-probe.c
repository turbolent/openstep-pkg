/* Separate SDL_SetTimer probe using native sleep(3), not SDL_Delay(). */
#include "SDL.h"
#include <stdio.h>
#ifdef __NeXT__
#include <libc.h>
#else
#include <unistd.h>
#endif

static volatile int timer_hits;

static Uint32 SDLCALL timer_callback(Uint32 interval)
{
    ++timer_hits;
    return 0;
}

int main(int argc, char **argv)
{
    if (SDL_Init(SDL_INIT_TIMER) != 0) {
        fprintf(stderr, "SDL_TIMER_SLEEP_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    if (SDL_SetTimer(20, timer_callback) != 0) {
        fprintf(stderr, "SDL_TIMER_SLEEP_SET_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    sleep(1);
    SDL_SetTimer(0, NULL);
    SDL_Quit();
    if (timer_hits != 1) {
        fprintf(stderr, "SDL_TIMER_SLEEP_BAD: %d\n", timer_hits);
        return 1;
    }
    fprintf(stderr, "SDL_TIMER_SLEEP_OK: %d\n", timer_hits);
    return 0;
}
