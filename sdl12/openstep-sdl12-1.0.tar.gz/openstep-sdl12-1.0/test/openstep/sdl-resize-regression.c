/* SDL 1.2 OPENSTEP SDL_RESIZABLE/event/re-SetVideoMode regression. */
#include <stdio.h>

#include "SDL.h"

#define TEST_MILLISECONDS 90000

static void draw_pattern(SDL_Surface *screen, int generation)
{
    SDL_Rect rect;
    Uint32 background;
    Uint32 top;
    Uint32 bottom;
    Uint32 marker;

    background = SDL_MapRGB(screen->format, 35, 35, 45);
    top = SDL_MapRGB(screen->format, 30, 80, 190);
    bottom = SDL_MapRGB(screen->format, 190, 45, 35);
    marker = SDL_MapRGB(screen->format,
                        (Uint8)(80 + (generation * 31) % 150), 200, 70);
    SDL_FillRect(screen, NULL, background);
    rect.x = 0;
    rect.y = 0;
    rect.w = screen->w;
    rect.h = 18;
    SDL_FillRect(screen, &rect, top);
    rect.y = screen->h - 18;
    SDL_FillRect(screen, &rect, bottom);
    rect.x = screen->w / 2 - 20;
    rect.y = screen->h / 2 - 20;
    rect.w = 40;
    rect.h = 40;
    SDL_FillRect(screen, &rect, marker);
    SDL_UpdateRect(screen, 0, 0, 0, 0);
}

int main(int argc, char **argv)
{
    SDL_Surface *screen;
    SDL_Event event;
    Uint32 start;
    int running;
    int resize_count;

    (void)argc;
    (void)argv;
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0) {
        fprintf(stderr, "SDL_RESIZE_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    SDL_WM_SetCaption("SDL resize: resize twice, then Escape", "SDL resize");
    screen = SDL_SetVideoMode(320, 200, 24,
                              SDL_SWSURFACE | SDL_RESIZABLE);
    if (screen == NULL) {
        fprintf(stderr, "SDL_RESIZE_VIDEO_FAILED: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
    if ((screen->flags & SDL_RESIZABLE) == 0) {
        fprintf(stderr, "SDL_RESIZE_FLAG_MISSING: 0x%lx\n",
                (unsigned long)screen->flags);
        SDL_Quit();
        return 1;
    }
    resize_count = 0;
    draw_pattern(screen, resize_count);
    printf("SDL_RESIZE_READY: %d %d flags=0x%lx\n", screen->w, screen->h,
           (unsigned long)screen->flags);
    fflush(stdout);

    start = SDL_GetTicks();
    running = 1;
    while (running && ((SDL_GetTicks() - start) < TEST_MILLISECONDS)) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_VIDEORESIZE) {
                printf("SDL_RESIZE_EVENT: %d %d\n", event.resize.w,
                       event.resize.h);
                fflush(stdout);
                screen = SDL_SetVideoMode(event.resize.w, event.resize.h, 24,
                                          SDL_SWSURFACE | SDL_RESIZABLE);
                if (screen == NULL) {
                    fprintf(stderr, "SDL_RESIZE_RESET_FAILED: %s\n",
                            SDL_GetError());
                    SDL_Quit();
                    return 1;
                }
                ++resize_count;
                draw_pattern(screen, resize_count);
                printf("SDL_RESIZE_APPLIED: %d %d count=%d\n", screen->w,
                       screen->h, resize_count);
                fflush(stdout);
            } else if (event.type == SDL_QUIT) {
                running = 0;
            } else if ((event.type == SDL_KEYDOWN) &&
                       (event.key.keysym.sym == SDLK_ESCAPE)) {
                running = 0;
            }
        }
        SDL_Delay(10);
    }
    if (resize_count >= 2) {
        printf("SDL_RESIZE_OK: count=%d\n", resize_count);
    } else {
        fprintf(stderr, "SDL_RESIZE_INCOMPLETE: count=%d\n", resize_count);
    }
    SDL_Quit();
    return (resize_count >= 2) ? 0 : 1;
}
