#!/bin/csh -f
# Build SDL 1.2.15's unmodified test/testbitmap.c for OPENSTEP video.

set upstream_test = /ndrv/openstep-sdl12/upstream/SDL-1.2.15/test
set build_dir = /tmp/SDL12/src/test/openstep/upstream-testbitmap
set overlay = /tmp/SDL12/build/SDL-1.2.15-openstep

if (! -r $upstream_test/testbitmap.c) then
    echo "build-upstream-testbitmap: missing $upstream_test/testbitmap.c"
    exit 1
endif
if (! -r $upstream_test/picture.xbm) then
    echo "build-upstream-testbitmap: missing $upstream_test/picture.xbm"
    exit 1
endif
if (! -r $overlay/libSDL.a) then
    echo "build-upstream-testbitmap: missing $overlay/libSDL.a"
    exit 1
endif

if (! -d $build_dir) mkdir $build_dir
cp $upstream_test/testbitmap.c $build_dir/testbitmap.c
cp $upstream_test/picture.xbm $build_dir/picture.xbm

cd $build_dir
cc -m486 -O -Wall -D__OPENSTEP__ -I$overlay/include -o sdl-testbitmap testbitmap.c $overlay/libSDL.a -framework AppKit -framework Foundation -framework SoundKit
if ($status != 0) exit 1
/bin/csh -f $overlay/fix-macho-i486-subtype.csh sdl-testbitmap
if ($status != 0) exit 1

echo "build-upstream-testbitmap: built $build_dir/sdl-testbitmap"
exit 0
