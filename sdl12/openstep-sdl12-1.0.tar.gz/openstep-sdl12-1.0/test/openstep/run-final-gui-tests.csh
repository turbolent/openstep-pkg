#!/bin/csh -f
# Run the remaining WindowServer-only acceptance tests in one sequence.

set test_dir = /tmp/SDL12/src/test/openstep
set sequence_log = /tmp/SDL12/log/final-gui-sequence.log

if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log
echo "SDL12_FINAL_GUI_SEQUENCE_START" >! $sequence_log

echo "[1/7] Dirty rectangles: first red only, then red and green."
/bin/csh -f $test_dir/run-dirtyrect-regression.csh
if ($status != 0) then
    echo "FAIL dirtyrect" >> $sequence_log
    exit 1
endif
echo "PASS dirtyrect" >> $sequence_log

echo "[2/7] Cursor visibility: watch four automatic color/title phases."
/bin/csh -f $test_dir/run-cursor-regression.csh
if ($status != 0) then
    echo "FAIL cursor" >> $sequence_log
    exit 1
endif
echo "PASS cursor" >> $sequence_log

echo "[3/7] Cursor warp: pointer should follow three automatic square targets."
/bin/csh -f $test_dir/run-warp-regression.csh
if ($status != 0) then
    echo "FAIL warp" >> $sequence_log
    exit 1
endif
echo "PASS warp" >> $sequence_log

echo "[4/7] Resize: resize to two different sizes, then press Escape."
/bin/csh -f $test_dir/run-resize-regression.csh
if ($status != 0) then
    echo "FAIL resize" >> $sequence_log
    exit 1
endif
echo "PASS resize" >> $sequence_log

echo "[5/7] Upstream testcursor: click three times, then press Escape."
/bin/csh -f $test_dir/run-upstream-testcursor.csh
if ($status != 0) then
    echo "FAIL testcursor" >> $sequence_log
    exit 1
endif
echo "PASS testcursor" >> $sequence_log

echo "[6/7] External stars: watch animation, then press any key."
/bin/csh -f $test_dir/run-external-stars.csh
if ($status != 0) then
    echo "FAIL stars" >> $sequence_log
    exit 1
endif
echo "PASS stars" >> $sequence_log

echo "[7/7] External XFlame: watch 8bpp partial-update animation, then press any key."
/bin/csh -f $test_dir/run-external-xflame.csh
if ($status != 0) then
    echo "FAIL xflame" >> $sequence_log
    exit 1
endif
echo "PASS xflame" >> $sequence_log

echo "SDL12_FINAL_GUI_SEQUENCE_OK"
echo "SDL12_FINAL_GUI_SEQUENCE_OK" >> $sequence_log
exit 0
