#!/bin/csh -f
# Run SDL 1.2.15's upstream testbitmap in OPENSTEP's supported 8bpp mode.
# Click to blit the compiled-in XBM image; Escape exits the original test.

set program_dir = /tmp/SDL12/src/test/openstep/upstream-testbitmap
set program = $program_dir/sdl-testbitmap
set log = /tmp/SDL12/log/upstream-testbitmap.log

if (! -x $program) then
    echo "run-upstream-testbitmap: missing $program"
    echo "build it first: /bin/csh -f /tmp/SDL12/src/test/openstep/build-upstream-testbitmap.csh"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

cd $program_dir
echo "SDL upstream testbitmap: click once to draw, then press Escape"
$program -bpp 8 >&! $log
set program_status = $status
echo "upstream testbitmap exit status: $program_status (log: $log)"
exit $program_status
