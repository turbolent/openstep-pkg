/* Direct OPENSTEP legacy Sound API diagnostic; independent of SDL. */
#include <sound/sound.h>
#include <stdio.h>

int main(int argc, char **argv)
{
    SNDSoundStruct *sound;
    const char *path;
    int error;

    path = (argc == 2) ? argv[1] : "/tmp/SDL12/audio/hiyuki-openstep-test-15s-44100-s16.snd";
    sound = 0;
    error = SNDReadSoundfile((char *)path, &sound);
    if (error != SND_ERR_NONE) {
        fprintf(stderr, "SOUND_API_LOAD_FAILED: %d\n", error);
        return 1;
    }
    error = SNDVerifyPlayable(sound);
    if (error != SND_ERR_NONE) {
        fprintf(stderr, "SOUND_API_UNPLAYABLE: %d\n", error);
        SNDFree(sound);
        return 1;
    }
    fprintf(stderr, "SOUND_API_READY: %s (%d Hz, %d ch)\n",
            path, sound->samplingRate, sound->channelCount);
    error = SNDStartPlaying(sound, 1, 0, 1, SND_NULL_FUN, SND_NULL_FUN);
    if (error == SND_ERR_NONE) error = SNDWait(1);
    SNDFree(sound);
    if (error != SND_ERR_NONE) {
        fprintf(stderr, "SOUND_API_PLAY_FAILED: %d\n", error);
        return 1;
    }
    fprintf(stderr, "SOUND_API_OK\n");
    return 0;
}
