/* SDL 1.2 OPENSTEP Display PostScript cursor-warp regression. */
#include <stdio.h>

#include "SDL.h"

static void draw_target(SDL_Surface *screen, int x, int y, int phase)
{
    SDL_Rect rect;
    Uint32 background;
    Uint32 target;

    background = SDL_MapRGB(screen->format, 30, 35, 45);
    target = SDL_MapRGB(screen->format, 60, (Uint8)(120 + phase * 35), 220);
    SDL_FillRect(screen, NULL, background);
    rect.x = x - 8;
    rect.y = y - 8;
    rect.w = 17;
    rect.h = 17;
    SDL_FillRect(screen, &rect, target);
    SDL_UpdateRect(screen, 0, 0, 0, 0);
}

static int wait_phase(Uint32 milliseconds)
{
    Uint32 start;
    SDL_Event event;

    start = SDL_GetTicks();
    while ((SDL_GetTicks() - start) < milliseconds) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) return 0;
            if ((event.type == SDL_KEYDOWN) &&
                (event.key.keysym.sym == SDLK_ESCAPE)) return 0;
        }
        SDL_Delay(10);
    }
    return 1;
}

int main(int argc, char **argv)
{
    static int positions[3][2] = {
        { 30, 30 }, { 290, 30 }, { 160, 170 }
    };
    SDL_Surface *screen;
    int x;
    int y;
    int phase;
    int ok;

    (void)argc;
    (void)argv;
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0) {
        fprintf(stderr, "SDL_WARP_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    screen = SDL_SetVideoMode(320, 200, 24, SDL_SWSURFACE);
    if (screen == NULL) {
        fprintf(stderr, "SDL_WARP_VIDEO_FAILED: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
    ok = 1;
    for (phase = 0; phase < 3; ++phase) {
        draw_target(screen, positions[phase][0], positions[phase][1], phase);
        SDL_WM_SetCaption((phase == 0) ? "SDL warp 1/3: upper-left" :
                          ((phase == 1) ? "SDL warp 2/3: upper-right" :
                           "SDL warp 3/3: lower-center"), "SDL warp");
        SDL_WarpMouse((Uint16)positions[phase][0],
                      (Uint16)positions[phase][1]);
        SDL_GetMouseState(&x, &y);
        printf("SDL_WARP_PHASE: %d requested=%d,%d state=%d,%d\n",
               phase + 1, positions[phase][0], positions[phase][1], x, y);
        fflush(stdout);
        if ((x != positions[phase][0]) || (y != positions[phase][1])) ok = 0;
        if (!wait_phase(2500)) break;
    }
    if (ok && (phase == 3)) {
        printf("SDL_WARP_OK\n");
    } else {
        fprintf(stderr, "SDL_WARP_FAILED: completed=%d\n", phase);
        ok = 0;
    }
    SDL_Quit();
    return ok ? 0 : 1;
}
