/* WindowServer + SoundKit continuous regression for the OPENSTEP backend. */
#include "SDL.h"
#include <stdio.h>
#include <stdlib.h>

struct AVData {
    Uint8 *data;
    Uint32 length;
    Uint32 position;
    Uint32 callbacks;
    Uint32 bytes;
};

static void SDLCALL fill_loop(void *userdata, Uint8 *stream, int length)
{
    struct AVData *audio;
    Uint32 remaining;
    Uint32 amount;
    Uint32 written;

    audio = (struct AVData *)userdata;
    written = 0;
    while (written < (Uint32)length) {
        if (audio->position >= audio->length) audio->position = 0;
        remaining = audio->length - audio->position;
        amount = ((Uint32)length - written < remaining) ?
                 (Uint32)length - written : remaining;
        SDL_memcpy(stream + written, audio->data + audio->position, amount);
        audio->position += amount;
        written += amount;
    }
    ++audio->callbacks;
    audio->bytes += (Uint32)length;
}

static void draw_frame(SDL_Surface *screen, Uint32 tick)
{
    SDL_Rect box;
    Uint32 background;
    Uint32 foreground;

    background = SDL_MapRGB(screen->format, (Uint8)(tick & 255),
                            (Uint8)((tick >> 1) & 255),
                            (Uint8)(255 - (tick & 255)));
    foreground = SDL_MapRGB(screen->format, 255, 255, 255);
    SDL_FillRect(screen, NULL, background);
    box.x = (Sint16)((tick / 7) % (screen->w - 40));
    box.y = (Sint16)((tick / 11) % (screen->h - 30));
    box.w = 40;
    box.h = 30;
    SDL_FillRect(screen, &box, foreground);
    SDL_UpdateRect(screen, 0, 0, 0, 0);
}

int main(int argc, char **argv)
{
    SDL_AudioSpec wanted;
    SDL_Surface *screen;
    SDL_Event event;
    Uint8 *buffer;
    Uint32 length;
    Uint32 started;
    Uint32 elapsed;
    Uint32 next_report;
    Uint32 exposes;
    Uint32 active_changes;
    int seconds;
    int running;
    int result;
    struct AVData audio;
    const char *path;
    FILE *report;

    path = "/tmp/SDL12/audio/hiyuki-openstep-test-15s-44100-s16.wav";
    seconds = 300;
    if (argc > 1) path = argv[1];
    if (argc > 2) seconds = atoi(argv[2]);
    if ((seconds < 1) || (seconds > 300)) {
        fprintf(stderr, "usage: sdl-av-stress [wav] [seconds: 1..300]\n");
        return 2;
    }
    report = fopen("/tmp/SDL12/log/sdl-av-stress.log", "w");
    if (report == NULL) report = stderr;
    else setbuf(report, NULL);
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER) != 0) {
        fprintf(report, "SDL_AV_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    screen = SDL_SetVideoMode(320, 240, 24, SDL_SWSURFACE);
    if (screen == NULL) {
        fprintf(report, "SDL_AV_VIDEO_FAILED: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
    SDL_WM_SetCaption("SDL OPENSTEP audio + video stress", NULL);
    if (SDL_LoadWAV(path, &wanted, &buffer, &length) == NULL) {
        fprintf(report, "SDL_AV_LOAD_FAILED: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
    audio.data = buffer;
    audio.length = length;
    audio.position = 0;
    audio.callbacks = 0;
    audio.bytes = 0;
    exposes = 0;
    active_changes = 0;
    wanted.callback = fill_loop;
    wanted.userdata = &audio;
    if (SDL_OpenAudio(&wanted, NULL) != 0) {
        fprintf(report, "SDL_AV_OPEN_FAILED: %s\n", SDL_GetError());
        SDL_FreeWAV(buffer);
        SDL_Quit();
        return 1;
    }
    SDL_PauseAudio(0);
    started = SDL_GetTicks();
    next_report = 30000;
    running = 1;
    fprintf(report, "SDL_AV_READY: %d seconds, %d Hz, %d ch\n", seconds,
            wanted.freq, wanted.channels);
    while (running && ((elapsed = SDL_GetTicks() - started) <
                       (Uint32)(seconds * 1000))) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = 0;
            } else if (event.type == SDL_VIDEOEXPOSE) {
                ++exposes;
            } else if (event.type == SDL_ACTIVEEVENT) {
                ++active_changes;
            }
        }
        draw_frame(screen, elapsed / 10);
        if (elapsed >= next_report) {
            fprintf(report,
                    "SDL_AV_PROGRESS: %lu callbacks=%lu bytes=%lu exposes=%lu\n",
                    (unsigned long)elapsed, (unsigned long)audio.callbacks,
                    (unsigned long)audio.bytes, (unsigned long)exposes);
            next_report += 30000;
        }
        SDL_Delay(10);
    }
    result = running && (audio.callbacks != 0);
    SDL_CloseAudio();
    SDL_FreeWAV(buffer);
    elapsed = SDL_GetTicks() - started;
    /* OPENSTEP can terminate the process while SDL_Quit closes the final
       AppKit window.  Commit the test result after audio drain but before
       that GUI teardown. */
    if (!result) {
        if (!running) fprintf(report, "SDL_AV_QUIT_EARLY\n");
        fprintf(report, "SDL_AV_FAILED\n");
        if (report != stderr) fclose(report);
        SDL_Quit();
        return 1;
    }
    fprintf(report,
            "SDL_AV_OK: callbacks=%lu bytes=%lu elapsed=%lu exposes=%lu active=%lu\n",
            (unsigned long)audio.callbacks, (unsigned long)audio.bytes,
            (unsigned long)elapsed, (unsigned long)exposes,
            (unsigned long)active_changes);
    if (report != stderr) fclose(report);
    SDL_Quit();
    return 0;
}
