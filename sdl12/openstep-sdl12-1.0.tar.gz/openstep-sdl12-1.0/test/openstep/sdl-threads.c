/* Headless OPENSTEP Mach cthreads regression test. */
#include "SDL.h"
#include <stdio.h>

#define CONTENTION_WORKERS 4
#define CONTENTION_LOOPS 100

static SDL_mutex *counter_lock;
static SDL_sem *ready;
static SDL_sem *waiting;
static SDL_cond *condition;
static int counter;
static int release_worker;
static int condition_observed;
static int condition_wait_result;
static int broadcast_release;
static int broadcast_observed;
static SDL_mutex *contention_lock;
static SDL_sem *contention_start;
static int contention_counter;

static int SDLCALL worker(void *unused)
{
    SDL_LockMutex(counter_lock);
    ++counter;
    SDL_UnlockMutex(counter_lock);
    SDL_SemPost(ready);
    SDL_LockMutex(counter_lock);
    SDL_SemPost(waiting);
    while (!release_worker) {
        condition_wait_result = SDL_CondWaitTimeout(condition, counter_lock,
                                                     1000);
        if (condition_wait_result != 0) return 2;
    }
    condition_observed = 1;
    SDL_UnlockMutex(counter_lock);
    return 37;
}

static int SDLCALL broadcast_worker(void *unused)
{
    int result;

    SDL_LockMutex(counter_lock);
    SDL_SemPost(waiting);
    while (!broadcast_release) {
        result = SDL_CondWaitTimeout(condition, counter_lock, 1000);
        if (result != 0) {
            SDL_UnlockMutex(counter_lock);
            return 3;
        }
    }
    ++broadcast_observed;
    SDL_UnlockMutex(counter_lock);
    return 71;
}

static int SDLCALL contention_worker(void *unused)
{
    int index;

    if (SDL_SemWaitTimeout(contention_start, 1000) != 0) return 4;
    for (index = 0; index < CONTENTION_LOOPS; ++index) {
        if (SDL_LockMutex(contention_lock) != 0) return 5;
        ++contention_counter;
        if (SDL_UnlockMutex(contention_lock) != 0) return 6;
    }
    return 73;
}

int main(int argc, char **argv)
{
    SDL_Thread *thread;
    SDL_Thread *broadcast_one;
    SDL_Thread *broadcast_two;
    SDL_Thread *contention_threads[CONTENTION_WORKERS];
    int status;
    int broadcast_status_one;
    int broadcast_status_two;
    int contention_status[CONTENTION_WORKERS];
    int timeout_result;
    int index;
    Uint32 timeout_before;
    Uint32 timeout_after;

    if (SDL_Init(SDL_INIT_TIMER) != 0) {
        fprintf(stderr, "SDL_THREAD_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    counter_lock = SDL_CreateMutex();
    ready = SDL_CreateSemaphore(0);
    waiting = SDL_CreateSemaphore(0);
    condition = SDL_CreateCond();
    if ((counter_lock == NULL) || (ready == NULL) || (waiting == NULL) ||
        (condition == NULL)) {
        fprintf(stderr, "SDL_THREAD_SYNC_CREATE_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    SDL_LockMutex(counter_lock);
    timeout_before = SDL_GetTicks();
    timeout_result = SDL_CondWaitTimeout(condition, counter_lock, 30);
    timeout_after = SDL_GetTicks();
    SDL_UnlockMutex(counter_lock);
    if ((timeout_result != SDL_MUTEX_TIMEDOUT) ||
        (timeout_after < timeout_before) ||
        ((timeout_after - timeout_before) < 20)) {
        fprintf(stderr, "SDL_THREAD_TIMEOUT_BAD: %d %lu\n", timeout_result,
                (unsigned long)(timeout_after - timeout_before));
        return 1;
    }
    thread = SDL_CreateThread(worker, NULL);
    if (thread == NULL) {
        fprintf(stderr, "SDL_THREAD_CREATE_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    if (SDL_SemWaitTimeout(ready, 1000) != 0) {
        fprintf(stderr, "SDL_THREAD_WAIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    if (SDL_SemWaitTimeout(waiting, 1000) != 0) {
        fprintf(stderr, "SDL_THREAD_COND_WAIT_READY_FAILED: %s\n",
                SDL_GetError());
        return 1;
    }
    SDL_LockMutex(counter_lock);
    release_worker = 1;
    if (SDL_CondSignal(condition) != 0) {
        fprintf(stderr, "SDL_THREAD_SIGNAL_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    SDL_UnlockMutex(counter_lock);
    status = -1;
    SDL_WaitThread(thread, &status);
    broadcast_one = SDL_CreateThread(broadcast_worker, NULL);
    broadcast_two = SDL_CreateThread(broadcast_worker, NULL);
    if ((broadcast_one == NULL) || (broadcast_two == NULL)) {
        fprintf(stderr, "SDL_THREAD_BROADCAST_CREATE_FAILED: %s\n",
                SDL_GetError());
        return 1;
    }
    for (index = 0; index < 2; ++index) {
        if (SDL_SemWaitTimeout(waiting, 1000) != 0) {
            fprintf(stderr, "SDL_THREAD_BROADCAST_READY_FAILED: %s\n",
                    SDL_GetError());
            return 1;
        }
    }
    SDL_LockMutex(counter_lock);
    broadcast_release = 1;
    if (SDL_CondBroadcast(condition) != 0) {
        fprintf(stderr, "SDL_THREAD_BROADCAST_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    SDL_UnlockMutex(counter_lock);
    broadcast_status_one = -1;
    broadcast_status_two = -1;
    SDL_WaitThread(broadcast_one, &broadcast_status_one);
    SDL_WaitThread(broadcast_two, &broadcast_status_two);
    contention_lock = SDL_CreateMutex();
    contention_start = SDL_CreateSemaphore(0);
    if ((contention_lock == NULL) || (contention_start == NULL)) {
        fprintf(stderr, "SDL_THREAD_CONTENTION_CREATE_FAILED: %s\n",
                SDL_GetError());
        return 1;
    }
    for (index = 0; index < CONTENTION_WORKERS; ++index) {
        contention_threads[index] = SDL_CreateThread(contention_worker, NULL);
        if (contention_threads[index] == NULL) {
            fprintf(stderr, "SDL_THREAD_CONTENTION_THREAD_FAILED: %s\n",
                    SDL_GetError());
            return 1;
        }
    }
    for (index = 0; index < CONTENTION_WORKERS; ++index) {
        SDL_SemPost(contention_start);
    }
    for (index = 0; index < CONTENTION_WORKERS; ++index) {
        contention_status[index] = -1;
        SDL_WaitThread(contention_threads[index], &contention_status[index]);
        if (contention_status[index] != 73) {
            fprintf(stderr, "SDL_THREAD_CONTENTION_STATUS_BAD: %d\n",
                    contention_status[index]);
            return 1;
        }
    }
    SDL_DestroySemaphore(contention_start);
    SDL_DestroyMutex(contention_lock);
    SDL_DestroyCond(condition);
    SDL_DestroySemaphore(waiting);
    SDL_DestroySemaphore(ready);
    SDL_DestroyMutex(counter_lock);
    if ((counter != 1) || (condition_observed != 1) ||
        (condition_wait_result != 0) || (status != 37) ||
        (broadcast_observed != 2) || (broadcast_status_one != 71) ||
        (broadcast_status_two != 71) ||
        (contention_counter != (CONTENTION_WORKERS * CONTENTION_LOOPS))) {
        fprintf(stderr, "SDL_THREAD_BAD_RESULT: %d %d %d %d %d %d %d %d\n",
                counter, condition_observed, condition_wait_result, status,
                broadcast_observed, broadcast_status_one, broadcast_status_two,
                contention_counter);
        return 1;
    }
    for (index = 0; index < 3; ++index) {
        SDL_Quit();
        if ((index != 2) && (SDL_Init(SDL_INIT_TIMER) != 0)) {
            fprintf(stderr, "SDL_THREAD_REINIT_FAILED: %s\n", SDL_GetError());
            return 1;
        }
    }
    fprintf(stderr, "SDL_THREAD_OK\n");
    return 0;
}
