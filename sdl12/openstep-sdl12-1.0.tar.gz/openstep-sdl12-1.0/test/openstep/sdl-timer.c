/* Runtime test that needs no WindowServer connection. */
#include "SDL.h"
#include <stdio.h>

static volatile int timer_hits;

static Uint32 SDLCALL timer_callback(Uint32 interval)
{
    ++timer_hits;
    return 0;
}

int main(int argc, char **argv)
{
    Uint32 before;
    Uint32 after;
    Uint32 last;
    int index;

    if (SDL_Init(SDL_INIT_TIMER) != 0) {
        fprintf(stderr, "SDL_TIMER_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    before = SDL_GetTicks();
    SDL_Delay(40);
    after = SDL_GetTicks();
    if (after < before || (after - before) < 20) {
        fprintf(stderr, "SDL_TIMER_BAD_DELTA: %lu\n",
                (unsigned long)(after - before));
        return 1;
    }
    last = after;
    for (index = 0; index < 10; ++index) {
        SDL_Delay(10);
        after = SDL_GetTicks();
        if (after < last) {
            fprintf(stderr, "SDL_TIMER_NONMONOTONIC: %lu %lu\n",
                    (unsigned long)last, (unsigned long)after);
            return 1;
        }
        last = after;
    }
    if (SDL_SetTimer(20, timer_callback) != 0) {
        fprintf(stderr, "SDL_TIMER_SET_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    for (index = 0; (index < 20) && (timer_hits == 0); ++index) SDL_Delay(10);
    SDL_SetTimer(0, NULL);
    SDL_Quit();
    if (timer_hits != 1) {
        fprintf(stderr, "SDL_TIMER_CALLBACK_BAD: %d\n", timer_hits);
        return 1;
    }
    fprintf(stderr, "SDL_TIMER_OK: %lu callback=%d\n",
            (unsigned long)(after - before), timer_hits);
    return 0;
}
