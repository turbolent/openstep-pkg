#!/bin/csh -f
# Run external xflame-1.0 in the WindowServer session.

set program_dir = /tmp/SDL12/src/external-build/xflame-1.0
set program = $program_dir/sdl-xflame
set log = /tmp/SDL12/log/external-xflame.log

if (! -x $program) then
    echo "run-external-xflame: missing $program"
    echo "build it first: /bin/csh -f /tmp/SDL12/src/test/openstep/build-external-xflame.csh"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

cd $program_dir
echo "Watch the animated 8bpp flame and partial updates, then press any key."
$program >&! $log
set program_status = $status
echo "external xflame exit status: $program_status (log: $log)"
exit $program_status
