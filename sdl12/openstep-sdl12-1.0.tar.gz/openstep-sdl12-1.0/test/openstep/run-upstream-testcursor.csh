#!/bin/csh -f
# Run SDL 1.2.15's upstream testcursor in the WindowServer session.

set program_dir = /tmp/SDL12/src/test/openstep/upstream-testcursor
set program = $program_dir/sdl-testcursor
set log = /tmp/SDL12/log/upstream-testcursor.log

if (! -x $program) then
    echo "run-upstream-testcursor: missing $program"
    echo "build it first: /bin/csh -f /tmp/SDL12/src/test/openstep/build-upstream-testcursor.csh"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

cd $program_dir
echo "Click three times to cycle 16x16, 32x32 and 8x11 cursors; press Escape."
$program >&! $log
set program_status = $status
echo "upstream testcursor exit status: $program_status (log: $log)"
exit $program_status
