#!/bin/csh -f
# Build SDL 1.2.15's unmodified test/testcursor.c for OPENSTEP.

set upstream_test = /ndrv/openstep-sdl12/upstream/SDL-1.2.15/test
set build_dir = /tmp/SDL12/src/test/openstep/upstream-testcursor
set overlay = /tmp/SDL12/build/SDL-1.2.15-openstep

if (! -r $upstream_test/testcursor.c) then
    echo "build-upstream-testcursor: missing $upstream_test/testcursor.c"
    exit 1
endif
if (! -r $overlay/libSDL.a) then
    echo "build-upstream-testcursor: missing $overlay/libSDL.a"
    exit 1
endif

if (! -d $build_dir) mkdir $build_dir
cp $upstream_test/testcursor.c $build_dir/testcursor.c

cd $build_dir
cc -m486 -O -Wall -D__OPENSTEP__ -I$overlay/include -o sdl-testcursor testcursor.c $overlay/libSDL.a -framework AppKit -framework Foundation -framework SoundKit
if ($status != 0) exit 1
/bin/csh -f $overlay/fix-macho-i486-subtype.csh sdl-testcursor
if ($status != 0) exit 1

echo "build-upstream-testcursor: built $build_dir/sdl-testcursor"
exit 0
