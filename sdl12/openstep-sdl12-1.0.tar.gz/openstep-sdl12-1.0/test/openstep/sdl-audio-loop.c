/* Continuous SDL WAV playback regression for the OPENSTEP audio backend. */
#include "SDL.h"
#include <stdio.h>
#include <stdlib.h>

struct LoopData {
    Uint8 *data;
    Uint32 length;
    Uint32 position;
    Uint32 callbacks;
    Uint32 bytes;
};

static void SDLCALL fill_loop(void *userdata, Uint8 *stream, int length)
{
    struct LoopData *loop;
    Uint32 remaining;
    Uint32 amount;
    Uint32 written;

    loop = (struct LoopData *)userdata;
    written = 0;
    while (written < (Uint32)length) {
        if (loop->position >= loop->length) loop->position = 0;
        remaining = loop->length - loop->position;
        amount = ((Uint32)length - written < remaining) ?
                 (Uint32)length - written : remaining;
        SDL_memcpy(stream + written, loop->data + loop->position, amount);
        loop->position += amount;
        written += amount;
    }
    ++loop->callbacks;
    loop->bytes += (Uint32)length;
}

int main(int argc, char **argv)
{
    SDL_AudioSpec wanted;
    Uint8 *buffer;
    Uint32 length;
    Uint32 started;
    Uint32 elapsed;
    int seconds;
    int result;
    struct LoopData loop;
    const char *path;

    path = "/tmp/SDL12/audio/hiyuki-openstep-test-15s-44100-s16.wav";
    seconds = 300;
    if (argc > 1) path = argv[1];
    if (argc > 2) seconds = atoi(argv[2]);
    if ((seconds < 1) || (seconds > 300)) {
        fprintf(stderr, "usage: sdl-audio-loop [wav] [seconds: 1..300]\n");
        return 2;
    }
    if (SDL_Init(SDL_INIT_AUDIO | SDL_INIT_TIMER) != 0) {
        fprintf(stderr, "SDL_AUDIO_LOOP_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    if (SDL_LoadWAV(path, &wanted, &buffer, &length) == NULL) {
        fprintf(stderr, "SDL_AUDIO_LOOP_LOAD_FAILED: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
    if ((wanted.format != AUDIO_S16LSB) ||
        ((wanted.channels != 1) && (wanted.channels != 2))) {
        fprintf(stderr, "SDL_AUDIO_LOOP_UNSUPPORTED: format=0x%x channels=%d\n",
                wanted.format, wanted.channels);
        SDL_FreeWAV(buffer);
        SDL_Quit();
        return 1;
    }
    loop.data = buffer;
    loop.length = length;
    loop.position = 0;
    loop.callbacks = 0;
    loop.bytes = 0;
    wanted.callback = fill_loop;
    wanted.userdata = &loop;
    if (SDL_OpenAudio(&wanted, NULL) != 0) {
        fprintf(stderr, "SDL_AUDIO_LOOP_OPEN_FAILED: %s\n", SDL_GetError());
        SDL_FreeWAV(buffer);
        SDL_Quit();
        return 1;
    }
    fprintf(stderr, "SDL_AUDIO_LOOP_READY: %d seconds, %d Hz, %d ch\n",
            seconds, wanted.freq, wanted.channels);
    started = SDL_GetTicks();
    SDL_PauseAudio(0);
    while ((SDL_GetTicks() - started) < (Uint32)(seconds * 1000)) {
        SDL_Delay(100);
    }
    SDL_CloseAudio();
    elapsed = SDL_GetTicks() - started;
    SDL_FreeWAV(buffer);
    result = (loop.callbacks != 0);
    /* Record after SDL_CloseAudio() has drained the native queue, but before
       the final global SDL teardown. */
    if (!result) {
        fprintf(stderr, "SDL_AUDIO_LOOP_NO_CALLBACK\n");
        SDL_Quit();
        return 1;
    }
    fprintf(stderr, "SDL_AUDIO_LOOP_OK: callbacks=%lu bytes=%lu elapsed=%lu\n",
            (unsigned long)loop.callbacks, (unsigned long)loop.bytes,
            (unsigned long)elapsed);
    SDL_Quit();
    return 0;
}
