/* SDL pause/resume/close regression for the OPENSTEP SoundKit backend. */
#include "SDL.h"
#include <stdio.h>

struct PauseData {
    Uint8 *data;
    Uint32 length;
    Uint32 position;
    Uint32 callbacks;
};

static void SDLCALL fill_loop(void *userdata, Uint8 *stream, int length)
{
    struct PauseData *audio;
    Uint32 remaining;
    Uint32 amount;
    Uint32 written;

    audio = (struct PauseData *)userdata;
    written = 0;
    while (written < (Uint32)length) {
        if (audio->position >= audio->length) audio->position = 0;
        remaining = audio->length - audio->position;
        amount = ((Uint32)length - written < remaining) ?
                 (Uint32)length - written : remaining;
        SDL_memcpy(stream + written, audio->data + audio->position, amount);
        audio->position += amount;
        written += amount;
    }
    ++audio->callbacks;
}

int main(int argc, char **argv)
{
    SDL_AudioSpec wanted;
    Uint8 *buffer;
    Uint32 length;
    Uint32 before_pause;
    Uint32 after_pause;
    Uint32 after_resume;
    struct PauseData audio;
    const char *path;

    path = "/tmp/SDL12/audio/hiyuki-openstep-test-15s-44100-s16.wav";
    if (argc > 1) path = argv[1];
    if (SDL_Init(SDL_INIT_AUDIO | SDL_INIT_TIMER) != 0) {
        fprintf(stderr, "SDL_AUDIO_PAUSE_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    if (SDL_LoadWAV(path, &wanted, &buffer, &length) == NULL) {
        fprintf(stderr, "SDL_AUDIO_PAUSE_LOAD_FAILED: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
    audio.data = buffer;
    audio.length = length;
    audio.position = 0;
    audio.callbacks = 0;
    wanted.callback = fill_loop;
    wanted.userdata = &audio;
    if (SDL_OpenAudio(&wanted, NULL) != 0) {
        fprintf(stderr, "SDL_AUDIO_PAUSE_OPEN_FAILED: %s\n", SDL_GetError());
        SDL_FreeWAV(buffer);
        SDL_Quit();
        return 1;
    }
    if (SDL_GetAudioStatus() != SDL_AUDIO_PAUSED) {
        fprintf(stderr, "SDL_AUDIO_PAUSE_INITIAL_STATE_BAD\n");
        SDL_CloseAudio();
        SDL_FreeWAV(buffer);
        SDL_Quit();
        return 1;
    }
    SDL_PauseAudio(0);
    SDL_Delay(1000);
    SDL_LockAudio();
    SDL_PauseAudio(1);
    before_pause = audio.callbacks;
    SDL_UnlockAudio();
    if ((before_pause == 0) || (SDL_GetAudioStatus() != SDL_AUDIO_PAUSED)) {
        fprintf(stderr, "SDL_AUDIO_PAUSE_START_BAD: %lu\n",
                (unsigned long)before_pause);
        SDL_CloseAudio();
        SDL_FreeWAV(buffer);
        SDL_Quit();
        return 1;
    }
    SDL_Delay(1000);
    SDL_LockAudio();
    after_pause = audio.callbacks;
    SDL_PauseAudio(0);
    SDL_UnlockAudio();
    SDL_Delay(1000);
    SDL_LockAudio();
    after_resume = audio.callbacks;
    SDL_UnlockAudio();
    if ((after_pause != before_pause) || (after_resume <= after_pause) ||
        (SDL_GetAudioStatus() != SDL_AUDIO_PLAYING)) {
        fprintf(stderr, "SDL_AUDIO_PAUSE_CALLBACK_BAD: %lu %lu %lu\n",
                (unsigned long)before_pause, (unsigned long)after_pause,
                (unsigned long)after_resume);
        SDL_CloseAudio();
        SDL_FreeWAV(buffer);
        SDL_Quit();
        return 1;
    }
    SDL_CloseAudio();
    if (SDL_GetAudioStatus() != SDL_AUDIO_STOPPED) {
        fprintf(stderr, "SDL_AUDIO_PAUSE_CLOSE_STATE_BAD\n");
        SDL_FreeWAV(buffer);
        SDL_Quit();
        return 1;
    }
    SDL_FreeWAV(buffer);
    SDL_Quit();
    fprintf(stderr, "SDL_AUDIO_PAUSE_OK: %lu %lu %lu\n",
            (unsigned long)before_pause, (unsigned long)after_pause,
            (unsigned long)after_resume);
    return 0;
}
