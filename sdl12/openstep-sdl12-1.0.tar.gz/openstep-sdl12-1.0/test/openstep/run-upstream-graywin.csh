#!/bin/csh -f
# Run SDL 1.2.15's upstream graywin in OPENSTEP's windowed 8bpp mode.

set program_dir = /tmp/SDL12/src/test/openstep/upstream-graywin
set program = $program_dir/sdl-graywin
set log = /tmp/SDL12/log/upstream-graywin.log

if (! -x $program) then
    echo "run-upstream-graywin: missing $program"
    echo "build it first: /bin/csh -f /tmp/SDL12/src/test/openstep/build-upstream-graywin.csh"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

cd $program_dir
echo "SDL upstream graywin: click once near the top, then press Escape"
$program >&! $log
set program_status = $status
echo "upstream graywin exit status: $program_status (log: $log)"
exit $program_status
