/* SoundKit audible test using SDL_LoadWAV() on user-supplied local media. */
#include "SDL.h"
#include <stdio.h>

struct WAVData {
    Uint8 *data;
    Uint32 length;
    Uint32 position;
};

static void SDLCALL fill_audio(void *userdata, Uint8 *stream, int length)
{
    struct WAVData *wav;
    Uint32 remaining;
    Uint32 amount;

    wav = (struct WAVData *)userdata;
    SDL_memset(stream, 0, length);
    if (wav->position >= wav->length) return;
    remaining = wav->length - wav->position;
    amount = (remaining < (Uint32)length) ? remaining : (Uint32)length;
    SDL_memcpy(stream, wav->data + wav->position, amount);
    wav->position += amount;
}

int main(int argc, char **argv)
{
    SDL_AudioSpec wanted;
    Uint8 *buffer;
    Uint32 length;
    struct WAVData wav;
    const char *path;

    path = (argc == 2) ? argv[1] : "/tmp/SDL12/audio/hiyuki-openstep-test-15s-44100-s16.wav";
    if (SDL_Init(SDL_INIT_AUDIO | SDL_INIT_TIMER) != 0) {
        fprintf(stderr, "SDL_WAV_AUDIO_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    if (SDL_LoadWAV(path, &wanted, &buffer, &length) == NULL) {
        fprintf(stderr, "SDL_WAV_AUDIO_LOAD_FAILED: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
    if ((wanted.format != AUDIO_S16LSB) ||
        ((wanted.channels != 1) && (wanted.channels != 2))) {
        fprintf(stderr, "SDL_WAV_AUDIO_UNSUPPORTED: format=0x%x channels=%d\n",
                wanted.format, wanted.channels);
        SDL_FreeWAV(buffer);
        SDL_Quit();
        return 1;
    }
    wav.data = buffer;
    wav.length = length;
    wav.position = 0;
    wanted.callback = fill_audio;
    wanted.userdata = &wav;
    wanted.samples = 1024;
    if (SDL_OpenAudio(&wanted, NULL) != 0) {
        fprintf(stderr, "SDL_WAV_AUDIO_OPEN_FAILED: %s\n", SDL_GetError());
        SDL_FreeWAV(buffer);
        SDL_Quit();
        return 1;
    }
    fprintf(stderr, "SDL_WAV_AUDIO_READY: %s (%lu bytes, %d Hz, %d ch)\n",
            path, (unsigned long)length, wanted.freq, wanted.channels);
    SDL_PauseAudio(0);
    while (wav.position < wav.length) SDL_Delay(100);
    SDL_Delay(250);
    SDL_CloseAudio();
    SDL_FreeWAV(buffer);
    SDL_Quit();
    fprintf(stderr, "SDL_WAV_AUDIO_OK\n");
    return 0;
}
