/* WindowServer-only SDL_WaitEvent() smoke test for the OPENSTEP driver. */
#include "SDL.h"
#include <stdio.h>

int main(int argc, char **argv)
{
    SDL_Surface *screen;
    SDL_Event event;
    FILE *report;
    int wait_result;
    int finished;

    report = fopen("/tmp/SDL12/log/sdl-wait-event.log", "w");
    if (report == NULL) report = stderr;
    else setbuf(report, NULL);
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) != 0) {
        fprintf(report, "SDL_WAIT_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    screen = SDL_SetVideoMode(320, 180, 24, SDL_SWSURFACE);
    if (screen == NULL) {
        fprintf(report, "SDL_WAIT_VIDEO_FAILED: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
    SDL_WM_SetCaption("SDL WaitEvent: click or press a key", NULL);
    SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 32, 96, 160));
    SDL_UpdateRect(screen, 0, 0, 0, 0);
    fprintf(report, "SDL_WAIT_READY\n");

    wait_result = 1;
    finished = 0;
    while (!finished && ((wait_result = SDL_WaitEvent(&event)) == 1)) {
        if (event.type == SDL_KEYDOWN) {
            fprintf(report, "SDL_WAIT_KEYDOWN: %d\n", (int)event.key.keysym.sym);
            finished = 1;
        } else if (event.type == SDL_MOUSEBUTTONDOWN) {
            fprintf(report, "SDL_WAIT_MOUSE: %d %d %d\n",
                    (int)event.button.button, (int)event.button.x,
                    (int)event.button.y);
            finished = 1;
        } else if (event.type == SDL_QUIT) {
            fprintf(report, "SDL_WAIT_QUIT\n");
            finished = 1;
        } else {
            fprintf(report, "SDL_WAIT_INTERNAL: %d\n", (int)event.type);
        }
    }
    if (wait_result != 1) {
        fprintf(report, "SDL_WAIT_FAILED: %s\n", SDL_GetError());
        if (report != stderr) fclose(report);
        SDL_Quit();
        return 1;
    }
    fprintf(report, "SDL_WAIT_OK\n");
    if (report != stderr) fclose(report);
    SDL_Quit();
    return 0;
}
