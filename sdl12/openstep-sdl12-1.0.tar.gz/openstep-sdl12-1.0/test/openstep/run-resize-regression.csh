#!/bin/csh -f
# Run SDL_RESIZABLE regression in the WindowServer session.

set program = /tmp/SDL12/src/test/openstep/sdl-resize-regression
set log = /tmp/SDL12/log/sdl-resize-regression.log

if (! -x $program) then
    echo "run-resize-regression: missing $program"
    echo "build it first: cd /tmp/SDL12/src/test/openstep; make sdl-resize-regression"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

echo "Resize the SDL window to two different sizes, then press Escape."
$program >&! $log
set program_status = $status
echo "resize regression exit status: $program_status (log: $log)"
exit $program_status
