#!/bin/csh -f
# Build the unmodified external xflame-1.0 SDL program for OPENSTEP.

set source_dir = /ndrv/openstep-sdl12/external/xflame-1.0
set build_dir = /tmp/SDL12/src/external-build/xflame-1.0
set overlay = /tmp/SDL12/build/SDL-1.2.15-openstep

if (! -r $source_dir/main.c) then
    echo "build-external-xflame: missing $source_dir/main.c"
    exit 1
endif
if (! -r $overlay/libSDL.a) then
    echo "build-external-xflame: missing $overlay/libSDL.a"
    exit 1
endif
if (! -d /tmp/SDL12/src/external-build) mkdir /tmp/SDL12/src/external-build
if (! -d $build_dir) mkdir $build_dir
cp $source_dir/main.c $build_dir/main.c
cp $source_dir/README $build_dir/README

cd $build_dir
if (! -e SDL) ln -s $overlay/include SDL
cc -m486 -O -Wall -D__OPENSTEP__ -I. -o sdl-xflame main.c $overlay/libSDL.a -framework AppKit -framework Foundation -framework SoundKit
if ($status != 0) exit 1
/bin/csh -f $overlay/fix-macho-i486-subtype.csh sdl-xflame
if ($status != 0) exit 1

echo "build-external-xflame: built $build_dir/sdl-xflame"
exit 0
