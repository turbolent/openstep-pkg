#!/bin/csh -f
# Run the native OPENSTEP SDL audio-only endurance regression.
# Optional argument: duration in seconds (1..300); default is five minutes.

set program_dir = /tmp/SDL12/src/test/openstep
set wav = /ndrv/openstep-sdl12/assets/hiyuki-openstep-test-15s-44100-s16.wav
set seconds = 300
set log = /tmp/SDL12/log/sdl-audio-loop.log

if ($#argv == 1) then
    set seconds = $argv[1]
endif

if (! -x $program_dir/sdl-audio-loop) then
    echo "run-audio-loop: missing $program_dir/sdl-audio-loop"
    echo "build it first: cd $program_dir; make sdl-audio-loop"
    exit 1
endif
if (! -r $wav) then
    echo "run-audio-loop: cannot read $wav"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

echo "SDL audio-only loop: $seconds seconds"
$program_dir/sdl-audio-loop $wav $seconds >&! $log
set program_status = $status
echo "audio-loop exit status: $program_status (log: $log)"
exit $program_status
