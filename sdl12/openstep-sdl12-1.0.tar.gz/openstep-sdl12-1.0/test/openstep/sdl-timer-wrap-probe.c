/* Exercise OPENSTEP SDL_GetTicks arithmetic at its documented wrap point. */
#include "SDL.h"
#include <stdio.h>
#include <sys/time.h>

extern Uint32 SDL_OPENSTEP_TicksFromTime(const struct timeval *origin,
                                        const struct timeval *sample);

int main(int argc, char **argv)
{
    struct timeval origin;
    struct timeval sample;
    Uint32 ticks;

    (void)argc;
    (void)argv;
    origin.tv_sec = 100;
    origin.tv_usec = 900000;

    sample.tv_sec = 100;
    sample.tv_usec = 940000;
    ticks = SDL_OPENSTEP_TicksFromTime(&origin, &sample);
    if (ticks != 40U) {
        fprintf(stderr, "SDL_TIMER_ARITHMETIC_SHORT_BAD: %lu\n",
                (unsigned long)ticks);
        return 1;
    }

    /* Elapsed = 2^32 + 1234 milliseconds. */
    sample.tv_sec = 4295069;
    sample.tv_usec = 430000;
    ticks = SDL_OPENSTEP_TicksFromTime(&origin, &sample);
    if (ticks != 1234U) {
        fprintf(stderr, "SDL_TIMER_ARITHMETIC_WRAP_BAD: %lu\n",
                (unsigned long)ticks);
        return 1;
    }

    sample.tv_sec = 99;
    sample.tv_usec = 900000;
    ticks = SDL_OPENSTEP_TicksFromTime(&origin, &sample);
    if (ticks != 0U) {
        fprintf(stderr, "SDL_TIMER_ARITHMETIC_BACKWARD_BAD: %lu\n",
                (unsigned long)ticks);
        return 1;
    }
    fprintf(stderr, "SDL_TIMER_WRAP_OK: %lu\n", (unsigned long)1234U);
    return 0;
}
