#!/bin/csh -f
# Build SDL 1.2.15's unmodified test/testwm.c for the OPENSTEP backend.
# Read-only inputs stay on NFS; every generated file stays below /tmp/SDL12.

set upstream_test = /ndrv/openstep-sdl12/upstream/SDL-1.2.15/test
set build_dir = /tmp/SDL12/src/test/openstep/upstream-testwm
set overlay = /tmp/SDL12/build/SDL-1.2.15-openstep

if (! -r $upstream_test/testwm.c) then
    echo "build-upstream-testwm: missing $upstream_test/testwm.c"
    exit 1
endif
if (! -r $upstream_test/icon.bmp) then
    echo "build-upstream-testwm: missing $upstream_test/icon.bmp"
    exit 1
endif
if (! -r $overlay/libSDL.a) then
    echo "build-upstream-testwm: missing $overlay/libSDL.a"
    exit 1
endif

if (! -d $build_dir) mkdir $build_dir
cp $upstream_test/testwm.c $build_dir/testwm.c
cp $upstream_test/icon.bmp $build_dir/icon.bmp

cd $build_dir
cc -m486 -O -Wall -D__OPENSTEP__ -I$overlay/include -o sdl-testwm testwm.c $overlay/libSDL.a -framework AppKit -framework Foundation -framework SoundKit
if ($status != 0) exit 1
/bin/csh -f $overlay/fix-macho-i486-subtype.csh sdl-testwm
if ($status != 0) exit 1

echo "build-upstream-testwm: built $build_dir/sdl-testwm"
exit 0
