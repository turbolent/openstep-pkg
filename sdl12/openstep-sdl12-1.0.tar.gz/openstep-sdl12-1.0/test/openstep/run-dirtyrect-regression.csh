#!/bin/csh -f
# Run the SDL_UpdateRect clipping regression in the WindowServer session.

set program = /tmp/SDL12/src/test/openstep/sdl-dirtyrect-regression
set log = /tmp/SDL12/log/sdl-dirtyrect-regression.log

if (! -x $program) then
    echo "run-dirtyrect-regression: missing $program"
    echo "build it first: cd /tmp/SDL12/src/test/openstep; make sdl-dirtyrect-regression"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

echo "First only the upper-left red rectangle should appear; then lower-right green."
$program >&! $log
set program_status = $status
echo "dirty-rect regression exit status: $program_status (log: $log)"
exit $program_status
