#!/bin/csh -f
# Run the native SDL cursor visibility/custom-cursor regression in WindowServer.

set program = /tmp/SDL12/src/test/openstep/sdl-cursor-regression
set log = /tmp/SDL12/log/sdl-cursor-regression.log

if (! -x $program) then
    echo "run-cursor-regression: missing $program"
    echo "build it first: cd /tmp/SDL12/src/test/openstep; make sdl-cursor-regression"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

echo "Move the pointer into the SDL window and watch all four 4-second phases."
$program >&! $log
set program_status = $status
echo "cursor regression exit status: $program_status (log: $log)"
exit $program_status
