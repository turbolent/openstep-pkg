/* Inspect SIGALRM disposition after SDL_INIT_TIMER without changing SDL state.
 * The temporary SIG_IGN assignment is immediately restored before exit.
 */
#include "SDL.h"
#include <signal.h>
#include <stdio.h>

int main(int argc, char **argv)
{
    void (*previous)(int);

    if (SDL_Init(SDL_INIT_TIMER) != 0) {
        fprintf(stderr, "SDL_SIGNAL_PROBE_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    previous = signal(SIGALRM, SIG_IGN);
    if (previous == SIG_ERR) {
        fprintf(stderr, "SDL_SIGNAL_PROBE_QUERY_FAILED\n");
        SDL_Quit();
        return 1;
    }
    signal(SIGALRM, previous);
    SDL_Quit();
    if (previous == SIG_DFL) {
        fprintf(stderr, "SDL_SIGNAL_PROBE_HANDLER: default\n");
        return 1;
    }
    if (previous == SIG_IGN) {
        fprintf(stderr, "SDL_SIGNAL_PROBE_HANDLER: ignored\n");
        return 1;
    }
    fprintf(stderr, "SDL_SIGNAL_PROBE_HANDLER: custom\n");
    return 0;
}
