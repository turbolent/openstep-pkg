#!/bin/csh -f
# Run the OPENSTEP SDL 1.2 audio + video regression from a GUI Terminal.
# Optional argument: duration in seconds (1..300); default is five minutes.

# This target's old csh does not expand the modern $0:h shorthand.
set program_dir = /tmp/SDL12/src/test/openstep
set wav = /ndrv/openstep-sdl12/assets/hiyuki-openstep-test-15s-44100-s16.wav
set seconds = 300

if ($#argv == 1) then
    set seconds = $argv[1]
endif

if (! -x "$program_dir/sdl-av-stress") then
    echo "run-av-stress: missing $program_dir/sdl-av-stress"
    echo "build it first: cd $program_dir; make sdl-av-stress"
    exit 1
endif

if (! -r "$wav") then
    echo "run-av-stress: cannot read $wav"
    exit 1
endif

if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

echo "SDL AV stress: $seconds seconds (close the SDL window only to abort)"
$program_dir/sdl-av-stress $wav $seconds
exit $status
