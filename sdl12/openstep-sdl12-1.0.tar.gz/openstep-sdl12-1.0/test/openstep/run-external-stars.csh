#!/bin/csh -f
# Run external stars-1.0 in the WindowServer session.

set program_dir = /tmp/SDL12/src/external-build/stars-1.0
set program = $program_dir/sdl-stars
set log = /tmp/SDL12/log/external-stars.log

if (! -x $program) then
    echo "run-external-stars: missing $program"
    echo "build it first: /bin/csh -f /tmp/SDL12/src/test/openstep/build-external-stars.csh"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

cd $program_dir
echo "Watch the rotating starfield, then press any key to exit."
$program >&! $log
set program_status = $status
echo "external stars exit status: $program_status (log: $log)"
exit $program_status
