/* SDL 1.2 OPENSTEP native cursor visibility/custom-cursor regression. */
#include <stdio.h>
#include <stdlib.h>

#include "SDL.h"

#define PHASE_MILLISECONDS 4000

static int pump_for(Uint32 milliseconds)
{
    Uint32 start;
    SDL_Event event;

    start = SDL_GetTicks();
    while ((SDL_GetTicks() - start) < milliseconds) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) return 0;
            if ((event.type == SDL_KEYDOWN) &&
                (event.key.keysym.sym == SDLK_ESCAPE)) return 0;
        }
        SDL_Delay(10);
    }
    return 1;
}

static void show_phase(SDL_Surface *screen, const char *title,
                       Uint8 red, Uint8 green, Uint8 blue)
{
    Uint32 color;

    SDL_WM_SetCaption(title, title);
    color = SDL_MapRGB(screen->format, red, green, blue);
    SDL_FillRect(screen, NULL, color);
    SDL_UpdateRect(screen, 0, 0, 0, 0);
    printf("SDL_CURSOR_PHASE: %s\n", title);
    fflush(stdout);
}

int main(int argc, char **argv)
{
    static Uint8 cursor_data[32] = {
        0x80, 0x00, 0xc0, 0x00, 0xe0, 0x00, 0xf0, 0x00,
        0xf8, 0x00, 0xfc, 0x00, 0xfe, 0x00, 0xff, 0x00,
        0xff, 0x80, 0xfc, 0x00, 0xdc, 0x00, 0x8e, 0x00,
        0x06, 0x00, 0x07, 0x00, 0x03, 0x00, 0x00, 0x00
    };
    static Uint8 cursor_mask[32] = {
        0xc0, 0x00, 0xe0, 0x00, 0xf0, 0x00, 0xf8, 0x00,
        0xfc, 0x00, 0xfe, 0x00, 0xff, 0x00, 0xff, 0x80,
        0xff, 0xc0, 0xff, 0x80, 0xfe, 0x00, 0xdf, 0x00,
        0x8f, 0x00, 0x07, 0x80, 0x03, 0x80, 0x01, 0x00
    };
    SDL_Surface *screen;
    SDL_Cursor *original;
    SDL_Cursor *custom;
    int previous;
    int query;
    int ok;

    (void)argc;
    (void)argv;
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) < 0) {
        fprintf(stderr, "SDL_CURSOR_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    screen = SDL_SetVideoMode(360, 200, 24, SDL_SWSURFACE);
    if (screen == NULL) {
        fprintf(stderr, "SDL_CURSOR_VIDEO_FAILED: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
    original = SDL_GetCursor();
    custom = SDL_CreateCursor(cursor_data, cursor_mask, 16, 16, 0, 0);
    if (custom == NULL) {
        fprintf(stderr, "SDL_CURSOR_CREATE_FAILED: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }

    ok = 1;
    query = SDL_ShowCursor(SDL_QUERY);
    if (query != SDL_ENABLE) {
        fprintf(stderr, "SDL_CURSOR_BAD_INITIAL_STATE: %d\n", query);
        ok = 0;
    }
    SDL_SetCursor(custom);
    previous = SDL_ShowCursor(SDL_ENABLE);
    query = SDL_ShowCursor(SDL_QUERY);
    if (query != SDL_ENABLE) ok = 0;
    printf("SDL_CURSOR_CUSTOM: previous=%d query=%d\n", previous, query);
    show_phase(screen, "SDL cursor 1/4: custom visible", 40, 120, 40);
    if (!pump_for(PHASE_MILLISECONDS)) goto finished;

    previous = SDL_ShowCursor(SDL_DISABLE);
    query = SDL_ShowCursor(SDL_QUERY);
    if ((previous != SDL_ENABLE) || (query != SDL_DISABLE)) ok = 0;
    printf("SDL_CURSOR_HIDDEN: previous=%d query=%d\n", previous, query);
    show_phase(screen, "SDL cursor 2/4: hidden", 120, 40, 40);
    if (!pump_for(PHASE_MILLISECONDS)) goto finished;

    previous = SDL_ShowCursor(SDL_ENABLE);
    query = SDL_ShowCursor(SDL_QUERY);
    if ((previous != SDL_DISABLE) || (query != SDL_ENABLE)) ok = 0;
    printf("SDL_CURSOR_RESHOWN: previous=%d query=%d\n", previous, query);
    show_phase(screen, "SDL cursor 3/4: custom restored", 40, 40, 120);
    if (!pump_for(PHASE_MILLISECONDS)) goto finished;

    SDL_SetCursor(original);
    show_phase(screen, "SDL cursor 4/4: default restored", 100, 60, 120);
    pump_for(PHASE_MILLISECONDS);

finished:
    SDL_SetCursor(original);
    SDL_FreeCursor(custom);
    if (ok) {
        printf("SDL_CURSOR_OK\n");
    } else {
        fprintf(stderr, "SDL_CURSOR_FAILED\n");
    }
    SDL_Quit();
    return ok ? 0 : 1;
}
