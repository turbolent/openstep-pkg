#!/bin/csh -f
# Run SDL 1.2.15's upstream testwm from a GUI Terminal.
# Escape triggers testwm's own SDL_USEREVENT quit path.

set program_dir = /tmp/SDL12/src/test/openstep/upstream-testwm
set program = $program_dir/sdl-testwm
set log = /tmp/SDL12/log/upstream-testwm.log

if (! -x $program) then
    echo "run-upstream-testwm: missing $program"
    echo "build it first: /bin/csh -f /tmp/SDL12/src/test/openstep/build-upstream-testwm.csh"
    exit 1
endif
if (! -r $program_dir/icon.bmp) then
    echo "run-upstream-testwm: missing $program_dir/icon.bmp"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

cd $program_dir
echo "SDL upstream testwm: press Escape in the SDL window to finish"
$program >&! $log
set program_status = $status
echo "upstream testwm exit status: $program_status (log: $log)"
exit $program_status
