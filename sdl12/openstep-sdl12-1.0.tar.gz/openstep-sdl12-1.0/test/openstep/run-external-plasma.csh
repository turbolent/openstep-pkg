#!/bin/csh -f
# Run external plasma-1.0 in the WindowServer session.

set program_dir = /tmp/SDL12/src/external-build/plasma-1.0
set program = $program_dir/sdl-plasma
set log = /tmp/SDL12/log/external-plasma.log

if (! -x $program) then
    echo "run-external-plasma: missing $program"
    echo "build it first: /bin/csh -f /tmp/SDL12/src/test/openstep/build-external-plasma.csh"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

cd $program_dir
echo "Watch the animated 8bpp palette plasma, then press any key to exit."
$program >&! $log
set program_status = $status
echo "external plasma exit status: $program_status (log: $log)"
exit $program_status
