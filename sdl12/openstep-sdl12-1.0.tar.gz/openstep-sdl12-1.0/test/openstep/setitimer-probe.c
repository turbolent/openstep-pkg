/* OPENSTEP BSD ITIMER_REAL/SIGALRM probe.
 *
 * This deliberately does not link SDL.  It distinguishes an OS timer/signal
 * failure from an SDL timer-backend failure before any SDL code is changed.
 */
#include <signal.h>
#include <stdio.h>
#include <sys/time.h>
#ifdef __NeXT__
#include <libc.h>
#else
#include <unistd.h>
#endif

static volatile sig_atomic_t alarm_hits;

static void alarm_handler(int signal_number)
{
    if (signal_number == SIGALRM) ++alarm_hits;
}

int main(int argc, char **argv)
{
    struct itimerval timer;
    int retries;

    timer.it_value.tv_sec = 0;
    timer.it_value.tv_usec = 20000;
    timer.it_interval.tv_sec = 0;
    timer.it_interval.tv_usec = 0;
    if (signal(SIGALRM, alarm_handler) == SIG_ERR) {
        fprintf(stderr, "SETITIMER_PROBE_SIGNAL_FAILED\n");
        return 1;
    }
    if (setitimer(ITIMER_REAL, &timer, NULL) != 0) {
        fprintf(stderr, "SETITIMER_PROBE_SET_FAILED\n");
        return 1;
    }
    for (retries = 0; (retries < 2) && (alarm_hits == 0); ++retries) {
        sleep(1);
    }
    if (alarm_hits != 1) {
        fprintf(stderr, "SETITIMER_PROBE_BAD: %d\n", (int)alarm_hits);
        return 1;
    }
    fprintf(stderr, "SETITIMER_PROBE_OK: %d\n", (int)alarm_hits);
    return 0;
}
