/* OPENSTEP SDL 1.2 video/event smoke test.  It is intended for a real
 * WindowServer console, not a telnet-only session. */
#include "SDL.h"
#include <stdio.h>
#include <stdlib.h>

#ifndef DEFAULT_BPP
#define DEFAULT_BPP 24
#endif

#ifndef DEFAULT_DURATION
#define DEFAULT_DURATION 600000
#endif

static void setup_palette(SDL_Surface *screen)
{
    SDL_Color colors[256];
    int index;

    if (screen->format->BitsPerPixel != 8) return;
    for (index = 0; index < 256; ++index) {
        colors[index].r = (Uint8)index;
        colors[index].g = (Uint8)(255 - index);
        colors[index].b = (Uint8)((index * 3) & 255);
    }
    SDL_SetColors(screen, colors, 0, 256);
}

static void put_pixel(SDL_Surface *screen, int x, int y, Uint32 color)
{
    Uint8 *pixel;

    pixel = (Uint8 *)screen->pixels + y * screen->pitch +
            x * screen->format->BytesPerPixel;
    switch (screen->format->BytesPerPixel) {
    case 1: *pixel = (Uint8)color; break;
    case 2: *((Uint16 *)pixel) = (Uint16)color; break;
    case 3:
        pixel[0] = (Uint8)(color & 255);
        pixel[1] = (Uint8)((color >> 8) & 255);
        pixel[2] = (Uint8)((color >> 16) & 255);
        break;
    default: *((Uint32 *)pixel) = color; break;
    }
}

static void draw_pattern(SDL_Surface *screen)
{
    int x;
    int y;
    Uint32 color;

    setup_palette(screen);
    for (y = 0; y < screen->h; ++y) {
        for (x = 0; x < screen->w; ++x) {
            color = SDL_MapRGB(screen->format,
                               (Uint8)((x * 255) / screen->w),
                               (Uint8)((y * 255) / screen->h),
                               (Uint8)((x ^ y) & 255));
            put_pixel(screen, x, y, color);
        }
    }
}

int main(int argc, char **argv)
{
    SDL_Surface *screen;
    SDL_Event event;
    Uint32 started;
    Uint32 duration;
    int running;
    int bpp;
    FILE *report;
    char caption[48];

    bpp = DEFAULT_BPP;
    duration = DEFAULT_DURATION;
    if (argc > 1) bpp = atoi(argv[1]);
    if (argc > 2) duration = (Uint32)(atoi(argv[2]) * 1000);
    report = fopen("/tmp/SDL12/log/sdl-video-events.log", "w");
    if (report == NULL) report = stderr;
    else setbuf(report, NULL);

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER) != 0) {
        fprintf(report, "SDL_INIT_FAILED: %s\n", SDL_GetError());
        return 1;
    }
    screen = SDL_SetVideoMode(320, 240, bpp, SDL_SWSURFACE);
    if (screen == NULL) {
        fprintf(report, "SDL_VIDEO_FAILED: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
    sprintf(caption, "SDL 1.2 OPENSTEP %dbpp", bpp);
    SDL_WM_SetCaption(caption, NULL);
    draw_pattern(screen);
    SDL_UpdateRect(screen, 0, 0, 0, 0);
    fprintf(report, "SDL_OPENSTEP_VIDEO_READY: %dbpp %lu ms\n", bpp,
            (unsigned long)duration);
    running = 1;
    started = SDL_GetTicks();
    while (running && (SDL_GetTicks() - started < duration)) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                fprintf(report, "SDL_QUIT\n");
                running = 0;
            }
            if (event.type == SDL_ACTIVEEVENT) {
                fprintf(report, "SDL_ACTIVE gain=%d state=0x%x\n",
                        (int)event.active.gain, (int)event.active.state);
            }
            if (event.type == SDL_VIDEOEXPOSE) {
                fprintf(report, "SDL_VIDEOEXPOSE\n");
            }
            if (event.type == SDL_KEYDOWN) {
                fprintf(report, "SDL_KEYDOWN sym=%d mod=0x%x unicode=%u\n",
                        (int)event.key.keysym.sym, (int)event.key.keysym.mod,
                        (unsigned int)event.key.keysym.unicode);
            }
            if (event.type == SDL_KEYUP) {
                fprintf(report, "SDL_KEYUP sym=%d mod=0x%x unicode=%u\n",
                        (int)event.key.keysym.sym, (int)event.key.keysym.mod,
                        (unsigned int)event.key.keysym.unicode);
            }
            if (event.type == SDL_MOUSEBUTTONDOWN) {
                fprintf(report, "SDL_MOUSEBUTTON %d %d %d\n",
                        (int)event.button.button, (int)event.button.x,
                        (int)event.button.y);
            }
            if (event.type == SDL_MOUSEBUTTONUP) {
                fprintf(report, "SDL_MOUSEBUTTONUP %d %d %d\n",
                        (int)event.button.button, (int)event.button.x,
                        (int)event.button.y);
            }
            if (event.type == SDL_MOUSEMOTION) {
                fprintf(report, "SDL_MOUSEMOTION state=0x%x %d %d\n",
                        (int)event.motion.state, (int)event.motion.x,
                        (int)event.motion.y);
            }
        }
        SDL_Delay(10);
    }
    fprintf(report, "SDL_OPENSTEP_VIDEO_DONE\n");
    if (report != stderr) fclose(report);
    SDL_Quit();
    return 0;
}
