# OPENSTEP platform overlay

This directory is overlaid onto a disposable SDL 1.2.15 tree under
`/tmp/SDL12/build/`; the pristine source under `upstream/` is never edited.

`include/SDL_config_openstep.h` is the conservative compiler baseline for
OPENSTEP 4.2 i386. It uses the target's BSD `u_intN_t` spellings rather than
redeclaring the signed types already supplied by `<sys/types.h>`. Native
SoundKit audio, BSD timer and Mach cthreads are enabled because their probes
and runtime regressions passed on the target machine.

`src/video/openstep/SDL_openstepvideo.m` implements a C89-compatible
Objective-C AppKit driver: 8/16/24/32bpp SDL software surfaces are converted
to a caller-owned 24bpp RGB `NSBitmapImageRep`; `displayRect:` clips dirty
updates. The NSView translates key, mouse, resize, close and expose traffic
into SDL private events. Native `NSCursor` handles cursor visibility and
small custom cursors, while DPS `PSsetmouse` implements warp. It links only
`-framework AppKit -framework Foundation`, and never adds an X11 header,
library, server, or compatibility layer dependency. The video object itself
requires AppKit and Foundation; applications linking the complete `libSDL.a`
also link SoundKit for the native audio bootstrap.

`src/timer/openstep/SDL_systimer.c` uses OPENSTEP's BSD/Mach-era
`gettimeofday`, `select`, `signal`, and `setitimer`, avoiding the unavailable
POSIX `sigaction` API in the upstream UNIX backend.  The `select` delay path
retries after `EINTR`, allowing SDL timer callbacks to run while a delay is
in progress. Wall-clock regressions are clamped at the `timeval` level while
the public Uint32 tick value retains SDL's documented approximately 49-day
wrap.

`src/thread/openstep/` maps SDL threads, recursive mutexes, conditions and
semaphores to Mach `cthreads.h`. `src/audio/openstep/SDL_openstepaudio.m`
uses the native `SNDStartPlaying(..., preempt=0)` FCFS queue with retained
PCM blocks.  `NXPlayStream` was rejected after target tests exposed byte-order
noise and buffer-boundary underruns.  Audio device availability remains a
target-session runtime requirement.

The final OPENSTEP 4.2 runs passed headless timer/thread regressions, 300-second
audio-only and audio/video stress tests, and the seven-stage WindowServer
sequence documented in `../../TESTING.md`. Fullscreen, OpenGL, hardware blits,
mouse grab/relative mode, CD-ROM, joystick, and dynamic loading remain outside
the supported port scope.
