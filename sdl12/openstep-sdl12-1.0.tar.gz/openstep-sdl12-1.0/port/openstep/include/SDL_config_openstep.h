/* OPENSTEP 4.2 i386 baseline configuration for SDL 1.2.15.
 * Keep this C89/cc 2.7 compatible: no stdint.h, C99 feature tests, or
 * assumptions about pthreads.  The enabled audio and cthreads backends use
 * OPENSTEP SoundKit and Mach cthreads rather than POSIX substitutes.
 */
#ifndef _SDL_config_openstep_h
#define _SDL_config_openstep_h

#include <sys/types.h>

/* OPENSTEP's sys/types.h provides signed intN_t and BSD u_intN_t, but not
 * the unsigned C99 spellings SDL uses. */
typedef u_int8_t uint8_t;
typedef u_int16_t uint16_t;
typedef u_int32_t uint32_t;
typedef unsigned long uintptr_t;

#define HAVE_SYS_TYPES_H 1
#define HAVE_STDIO_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STDDEF_H 1
#define HAVE_STDARG_H 1
#define HAVE_STRING_H 1
#define HAVE_STRINGS_H 1
#define HAVE_CTYPE_H 1
#define HAVE_MATH_H 1
#define HAVE_SIGNAL_H 1
#define STDC_HEADERS 1

#define HAVE_MALLOC 1
#define HAVE_CALLOC 1
#define HAVE_REALLOC 1
#define HAVE_FREE 1
#define HAVE_GETENV 1
#define HAVE_QSORT 1
#define HAVE_ABS 1
#define HAVE_MEMSET 1
#define HAVE_MEMCPY 1
#define HAVE_MEMMOVE 1
#define HAVE_MEMCMP 1
#define HAVE_STRLEN 1
#define HAVE_STRCHR 1
#define HAVE_STRRCHR 1
#define HAVE_STRSTR 1
#define HAVE_STRTOL 1
#define HAVE_STRTOD 1
#define HAVE_ATOI 1
#define HAVE_ATOF 1
#define HAVE_STRCMP 1
#define HAVE_STRNCMP 1
#define HAVE_SSCANF 1

/* No X11, OpenGL, hardware surface, or pthread fallback. */
#define SDL_AUDIO_DRIVER_OPENSTEP 1
#define SDL_CDROM_DISABLED 1
#define SDL_JOYSTICK_DISABLED 1
#define SDL_LOADSO_DISABLED 1
#define SDL_THREAD_OPENSTEP 1
#define SDL_TIMER_OPENSTEP 1
#define SDL_VIDEO_DRIVER_OPENSTEP 1

#endif /* _SDL_config_openstep_h */
