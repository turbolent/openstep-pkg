#ifndef _SDL_openstepaudio_h
#define _SDL_openstepaudio_h

#include "../SDL_sysaudio.h"

#define _THIS SDL_AudioDevice *this
#define OPENSTEP_LEGACY_SOUND_POOL 8
#define OPENSTEP_LEGACY_SOUND_KEEP 4

struct SDL_PrivateAudioData {
    Uint8 *mixbuf;
    Uint32 mixlen;
    Uint32 delay;
    void *legacy_sounds[OPENSTEP_LEGACY_SOUND_POOL];
    int legacy_tags[OPENSTEP_LEGACY_SOUND_POOL];
    int legacy_tag;
    int legacy_head;
    int legacy_count;
    int use_legacy_sound_api;
};

#endif /* _SDL_openstepaudio_h */
