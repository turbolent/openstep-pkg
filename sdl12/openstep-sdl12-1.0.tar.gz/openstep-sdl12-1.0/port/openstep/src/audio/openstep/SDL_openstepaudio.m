/* OPENSTEP native SoundKit C API streaming audio backend for SDL 1.2. */
#include "SDL_config.h"

#if SDL_AUDIO_DRIVER_OPENSTEP

#import <SoundKit/SoundKit.h>
#import <sound/sound.h>

#include "SDL_audio.h"
#include "SDL_timer.h"
#include "../SDL_audiomem.h"
#include "../SDL_sysaudio.h"
#include "SDL_openstepaudio.h"

/* SDL 1.2 keeps this internal helper out of the installed public header. */
extern void SDL_CalculateAudioSpec(SDL_AudioSpec *spec);

#define OPENSTEPAUD_DRIVER_NAME "openstep"

static int OPENSTEP_AUDIO_Available(void);
static SDL_AudioDevice *OPENSTEP_AUDIO_CreateDevice(int devindex);
static void OPENSTEP_AUDIO_DeleteDevice(SDL_AudioDevice *device);
static int OPENSTEP_AUDIO_OpenAudio(_THIS, SDL_AudioSpec *spec);
static void OPENSTEP_AUDIO_WaitAudio(_THIS);
static void OPENSTEP_AUDIO_PlayAudio(_THIS);
static Uint8 *OPENSTEP_AUDIO_GetAudioBuf(_THIS);
static void OPENSTEP_AUDIO_CloseAudio(_THIS);
static int OPENSTEP_AUDIO_UseLegacySoundAPI(_THIS, SDL_AudioSpec *spec);
static void OPENSTEP_AUDIO_DrainLegacySound(_THIS);

static int OPENSTEP_AUDIO_Available(void)
{
    const char *requested;

    requested = SDL_getenv("SDL_AUDIODRIVER");
    if ((requested != NULL) &&
        (SDL_strcasecmp(requested, OPENSTEPAUD_DRIVER_NAME) != 0)) return 0;
    return 1;
}

static void OPENSTEP_AUDIO_DeleteDevice(SDL_AudioDevice *device)
{
    SDL_free(device->hidden);
    SDL_free(device);
}

static SDL_AudioDevice *OPENSTEP_AUDIO_CreateDevice(int devindex)
{
    SDL_AudioDevice *device;

    device = (SDL_AudioDevice *)SDL_malloc(sizeof(*device));
    if (device == NULL) {
        SDL_OutOfMemory();
        return NULL;
    }
    SDL_memset(device, 0, sizeof(*device));
    device->hidden = (struct SDL_PrivateAudioData *)SDL_malloc(
        sizeof(*device->hidden));
    if (device->hidden == NULL) {
        SDL_free(device);
        SDL_OutOfMemory();
        return NULL;
    }
    SDL_memset(device->hidden, 0, sizeof(*device->hidden));
    device->OpenAudio = OPENSTEP_AUDIO_OpenAudio;
    device->WaitAudio = OPENSTEP_AUDIO_WaitAudio;
    device->PlayAudio = OPENSTEP_AUDIO_PlayAudio;
    device->GetAudioBuf = OPENSTEP_AUDIO_GetAudioBuf;
    device->CloseAudio = OPENSTEP_AUDIO_CloseAudio;
    device->free = OPENSTEP_AUDIO_DeleteDevice;
    return device;
}

AudioBootStrap OPENSTEP_AUDIO_bootstrap = {
    OPENSTEPAUD_DRIVER_NAME, "OPENSTEP SoundKit stream audio driver",
    OPENSTEP_AUDIO_Available, OPENSTEP_AUDIO_CreateDevice
};

static int OPENSTEP_AUDIO_OpenAudio(_THIS, SDL_AudioSpec *spec)
{
    float bytes_per_second;

    if ((spec->channels < 1) || (spec->channels > 2)) {
        SDL_SetError("OPENSTEP SoundKit supports one or two channels");
        return -1;
    }
    /* SNDStartPlaying(..., preempt=0) is the SoundKit documented FCFS
       queue.  It owns distinct queued buffers, accepts NeXT big-endian
       LINEAR_16 data, and remains continuous while the AppKit UI is busy.
       NXPlayStream needs a separate DMA-safe buffer pool before it can
       safely replace this proven path. */
    if (OPENSTEP_AUDIO_UseLegacySoundAPI(this, spec) != 0) return -1;
    this->hidden->mixlen = spec->size;
    this->hidden->mixbuf = (Uint8 *)SDL_AllocAudioMem(spec->size);
    if (this->hidden->mixbuf == NULL) {
        OPENSTEP_AUDIO_CloseAudio(this);
        SDL_OutOfMemory();
        return -1;
    }
    SDL_memset(this->hidden->mixbuf, spec->silence, spec->size);
    bytes_per_second = (float)((spec->format & 0xff) / 8) *
                       (float)spec->channels * (float)spec->freq;
    if (bytes_per_second <= 0.0f) {
        OPENSTEP_AUDIO_CloseAudio(this);
        SDL_SetError("OPENSTEP invalid audio specification");
        return -1;
    }
    this->hidden->delay = (Uint32)(((float)spec->size / bytes_per_second) *
                                    1000.0f);
    if (this->hidden->delay == 0) this->hidden->delay = 1;
    return 0;
}

static void OPENSTEP_AUDIO_WaitAudio(_THIS)
{
    if (this->hidden->use_legacy_sound_api) {
        /* Queue ahead before waiting.  SNDStartPlaying(..., preempt=0)
           is FCFS, so this prevents the DAC gaps caused by per-block waits. */
        if (this->hidden->legacy_count >= OPENSTEP_LEGACY_SOUND_KEEP) {
            OPENSTEP_AUDIO_DrainLegacySound(this);
        }
        return;
    }
    SDL_Delay(this->hidden->delay);
}

static void OPENSTEP_AUDIO_PlayAudio(_THIS)
{
    SNDSoundStruct *sound;
    Uint8 *source;
    Uint8 *target;
    Uint32 i;
    int slot;
    int error;

    if (this->hidden->legacy_count >= OPENSTEP_LEGACY_SOUND_POOL) {
        SDL_SetError("OPENSTEP legacy sound queue overflow");
        return;
    }
    sound = (SNDSoundStruct *)SDL_malloc(sizeof(*sound) +
                                         this->hidden->mixlen);
    if (sound == NULL) {
        SDL_OutOfMemory();
        return;
    }
    sound->magic = SND_MAGIC;
    sound->dataLocation = sizeof(*sound);
    sound->dataSize = this->hidden->mixlen;
    sound->dataFormat = SND_FORMAT_LINEAR_16;
    sound->samplingRate = this->spec.freq;
    sound->channelCount = this->spec.channels;
    source = this->hidden->mixbuf;
    target = ((Uint8 *)sound) + sizeof(*sound);
    if (this->spec.format == AUDIO_S16MSB) {
        SDL_memcpy(target, source, this->hidden->mixlen);
    } else {
        /* SND_FORMAT_LINEAR_16 data is big-endian, even on i486. */
        for (i = 0; i < this->hidden->mixlen; i += 2) {
            target[i] = source[i + 1];
            target[i + 1] = source[i];
        }
    }
    ++this->hidden->legacy_tag;
    if (this->hidden->legacy_tag <= 0) this->hidden->legacy_tag = 1;
    error = SNDStartPlaying(sound, this->hidden->legacy_tag, 0, 0,
                            SND_NULL_FUN, SND_NULL_FUN);
    if (error != SND_ERR_NONE) {
        SDL_free(sound);
        SDL_SetError("OPENSTEP legacy sound play failed (%d)", error);
        return;
    }
    slot = (this->hidden->legacy_head + this->hidden->legacy_count) %
           OPENSTEP_LEGACY_SOUND_POOL;
    this->hidden->legacy_sounds[slot] = (void *)sound;
    this->hidden->legacy_tags[slot] = this->hidden->legacy_tag;
    ++this->hidden->legacy_count;
}

static int OPENSTEP_AUDIO_UseLegacySoundAPI(_THIS, SDL_AudioSpec *spec)
{
    if ((spec->format != AUDIO_S16LSB) && (spec->format != AUDIO_S16MSB)) {
        SDL_SetError("OPENSTEP legacy sound API requires signed 16-bit PCM");
        return -1;
    }
    if ((spec->freq != 22050) && (spec->freq != 44100)) {
        SDL_SetError("OPENSTEP legacy sound API requires 22050 or 44100 Hz");
        return -1;
    }
    /* Match the proven OnionPlayer stream cadence: 0.25-second chunks and
       several queued buffers.  The SND server then plays FCFS without gaps. */
    spec->samples = (Uint16)(spec->freq / 4);
    SDL_CalculateAudioSpec(spec);
    this->hidden->use_legacy_sound_api = 1;
    this->hidden->legacy_tag = 0;
    this->hidden->legacy_head = 0;
    this->hidden->legacy_count = 0;
    return 0;
}

static void OPENSTEP_AUDIO_DrainLegacySound(_THIS)
{
    int slot;

    if (this->hidden->legacy_count > 0) {
        slot = this->hidden->legacy_head;
        if (SNDWait(this->hidden->legacy_tags[slot]) != SND_ERR_NONE) {
            SDL_SetError("OPENSTEP legacy sound wait failed");
        }
        SDL_free(this->hidden->legacy_sounds[slot]);
        this->hidden->legacy_sounds[slot] = NULL;
        this->hidden->legacy_head = (slot + 1) % OPENSTEP_LEGACY_SOUND_POOL;
        --this->hidden->legacy_count;
    }
}

static Uint8 *OPENSTEP_AUDIO_GetAudioBuf(_THIS)
{
    return this->hidden->mixbuf;
}

static void OPENSTEP_AUDIO_CloseAudio(_THIS)
{
    while (this->hidden->legacy_count > 0) {
        OPENSTEP_AUDIO_DrainLegacySound(this);
    }
    if (this->hidden->mixbuf != NULL) {
        SDL_FreeAudioMem(this->hidden->mixbuf);
        this->hidden->mixbuf = NULL;
    }
    this->hidden->use_legacy_sound_api = 0;
}

#endif /* SDL_AUDIO_DRIVER_OPENSTEP */
