/* OPENSTEP Mach cthreads private declarations. */
#ifndef _SDL_systhread_c_h
#define _SDL_systhread_c_h

#import <mach/cthreads.h>

typedef cthread_t SYS_ThreadHandle;

#endif /* _SDL_systhread_c_h */
