#ifndef _SDL_openstepthread_h
#define _SDL_openstepthread_h

#include "SDL_thread.h"
#include "SDL_systhread_c.h"

struct SDL_mutex {
    mutex_t mutex;
    Uint32 owner;
    int recursive;
};

#endif /* _SDL_openstepthread_h */
