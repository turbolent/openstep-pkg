/* SDL condition variables over OPENSTEP Mach cthreads primitives.
 *
 * cthreads has condition_wait() but no timed wait.  This is SDL 1.2's
 * generic semaphore handshake implementation, used unchanged in behaviour
 * so SDL_CondWaitTimeout() can distinguish a signal from a timeout.
 */
#include "SDL_config.h"

#if SDL_THREAD_OPENSTEP

#include "SDL_thread.h"

struct SDL_cond {
    SDL_mutex *lock;
    int waiting;
    int signals;
    SDL_sem *wait_sem;
    SDL_sem *wait_done;
};

SDL_cond *SDL_CreateCond(void)
{
    SDL_cond *cond;

    cond = (SDL_cond *)SDL_malloc(sizeof(*cond));
    if (cond == NULL) {
        SDL_OutOfMemory();
        return NULL;
    }
    cond->lock = NULL;
    cond->wait_sem = NULL;
    cond->wait_done = NULL;
    cond->waiting = 0;
    cond->signals = 0;
    cond->lock = SDL_CreateMutex();
    cond->wait_sem = SDL_CreateSemaphore(0);
    cond->wait_done = SDL_CreateSemaphore(0);
    if ((cond->lock == NULL) || (cond->wait_sem == NULL) ||
        (cond->wait_done == NULL)) {
        SDL_DestroyCond(cond);
        return NULL;
    }
    return cond;
}

void SDL_DestroyCond(SDL_cond *cond)
{
    if (cond != NULL) {
        if (cond->wait_sem != NULL) SDL_DestroySemaphore(cond->wait_sem);
        if (cond->wait_done != NULL) SDL_DestroySemaphore(cond->wait_done);
        if (cond->lock != NULL) SDL_DestroyMutex(cond->lock);
        SDL_free(cond);
    }
}

int SDL_CondSignal(SDL_cond *cond)
{
    if (cond == NULL) {
        SDL_SetError("Passed a NULL condition variable");
        return -1;
    }
    SDL_LockMutex(cond->lock);
    if (cond->waiting > cond->signals) {
        ++cond->signals;
        SDL_SemPost(cond->wait_sem);
        SDL_UnlockMutex(cond->lock);
        SDL_SemWait(cond->wait_done);
    } else {
        SDL_UnlockMutex(cond->lock);
    }
    return 0;
}

int SDL_CondBroadcast(SDL_cond *cond)
{
    int index;
    int number_waiting;

    if (cond == NULL) {
        SDL_SetError("Passed a NULL condition variable");
        return -1;
    }
    SDL_LockMutex(cond->lock);
    if (cond->waiting > cond->signals) {
        number_waiting = cond->waiting - cond->signals;
        cond->signals = cond->waiting;
        for (index = 0; index < number_waiting; ++index) {
            SDL_SemPost(cond->wait_sem);
        }
        SDL_UnlockMutex(cond->lock);
        for (index = 0; index < number_waiting; ++index) {
            SDL_SemWait(cond->wait_done);
        }
    } else {
        SDL_UnlockMutex(cond->lock);
    }
    return 0;
}

int SDL_CondWaitTimeout(SDL_cond *cond, SDL_mutex *mutex, Uint32 ms)
{
    int result;

    if ((cond == NULL) || (mutex == NULL)) {
        SDL_SetError("Passed a NULL condition or mutex");
        return -1;
    }
    SDL_LockMutex(cond->lock);
    ++cond->waiting;
    SDL_UnlockMutex(cond->lock);

    SDL_UnlockMutex(mutex);
    if (ms == SDL_MUTEX_MAXWAIT) {
        result = SDL_SemWait(cond->wait_sem);
    } else {
        result = SDL_SemWaitTimeout(cond->wait_sem, ms);
    }

    SDL_LockMutex(cond->lock);
    if (cond->signals > 0) {
        if (result > 0) SDL_SemWait(cond->wait_sem);
        SDL_SemPost(cond->wait_done);
        --cond->signals;
    }
    --cond->waiting;
    SDL_UnlockMutex(cond->lock);

    SDL_LockMutex(mutex);
    return result;
}

int SDL_CondWait(SDL_cond *cond, SDL_mutex *mutex)
{
    return SDL_CondWaitTimeout(cond, mutex, SDL_MUTEX_MAXWAIT);
}

#endif /* SDL_THREAD_OPENSTEP */
