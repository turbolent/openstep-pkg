/* SDL semaphores over OPENSTEP Mach cthreads mutexes and conditions. */
#include "SDL_config.h"

#if SDL_THREAD_OPENSTEP

#include "SDL_timer.h"
#include "SDL_thread.h"
#include "SDL_openstepthread.h"

struct SDL_semaphore {
    Uint32 count;
    mutex_t mutex;
    condition_t condition;
};

SDL_sem *SDL_CreateSemaphore(Uint32 initial_value)
{
    SDL_sem *sem;

    sem = (SDL_sem *)SDL_malloc(sizeof(*sem));
    if (sem == NULL) {
        SDL_OutOfMemory();
        return NULL;
    }
    sem->mutex = mutex_alloc();
    sem->condition = condition_alloc();
    if ((sem->mutex == NULL) || (sem->condition == NULL)) {
        if (sem->mutex != NULL) mutex_free(sem->mutex);
        if (sem->condition != NULL) condition_free(sem->condition);
        SDL_free(sem);
        SDL_OutOfMemory();
        return NULL;
    }
    mutex_init(sem->mutex);
    condition_init(sem->condition);
    sem->count = initial_value;
    return sem;
}

void SDL_DestroySemaphore(SDL_sem *sem)
{
    if (sem != NULL) {
        condition_free(sem->condition);
        mutex_free(sem->mutex);
        SDL_free(sem);
    }
}

int SDL_SemTryWait(SDL_sem *sem)
{
    int result;

    if (sem == NULL) return -1;
    mutex_lock(sem->mutex);
    result = SDL_MUTEX_TIMEDOUT;
    if (sem->count != 0) {
        --sem->count;
        result = 0;
    }
    mutex_unlock(sem->mutex);
    return result;
}

int SDL_SemWaitTimeout(SDL_sem *sem, Uint32 timeout)
{
    Uint32 start;
    int result;

    if (sem == NULL) return -1;
    if (timeout == 0) return SDL_SemTryWait(sem);
    start = SDL_GetTicks();
    mutex_lock(sem->mutex);
    while (sem->count == 0) {
        if (timeout != SDL_MUTEX_MAXWAIT &&
            (SDL_GetTicks() - start) >= timeout) {
            mutex_unlock(sem->mutex);
            return SDL_MUTEX_TIMEDOUT;
        }
        if (timeout == SDL_MUTEX_MAXWAIT) {
            condition_wait(sem->condition, sem->mutex);
        } else {
            mutex_unlock(sem->mutex);
            SDL_Delay(1);
            mutex_lock(sem->mutex);
        }
    }
    --sem->count;
    result = 0;
    mutex_unlock(sem->mutex);
    return result;
}

int SDL_SemWait(SDL_sem *sem)
{
    return SDL_SemWaitTimeout(sem, SDL_MUTEX_MAXWAIT);
}

Uint32 SDL_SemValue(SDL_sem *sem)
{
    Uint32 value;

    if (sem == NULL) return 0;
    mutex_lock(sem->mutex);
    value = sem->count;
    mutex_unlock(sem->mutex);
    return value;
}

int SDL_SemPost(SDL_sem *sem)
{
    if (sem == NULL) return -1;
    mutex_lock(sem->mutex);
    ++sem->count;
    condition_signal(sem->condition);
    mutex_unlock(sem->mutex);
    return 0;
}

#endif /* SDL_THREAD_OPENSTEP */
