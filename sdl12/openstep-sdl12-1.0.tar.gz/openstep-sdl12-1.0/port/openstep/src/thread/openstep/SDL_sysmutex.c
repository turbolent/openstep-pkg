/* Recursive SDL mutexes over OPENSTEP Mach cthreads mutexes. */
#include "SDL_config.h"

#if SDL_THREAD_OPENSTEP

#include "SDL_thread.h"
#include "SDL_openstepthread.h"

SDL_mutex *SDL_CreateMutex(void)
{
    SDL_mutex *mutex;

    mutex = (SDL_mutex *)SDL_malloc(sizeof(*mutex));
    if (mutex == NULL) {
        SDL_OutOfMemory();
        return NULL;
    }
    mutex->mutex = mutex_alloc();
    if (mutex->mutex == NULL) {
        SDL_free(mutex);
        SDL_OutOfMemory();
        return NULL;
    }
    mutex_init(mutex->mutex);
    mutex->owner = 0;
    mutex->recursive = 0;
    return mutex;
}

void SDL_DestroyMutex(SDL_mutex *mutex)
{
    if (mutex != NULL) {
        if (mutex->mutex != NULL) mutex_free(mutex->mutex);
        SDL_free(mutex);
    }
}

int SDL_mutexP(SDL_mutex *mutex)
{
    Uint32 self;

    if (mutex == NULL) {
        SDL_SetError("Passed a NULL mutex");
        return -1;
    }
    self = SDL_ThreadID();
    if (mutex->owner == self) {
        ++mutex->recursive;
        return 0;
    }
    mutex_lock(mutex->mutex);
    mutex->owner = self;
    mutex->recursive = 0;
    return 0;
}

int SDL_mutexV(SDL_mutex *mutex)
{
    if (mutex == NULL) {
        SDL_SetError("Passed a NULL mutex");
        return -1;
    }
    if (mutex->owner != SDL_ThreadID()) {
        SDL_SetError("mutex not owned by this thread");
        return -1;
    }
    if (mutex->recursive != 0) {
        --mutex->recursive;
    } else {
        mutex->owner = 0;
        mutex_unlock(mutex->mutex);
    }
    return 0;
}

#endif /* SDL_THREAD_OPENSTEP */
