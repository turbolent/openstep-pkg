/* SDL 1.2 Mach cthreads implementation for OPENSTEP. */
#include "SDL_config.h"

#if SDL_THREAD_OPENSTEP

#include "SDL_thread.h"
#include "../SDL_thread_c.h"
#include "../SDL_systhread.h"

static int openstep_cthreads_started = 0;

static any_t OPENSTEP_RunThread(any_t data)
{
    SDL_RunThread(data);
    return (any_t)0;
}

int SDL_SYS_CreateThread(SDL_Thread *thread, void *args)
{
    if (!openstep_cthreads_started) {
        cthread_init();
        openstep_cthreads_started = 1;
    }
    thread->handle = cthread_fork(OPENSTEP_RunThread, (any_t)args);
    if (thread->handle == NO_CTHREAD) {
        SDL_SetError("cthread_fork failed");
        return -1;
    }
    return 0;
}

void SDL_SYS_SetupThread(void)
{
}

Uint32 SDL_ThreadID(void)
{
    return (Uint32)(unsigned long)cthread_self();
}

void SDL_SYS_WaitThread(SDL_Thread *thread)
{
    if (thread->handle != NO_CTHREAD) cthread_join(thread->handle);
}

void SDL_SYS_KillThread(SDL_Thread *thread)
{
    if (thread->handle != NO_CTHREAD) cthread_abort(thread->handle);
}

#endif /* SDL_THREAD_OPENSTEP */
