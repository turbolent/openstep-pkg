/* OPENSTEP 4.2 BSD/Mach timer backend for SDL 1.2.15.
 *
 * OPENSTEP's BSD headers predate POSIX sigaction.  Use gettimeofday(2),
 * select(2), signal(3), and setitimer(2), all available in the base system.
 */
#include "SDL_config.h"

#ifdef SDL_TIMER_OPENSTEP

#include <sys/time.h>
#include <errno.h>
#include <libc.h>
#include <signal.h>

#include "SDL_timer.h"
#include "../SDL_timer_c.h"

static struct timeval start;
static struct timeval last_time;

/* Kept non-static so the target regression can exercise the 49-day boundary
   without changing the process clock.  This remains an internal SDL symbol. */
Uint32 SDL_OPENSTEP_TicksFromTime(const struct timeval *origin,
                                 const struct timeval *sample)
{
    long seconds;
    long microseconds;

    seconds = sample->tv_sec - origin->tv_sec;
    microseconds = sample->tv_usec - origin->tv_usec;
    if (microseconds < 0) {
        --seconds;
        microseconds += 1000000;
    }
    if (seconds < 0) return 0;
    /* Uint32 arithmetic deliberately wraps at 2^32 milliseconds, as the
       public SDL_GetTicks() contract specifies.  Avoid a signed long value
       holding the complete millisecond interval: it overflows after 24 days
       on OPENSTEP/i386. */
    return ((Uint32)seconds * 1000U) + (Uint32)(microseconds / 1000);
}

void SDL_StartTicks(void)
{
    gettimeofday(&start, NULL);
    last_time = start;
}

Uint32 SDL_GetTicks(void)
{
    struct timeval now;

    gettimeofday(&now, NULL);
    /* Clamp a backwards wall-clock adjustment before converting to Uint32.
       Comparing tick values would incorrectly suppress the documented
       49-day wrap. */
    if ((now.tv_sec < last_time.tv_sec) ||
        ((now.tv_sec == last_time.tv_sec) &&
         (now.tv_usec < last_time.tv_usec))) {
        now = last_time;
    } else {
        last_time = now;
    }
    return SDL_OPENSTEP_TicksFromTime(&start, &now);
}

void SDL_Delay(Uint32 ms)
{
    struct timeval tv;
    Uint32 then;
    Uint32 now;
    Uint32 elapsed;
    int was_error;

    /* Keep the SDL 1.2 Unix backend's contract: delay at least the requested
       interval even when SIGALRM interrupts the blocking syscall.  OPENSTEP's
       usleep path masks that delivery, so use the BSD select declaration from
       <libc.h> instead. */
    then = SDL_GetTicks();
    do {
        now = SDL_GetTicks();
        elapsed = now - then;
        then = now;
        if (elapsed >= ms) break;
        ms -= elapsed;
        tv.tv_sec = ms / 1000;
        tv.tv_usec = (ms % 1000) * 1000;
        errno = 0;
        was_error = select(0, NULL, NULL, NULL, &tv);
    } while (was_error && (errno == EINTR));
}

static void HandleAlarm(int sig)
{
    Uint32 ms;

    if (SDL_alarm_callback != NULL) {
        ms = (*SDL_alarm_callback)(SDL_alarm_interval);
        if (ms != SDL_alarm_interval) SDL_SetTimer(ms, SDL_alarm_callback);
    }
}

int SDL_SYS_TimerInit(void)
{
    signal(SIGALRM, HandleAlarm);
    return 0;
}

void SDL_SYS_TimerQuit(void)
{
    SDL_SetTimer(0, NULL);
}

int SDL_SYS_StartTimer(void)
{
    struct itimerval timer;

    timer.it_value.tv_sec = SDL_alarm_interval / 1000;
    timer.it_value.tv_usec = (SDL_alarm_interval % 1000) * 1000;
    timer.it_interval = timer.it_value;
    return setitimer(ITIMER_REAL, &timer, NULL);
}

void SDL_SYS_StopTimer(void)
{
    struct itimerval timer;

    SDL_memset(&timer, 0, sizeof(timer));
    setitimer(ITIMER_REAL, &timer, NULL);
}

#endif /* SDL_TIMER_OPENSTEP */
