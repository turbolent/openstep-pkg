/* OPENSTEP AppKit video driver private state for SDL 1.2.15. */
#ifndef _SDL_openstepvideo_h
#define _SDL_openstepvideo_h

#include "../SDL_sysvideo.h"

#define _THIS SDL_VideoDevice *this

struct SDL_PrivateVideoData {
    void *pool;
    void *window;
    void *view;
    void *bitmap;
    void *invisible_cursor;
    unsigned char *pixels;
    unsigned char *present_pixels;
    int width;
    int height;
    int pitch;
    int bits_per_pixel;
    int presenting;
    int resizable;
    unsigned int modifier_flags;
    SDL_Color palette[256];
};

#endif /* _SDL_openstepvideo_h */
