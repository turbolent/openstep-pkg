/*
 * SDL 1.2.15 OPENSTEP AppKit video driver.
 *
 * This deliberately exposes only a software 24bpp RGB framebuffer.  The
 * display path is Display PostScript through NSBitmapImageRep; it never
 * creates, opens, or depends on an X11 display.
 */
#include "SDL_config.h"

#import <AppKit/AppKit.h>
#import <AppKit/psopsNeXT.h>

#include "SDL_video.h"
#include "SDL_mouse.h"
#include "SDL_active.h"
#include "../SDL_sysvideo.h"
#include "../SDL_cursor_c.h"
#include "../SDL_pixels_c.h"
#include "../../events/SDL_events_c.h"

#include "SDL_openstepvideo.h"

#define OPENSTEPVID_DRIVER_NAME "openstep"

static int OPENSTEP_Available(void);
static SDL_VideoDevice *OPENSTEP_CreateDevice(int devindex);
static void OPENSTEP_DeleteDevice(_THIS);
static int OPENSTEP_VideoInit(_THIS, SDL_PixelFormat *vformat);
static SDL_Rect **OPENSTEP_ListModes(_THIS, SDL_PixelFormat *format,
                                     Uint32 flags);
static SDL_Surface *OPENSTEP_SetVideoMode(_THIS, SDL_Surface *current,
                                          int width, int height, int bpp,
                                          Uint32 flags);
static int OPENSTEP_SetColors(_THIS, int firstcolor, int ncolors,
                              SDL_Color *colors);
static void OPENSTEP_UpdateRects(_THIS, int numrects, SDL_Rect *rects);
static void OPENSTEP_VideoQuit(_THIS);
static int OPENSTEP_AllocHWSurface(_THIS, SDL_Surface *surface);
static void OPENSTEP_FreeHWSurface(_THIS, SDL_Surface *surface);
static int OPENSTEP_LockHWSurface(_THIS, SDL_Surface *surface);
static void OPENSTEP_UnlockHWSurface(_THIS, SDL_Surface *surface);
static void OPENSTEP_SetCaption(_THIS, const char *title, const char *icon);
static int OPENSTEP_IconifyWindow(_THIS);
static SDL_GrabMode OPENSTEP_GrabInput(_THIS, SDL_GrabMode mode);
static void OPENSTEP_InitOSKeymap(_THIS);
static void OPENSTEP_PumpEvents(_THIS);
static void OPENSTEP_SendKey(SDL_VideoDevice *device, NSEvent *event,
                             Uint8 state);
static void OPENSTEP_SendMouse(SDL_VideoDevice *device, NSEvent *event,
                               Uint8 state, Uint8 button);
static WMcursor *OPENSTEP_CreateWMCursor(_THIS, Uint8 *data, Uint8 *mask,
                                         int w, int h, int hot_x, int hot_y);
static void OPENSTEP_FreeWMCursor(_THIS, WMcursor *cursor);
static int OPENSTEP_ShowWMCursor(_THIS, WMcursor *cursor);
static void OPENSTEP_WarpWMCursor(_THIS, Uint16 x, Uint16 y);
static void OPENSTEP_ResetCursorRects(SDL_VideoDevice *device, NSView *view);
static WMcursor *OPENSTEP_CreateInvisibleCursor(_THIS);
static SDLKey OPENSTEP_KeyForCharacter(unsigned short character);
static SDLMod OPENSTEP_Modifiers(SDL_VideoDevice *device, NSEvent *event);
static void OPENSTEP_ConvertSurface(_THIS, int numrects, SDL_Rect *rects);
static void OPENSTEP_ConvertRect(_THIS, int left, int top, int right,
                                 int bottom);

/* OPENSTEP's NSCursor is the Window Server cursor, distinct from SDL's
   software framebuffer cursor.  Keep the native object behind SDL's opaque
   WMcursor handle so SDL core selects this path and never stamps a cursor
   into the application's surface. */
struct WMcursor {
    NSCursor *cursor;
};

@interface SDL12OpenStepWindow : NSWindow
{
    SDL_VideoDevice *_device;
}
- initWithContentRect:(NSRect)contentRect styleMask:(unsigned int)style
              backing:(NSBackingStoreType)backing defer:(BOOL)deferFlag
              device:(SDL_VideoDevice *)device;
@end

@implementation SDL12OpenStepWindow

- initWithContentRect:(NSRect)contentRect styleMask:(unsigned int)style
              backing:(NSBackingStoreType)backing defer:(BOOL)deferFlag
              device:(SDL_VideoDevice *)device
{
    self = [super initWithContentRect:contentRect styleMask:style
                              backing:backing defer:deferFlag];
    _device = device;
    return self;
}

- (void)becomeKeyWindow
{
    [super becomeKeyWindow];
    if (_device != NULL) {
        SDL_PrivateAppActive(1, SDL_APPACTIVE | SDL_APPINPUTFOCUS);
    }
}

- (void)resignKeyWindow
{
    [super resignKeyWindow];
    if (_device != NULL) {
        _device->hidden->modifier_flags = 0;
        SDL_PrivateAppActive(0, SDL_APPACTIVE | SDL_APPINPUTFOCUS);
    }
}

@end

@interface SDL12OpenStepView : NSView
{
    SDL_VideoDevice *_device;
    NSBitmapImageRep *_bitmap;
}
- initWithFrame:(NSRect)frame device:(SDL_VideoDevice *)device
          bitmap:(NSBitmapImageRep *)bitmap;
@end

@implementation SDL12OpenStepView

- initWithFrame:(NSRect)frame device:(SDL_VideoDevice *)device
          bitmap:(NSBitmapImageRep *)bitmap
{
    [super initWithFrame:frame];
    _device = device;
    _bitmap = [bitmap retain];
    return self;
}

- (void)dealloc
{
    [_bitmap release];
    [super dealloc];
}

- (BOOL)isFlipped
{
    return YES;
}

- (BOOL)acceptsFirstResponder
{
    return YES;
}

- (void)drawRect:(NSRect)rect
{
    [_bitmap drawInRect:[self bounds]];
    /* SDL_UpdateRects() synchronously asks AppKit to draw.  That normal
       present is not an SDL_VIDEOEXPOSE event: SDL reserves expose for a
       window-system redraw outside of the application's update request. */
    if ((_device != NULL) && !_device->hidden->presenting) {
        SDL_PrivateExpose();
    }
}

- (void)resetCursorRects
{
    OPENSTEP_ResetCursorRects(_device, self);
}

- (void)keyDown:(NSEvent *)event
{
    OPENSTEP_SendKey(_device, event, SDL_PRESSED);
}

- (void)keyUp:(NSEvent *)event
{
    OPENSTEP_SendKey(_device, event, SDL_RELEASED);
}

- (void)flagsChanged:(NSEvent *)event
{
    /* Some OPENSTEP console input paths report modifier flags only in this
       event, not in the following keyDown:/keyUp:.  Preserve the state on
       the SDL video device so ordinary keys receive the right SDLMod mask. */
    if (_device != NULL) {
        _device->hidden->modifier_flags = [event modifierFlags];
    }
}

- (void)mouseDown:(NSEvent *)event
{
    OPENSTEP_SendMouse(_device, event, SDL_PRESSED, SDL_BUTTON_LEFT);
}

- (void)mouseUp:(NSEvent *)event
{
    OPENSTEP_SendMouse(_device, event, SDL_RELEASED, SDL_BUTTON_LEFT);
}

- (void)rightMouseDown:(NSEvent *)event
{
    OPENSTEP_SendMouse(_device, event, SDL_PRESSED, SDL_BUTTON_RIGHT);
}

- (void)rightMouseUp:(NSEvent *)event
{
    OPENSTEP_SendMouse(_device, event, SDL_RELEASED, SDL_BUTTON_RIGHT);
}

- (void)mouseMoved:(NSEvent *)event
{
    NSPoint point;
    int x;
    int y;

    point = [self convertPoint:[event locationInWindow] fromView:nil];
    x = (int)point.x;
    y = (int)point.y;
    SDL_PrivateMouseMotion(0, 0, (Sint16)x, (Sint16)y);
}

- (void)mouseDragged:(NSEvent *)event
{
    NSPoint point;

    point = [self convertPoint:[event locationInWindow] fromView:nil];
    SDL_PrivateMouseMotion(SDL_BUTTON_LMASK, 0, (Sint16)point.x,
                           (Sint16)point.y);
}

- (void)rightMouseDragged:(NSEvent *)event
{
    NSPoint point;

    point = [self convertPoint:[event locationInWindow] fromView:nil];
    SDL_PrivateMouseMotion(SDL_BUTTON_RMASK, 0, (Sint16)point.x,
                           (Sint16)point.y);
}

- (void)windowWillClose:(NSNotification *)notification
{
    /* NSWindow releases itself and its content view when a user closes a
       default OPENSTEP window.  SDL_Quit() follows this notification, so
       leave it only the bitmap/framebuffer resources; the AppKit objects
       must not be messaged or released a second time. */
    if (_device != NULL) {
        _device->hidden->window = NULL;
        _device->hidden->view = NULL;
    }
    SDL_PrivateQuit();
}

- (void)windowDidResize:(NSNotification *)notification
{
    NSRect frame;
    int width;
    int height;

    /* The OPENSTEP Window reference says this delegate method is delivered
       once the user finishes resizing.  SDL 1.2 then requires the client to
       answer SDL_VIDEORESIZE by calling SDL_SetVideoMode() again.  Ignore a
       newly-created replacement view until SetVideoMode has installed it as
       the device's current view. */
    if ((_device == NULL) || !_device->hidden->resizable ||
        (_device->hidden->view != (void *)self)) return;
    frame = [self frame];
    width = (int)frame.size.width;
    height = (int)frame.size.height;
    if ((width > 0) && (height > 0) &&
        ((width != _device->hidden->width) ||
         (height != _device->hidden->height))) {
        SDL_PrivateResize(width, height);
    }
}

@end

static int OPENSTEP_Available(void)
{
    const char *requested;

    requested = SDL_getenv("SDL_VIDEODRIVER");
    if ((requested != NULL) &&
        (SDL_strcasecmp(requested, OPENSTEPVID_DRIVER_NAME) != 0)) {
        return 0;
    }
    return 1;
}

static void OPENSTEP_DeleteDevice(_THIS)
{
    SDL_free(this->hidden);
    SDL_free(this);
}

static SDL_VideoDevice *OPENSTEP_CreateDevice(int devindex)
{
    SDL_VideoDevice *device;

    device = (SDL_VideoDevice *)SDL_malloc(sizeof(SDL_VideoDevice));
    if (device == NULL) {
        SDL_OutOfMemory();
        return NULL;
    }
    SDL_memset(device, 0, sizeof(SDL_VideoDevice));
    device->hidden = (struct SDL_PrivateVideoData *)SDL_malloc(
        sizeof(struct SDL_PrivateVideoData));
    if (device->hidden == NULL) {
        SDL_free(device);
        SDL_OutOfMemory();
        return NULL;
    }
    SDL_memset(device->hidden, 0, sizeof(struct SDL_PrivateVideoData));

    device->VideoInit = OPENSTEP_VideoInit;
    device->ListModes = OPENSTEP_ListModes;
    device->SetVideoMode = OPENSTEP_SetVideoMode;
    device->SetColors = OPENSTEP_SetColors;
    device->UpdateRects = OPENSTEP_UpdateRects;
    device->VideoQuit = OPENSTEP_VideoQuit;
    device->AllocHWSurface = OPENSTEP_AllocHWSurface;
    device->LockHWSurface = OPENSTEP_LockHWSurface;
    device->UnlockHWSurface = OPENSTEP_UnlockHWSurface;
    device->FreeHWSurface = OPENSTEP_FreeHWSurface;
    device->SetCaption = OPENSTEP_SetCaption;
    device->IconifyWindow = OPENSTEP_IconifyWindow;
    device->GrabInput = OPENSTEP_GrabInput;
    device->CreateWMCursor = OPENSTEP_CreateWMCursor;
    device->FreeWMCursor = OPENSTEP_FreeWMCursor;
    device->ShowWMCursor = OPENSTEP_ShowWMCursor;
    device->WarpWMCursor = OPENSTEP_WarpWMCursor;
    device->InitOSKeymap = OPENSTEP_InitOSKeymap;
    device->PumpEvents = OPENSTEP_PumpEvents;
    device->free = OPENSTEP_DeleteDevice;
    return device;
}

VideoBootStrap OPENSTEP_bootstrap = {
    OPENSTEPVID_DRIVER_NAME, "OPENSTEP AppKit video driver",
    OPENSTEP_Available, OPENSTEP_CreateDevice
};

static int OPENSTEP_VideoInit(_THIS, SDL_PixelFormat *vformat)
{
    NSAutoreleasePool *pool;

    pool = [[NSAutoreleasePool alloc] init];
    this->hidden->pool = (void *)pool;
    [NSApplication sharedApplication];
    vformat->BitsPerPixel = 24;
    vformat->BytesPerPixel = 3;
    return 0;
}

static SDL_Rect **OPENSTEP_ListModes(_THIS, SDL_PixelFormat *format,
                                     Uint32 flags)
{
    return (SDL_Rect **)-1;
}

static void OPENSTEP_DestroyWindow(_THIS)
{
    id window;
    id bitmap;
    unsigned char *pixels;
    unsigned char *present_pixels;

    /* Detach every pointer first.  Closing an NSWindow can deliver AppKit
       notifications synchronously, and the close delegate calls
       SDL_PrivateQuit() for a user-initiated close.  A shutdown-initiated
       close must therefore neither invoke that delegate nor allow a nested
       VideoQuit to release the same objects. */
    window = (id)this->hidden->window;
    bitmap = (id)this->hidden->bitmap;
    pixels = this->hidden->pixels;
    present_pixels = this->hidden->present_pixels;
    this->hidden->window = NULL;
    this->hidden->view = NULL;
    this->hidden->bitmap = NULL;
    this->hidden->pixels = NULL;
    this->hidden->present_pixels = NULL;

    if (window != nil) {
        [window setDelegate:nil];
        /* Default OPENSTEP NSWindows release themselves on close, together
           with their content view.  Do not release either object again. */
        [window close];
    }
    if (bitmap != nil) [bitmap release];
    if (pixels != NULL) SDL_free(pixels);
    if (present_pixels != NULL) SDL_free(present_pixels);
}

static WMcursor *OPENSTEP_CreateWMCursor(_THIS, Uint8 *data, Uint8 *mask,
                                         int w, int h, int hot_x, int hot_y)
{
    WMcursor *cursor;
    NSBitmapImageRep *representation;
    NSImage *image;
    unsigned char *planes[5];
    unsigned char *pixels;
    int source_bytes_per_row;
    int source_index;
    int target_index;
    int x;
    int y;
    int data_bit;
    int mask_bit;

    if ((data == NULL) || (mask == NULL) || (w <= 0) || (h <= 0)) {
        return NULL;
    }
    /* The OPENSTEP NXCursor reference requires at least a 16x16 image and
       displays only a 16x16 portion of larger images.  We pad smaller SDL
       cursors into a 16x16 native image, but reject larger cursors here so
       SDL core deliberately selects its size-preserving software fallback. */
    if ((w > 16) || (h > 16) || (hot_x >= 16) || (hot_y >= 16)) {
        return NULL;
    }
    cursor = (WMcursor *)SDL_malloc(sizeof(WMcursor));
    if (cursor == NULL) {
        SDL_OutOfMemory();
        return NULL;
    }
    cursor->cursor = nil;
    representation = [[NSBitmapImageRep alloc]
        initWithBitmapDataPlanes:NULL pixelsWide:16 pixelsHigh:16
        bitsPerSample:8 samplesPerPixel:4 hasAlpha:YES isPlanar:NO
        colorSpaceName:NSCalibratedRGBColorSpace bytesPerRow:64
        bitsPerPixel:32];
    if (representation == nil) goto failed;
    [representation getBitmapDataPlanes:planes];
    pixels = planes[0];
    SDL_memset(pixels, 0, 16 * 16 * 4);
    source_bytes_per_row = (w + 7) / 8;
    for (y = 0; (y < h) && (y < 16); ++y) {
        for (x = 0; (x < w) && (x < 16); ++x) {
            source_index = y * source_bytes_per_row + x / 8;
            /* NSCursor consumes its NSImage in the documented flipped
               upper-left cursor coordinate system.  Unlike the display
               bitmap backing plane, its image rows must retain SDL's
               top-to-bottom order. */
            target_index = (y * 16 + x) * 4;
            data_bit = data[source_index] & (0x80 >> (x & 7));
            mask_bit = mask[source_index] & (0x80 >> (x & 7));
            if (!mask_bit && !data_bit) continue;
            if (data_bit) {
                pixels[target_index] = 0;
                pixels[target_index + 1] = 0;
                pixels[target_index + 2] = 0;
            } else {
                pixels[target_index] = 255;
                pixels[target_index + 1] = 255;
                pixels[target_index + 2] = 255;
            }
            pixels[target_index + 3] = 255;
        }
    }
    image = [[NSImage alloc] initWithSize:NSMakeSize(16.0, 16.0)];
    if (image == nil) goto failed;
    [image addRepresentation:representation];
    [representation release];
    representation = nil;
    if (hot_x < 0) hot_x = 0;
    if (hot_y < 0) hot_y = 0;
    if (hot_x > 15) hot_x = 15;
    if (hot_y > 15) hot_y = 15;
    cursor->cursor = [[NSCursor alloc]
        initWithImage:image hotSpot:NSMakePoint((float)hot_x, (float)hot_y)];
    [image release];
    if (cursor->cursor == nil) goto failed;
    return cursor;

failed:
    if (representation != nil) [representation release];
    if (cursor->cursor != nil) [cursor->cursor release];
    SDL_free(cursor);
    SDL_OutOfMemory();
    return NULL;
}

static void OPENSTEP_FreeWMCursor(_THIS, WMcursor *cursor)
{
    if (cursor != NULL) {
        if (cursor->cursor != nil) [cursor->cursor release];
        SDL_free(cursor);
    }
}

static WMcursor *OPENSTEP_CreateInvisibleCursor(_THIS)
{
    Uint8 transparent_data[32];
    Uint8 transparent_mask[32];

    SDL_memset(transparent_data, 0, sizeof(transparent_data));
    SDL_memset(transparent_mask, 0, sizeof(transparent_mask));
    return OPENSTEP_CreateWMCursor(this, transparent_data, transparent_mask,
                                   16, 16, 0, 0);
}

static void OPENSTEP_ResetCursorRects(SDL_VideoDevice *device, NSView *view)
{
    SDL_Cursor *cursor;
    WMcursor *native_cursor;

    if ((device == NULL) || (view == nil)) return;
    native_cursor = NULL;
    if ((SDL_cursorstate & CURSOR_VISIBLE) != 0) {
        cursor = SDL_GetCursor();
        if (cursor != NULL) native_cursor = cursor->wm_cursor;
    } else {
        native_cursor = (WMcursor *)device->hidden->invisible_cursor;
    }
    if ((native_cursor != NULL) && (native_cursor->cursor != nil)) {
        [view addCursorRect:[view bounds] cursor:native_cursor->cursor];
    }
}

static int OPENSTEP_ShowWMCursor(_THIS, WMcursor *cursor)
{
    WMcursor *native_cursor;
    id window;
    id view;

    native_cursor = cursor;
    if (native_cursor == NULL) {
        native_cursor = (WMcursor *)this->hidden->invisible_cursor;
        if (native_cursor == NULL) {
            native_cursor = OPENSTEP_CreateInvisibleCursor(this);
            if (native_cursor == NULL) return 0;
            this->hidden->invisible_cursor = (void *)native_cursor;
        }
    }
    if ((native_cursor != NULL) && (native_cursor->cursor != nil)) {
        [native_cursor->cursor set];
    }
    window = (id)this->hidden->window;
    view = (id)this->hidden->view;
    if ((window != nil) && (view != nil)) {
        [window invalidateCursorRectsForView:view];
    }
    return 1;
}

static void OPENSTEP_WarpWMCursor(_THIS, Uint16 x, Uint16 y)
{
    id view;

    view = (id)this->hidden->view;
    if (view == nil) return;
    if (this->hidden->width > 0) {
        if (x >= this->hidden->width) x = this->hidden->width - 1;
    }
    if (this->hidden->height > 0) {
        if (y >= this->hidden->height) y = this->hidden->height - 1;
    }
    /* Display PostScript's documented setmouse operator moves both mouse
       location and cursor in the current coordinate system.  lockFocus makes
       that system the flipped SDL view's coordinates, so no Quartz/global
       screen conversion is involved. */
    [view lockFocus];
    PSsetmouse((float)x, (float)y);
    [view unlockFocus];
    SDL_PrivateMouseMotion(0, 0, (Sint16)x, (Sint16)y);
}

static SDL_Surface *OPENSTEP_SetVideoMode(_THIS, SDL_Surface *current,
                                          int width, int height, int bpp,
                                          Uint32 flags)
{
    SDL12OpenStepWindow *window;
    SDL12OpenStepView *view;
    NSBitmapImageRep *bitmap;
    NSRect frame;
    unsigned char *planes[1];
    unsigned char *pixels;
    unsigned char *present_pixels;
    int bytes_per_pixel;
    int pitch;
    int present_pitch;

    if ((flags & SDL_FULLSCREEN) != 0) {
        SDL_SetError("OPENSTEP AppKit driver has no fullscreen mode yet");
        return NULL;
    }
    if ((width <= 0) || (height <= 0) ||
        ((bpp != 8) && (bpp != 16) && (bpp != 24) && (bpp != 32))) {
        SDL_SetError("OPENSTEP AppKit driver supports 8/16/24/32bpp software surfaces");
        return NULL;
    }
    bytes_per_pixel = bpp / 8;
    pitch = width * bytes_per_pixel;
    present_pitch = width * 3;
    pixels = (unsigned char *)SDL_malloc((size_t)pitch * (size_t)height);
    if (pixels == NULL) {
        SDL_OutOfMemory();
        return NULL;
    }
    SDL_memset(pixels, 0, (size_t)pitch * (size_t)height);
    present_pixels = (unsigned char *)SDL_malloc((size_t)present_pitch *
                                                  (size_t)height);
    if (present_pixels == NULL) {
        SDL_free(pixels);
        SDL_OutOfMemory();
        return NULL;
    }
    SDL_memset(present_pixels, 0, (size_t)present_pitch * (size_t)height);
    planes[0] = present_pixels;
    bitmap = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:planes
                                                       pixelsWide:width
                                                       pixelsHigh:height
                                                    bitsPerSample:8
                                                  samplesPerPixel:3
                                                         hasAlpha:NO
                                                          isPlanar:NO
                                                colorSpaceName:NSCalibratedRGBColorSpace
                                                   bytesPerRow:present_pitch
                                                  bitsPerPixel:24];
    if (bitmap == nil) {
        SDL_free(pixels);
        SDL_free(present_pixels);
        SDL_SetError("OPENSTEP could not create NSBitmapImageRep");
        return NULL;
    }
    frame = NSMakeRect(80.0, 80.0, (float)width, (float)height);
    window = [[SDL12OpenStepWindow alloc]
                initWithContentRect:frame
                styleMask:(NSTitledWindowMask | NSClosableWindowMask |
                           NSMiniaturizableWindowMask |
                           (((flags & SDL_RESIZABLE) != 0) ?
                            NSResizableWindowMask : 0))
                backing:NSBackingStoreBuffered defer:NO device:this];
    if (window == nil) {
        [bitmap release];
        SDL_free(pixels);
        SDL_free(present_pixels);
        SDL_SetError("OPENSTEP could not create SDL window");
        return NULL;
    }
    view = [[SDL12OpenStepView alloc]
              initWithFrame:NSMakeRect(0.0, 0.0, (float)width, (float)height)
              device:this bitmap:bitmap];
    if (view == nil) {
        [window release];
        [bitmap release];
        SDL_free(pixels);
        SDL_free(present_pixels);
        SDL_OutOfMemory();
        return NULL;
    }
    [window setTitle:@"SDL 1.2 OPENSTEP"];
    [window setDelegate:view];
    [window setContentView:view];
    [window makeFirstResponder:view];
    [window makeKeyAndOrderFront:nil];
    [window setAcceptsMouseMovedEvents:YES];
    [[NSApplication sharedApplication] activateIgnoringOtherApps:YES];

    OPENSTEP_DestroyWindow(this);
    this->hidden->window = (void *)window;
    this->hidden->view = (void *)view;
    this->hidden->bitmap = (void *)bitmap;
    this->hidden->pixels = pixels;
    this->hidden->present_pixels = present_pixels;
    this->hidden->width = width;
    this->hidden->height = height;
    this->hidden->pitch = pitch;
    this->hidden->bits_per_pixel = bpp;
    this->hidden->resizable = ((flags & SDL_RESIZABLE) != 0);
    /* SDL_WM_SetCaption() is valid before the first SDL_SetVideoMode().
       SDL core retained wm_title then called SetCaption while no AppKit
       window existed, so apply that retained value once the window does. */
    OPENSTEP_SetCaption(this, this->wm_title, this->wm_icon);
    [window invalidateCursorRectsForView:view];
    if (!SDL_ReallocFormat(current, bpp,
                           (bpp == 8) ? 0 : ((bpp == 16) ? 0x0000f800 : 0x000000ff),
                           (bpp == 8) ? 0 : ((bpp == 16) ? 0x000007e0 : 0x0000ff00),
                           (bpp == 8) ? 0 : ((bpp == 16) ? 0x0000001f : 0x00ff0000),
                           0)) {
        OPENSTEP_DestroyWindow(this);
        SDL_SetError("OPENSTEP could not allocate SDL pixel format");
        return NULL;
    }
    current->flags = SDL_SWSURFACE | (flags & SDL_RESIZABLE);
    current->w = width;
    current->h = height;
    current->pitch = pitch;
    current->pixels = pixels;
    SDL_SetMouseRange(width, height);
    return current;
}

static int OPENSTEP_SetColors(_THIS, int firstcolor, int ncolors,
                              SDL_Color *colors)
{
    int index;

    if ((firstcolor < 0) || (ncolors < 0) ||
        ((firstcolor + ncolors) > 256) || (colors == NULL)) return 0;
    for (index = 0; index < ncolors; ++index) {
        this->hidden->palette[firstcolor + index] = colors[index];
    }
    return 1;
}

static void OPENSTEP_UpdateRects(_THIS, int numrects, SDL_Rect *rects)
{
    id view;
    int index;
    int left;
    int top;
    int right;
    int bottom;

    view = (id)this->hidden->view;
    if (view == nil) return;
    OPENSTEP_ConvertSurface(this, numrects, rects);
    this->hidden->presenting = 1;
    if ((numrects <= 0) || (rects == NULL)) {
        [view display];
    } else {
        /* OPENSTEP NSView documents displayRect: as an immediate redraw
           clipped to a rectangle in the receiving view's coordinate system.
           The view is flipped, so SDL's top-left rectangles can be passed
           directly; only the NSBitmapImageRep backing rows are reversed. */
        for (index = 0; index < numrects; ++index) {
            left = rects[index].x;
            top = rects[index].y;
            right = left + rects[index].w;
            bottom = top + rects[index].h;
            if (left < 0) left = 0;
            if (top < 0) top = 0;
            if (right > this->hidden->width) right = this->hidden->width;
            if (bottom > this->hidden->height) bottom = this->hidden->height;
            if ((right > left) && (bottom > top)) {
                [view displayRect:NSMakeRect((float)left, (float)top,
                                             (float)(right - left),
                                             (float)(bottom - top))];
            }
        }
    }
    this->hidden->presenting = 0;
}

static void OPENSTEP_ConvertSurface(_THIS, int numrects, SDL_Rect *rects)
{
    int index;
    int left;
    int top;
    int right;
    int bottom;

    if ((numrects <= 0) || (rects == NULL)) {
        OPENSTEP_ConvertRect(this, 0, 0, this->hidden->width,
                             this->hidden->height);
        return;
    }
    for (index = 0; index < numrects; ++index) {
        left = rects[index].x;
        top = rects[index].y;
        right = left + rects[index].w;
        bottom = top + rects[index].h;
        if (left < 0) left = 0;
        if (top < 0) top = 0;
        if (right > this->hidden->width) right = this->hidden->width;
        if (bottom > this->hidden->height) bottom = this->hidden->height;
        if ((right > left) && (bottom > top)) {
            OPENSTEP_ConvertRect(this, left, top, right, bottom);
        }
    }
}

static void OPENSTEP_ConvertRect(_THIS, int left, int top, int right,
                                 int bottom)
{
    unsigned char *source;
    unsigned char *target;
    Uint32 pixel;
    Uint16 pixel16;
    int x;
    int y;
    int present_y;
    int source_offset;
    int target_offset;

    source = this->hidden->pixels;
    target = this->hidden->present_pixels;
    if ((source == NULL) || (target == NULL)) return;
    for (y = top; y < bottom; ++y) {
        /* NSBitmapImageRep stores its first data row at the lower edge.
           SDL surface row 0 is the upper edge, so reverse only the backing
           bitmap row here; event coordinates are already top-left. */
        present_y = this->hidden->height - 1 - y;
        for (x = left; x < right; ++x) {
            source_offset = y * this->hidden->pitch;
            target_offset = (present_y * this->hidden->width + x) * 3;
            switch (this->hidden->bits_per_pixel) {
            case 8:
                pixel = source[source_offset + x];
                target[target_offset] = this->hidden->palette[pixel].r;
                target[target_offset + 1] = this->hidden->palette[pixel].g;
                target[target_offset + 2] = this->hidden->palette[pixel].b;
                break;
            case 16:
                pixel16 = *((Uint16 *)(source + source_offset + x * 2));
                target[target_offset] = (Uint8)((pixel16 >> 8) & 0xf8);
                target[target_offset + 1] = (Uint8)((pixel16 >> 3) & 0xfc);
                target[target_offset + 2] = (Uint8)((pixel16 << 3) & 0xf8);
                break;
            case 24:
                source_offset += x * 3;
                target[target_offset] = source[source_offset];
                target[target_offset + 1] = source[source_offset + 1];
                target[target_offset + 2] = source[source_offset + 2];
                break;
            default:
                pixel = *((Uint32 *)(source + source_offset + x * 4));
                target[target_offset] = (Uint8)(pixel & 0xff);
                target[target_offset + 1] = (Uint8)((pixel >> 8) & 0xff);
                target[target_offset + 2] = (Uint8)((pixel >> 16) & 0xff);
                break;
            }
        }
    }
}

static void OPENSTEP_VideoQuit(_THIS)
{
    OPENSTEP_DestroyWindow(this);
    if (this->hidden->invisible_cursor != NULL) {
        OPENSTEP_FreeWMCursor(this,
            (WMcursor *)this->hidden->invisible_cursor);
        this->hidden->invisible_cursor = NULL;
    }
    if (this->hidden->pool != NULL) {
        [(id)this->hidden->pool release];
        this->hidden->pool = NULL;
    }
}

static int OPENSTEP_AllocHWSurface(_THIS, SDL_Surface *surface)
{
    return -1;
}

static void OPENSTEP_FreeHWSurface(_THIS, SDL_Surface *surface)
{
}

static int OPENSTEP_LockHWSurface(_THIS, SDL_Surface *surface)
{
    return 0;
}

static void OPENSTEP_UnlockHWSurface(_THIS, SDL_Surface *surface)
{
}

static void OPENSTEP_SetCaption(_THIS, const char *title, const char *icon)
{
    NSString *string;

    if ((this->hidden->window == NULL) || (title == NULL)) return;
    string = [NSString stringWithCString:title];
    if (string != nil) [(id)this->hidden->window setTitle:string];
}

static int OPENSTEP_IconifyWindow(_THIS)
{
    if (this->hidden->window == NULL) return 0;
    [(id)this->hidden->window miniaturize:nil];
    return 1;
}

static SDL_GrabMode OPENSTEP_GrabInput(_THIS, SDL_GrabMode mode)
{
    if (mode == SDL_GRAB_QUERY) return SDL_GRAB_OFF;
    if (mode == SDL_GRAB_ON) {
        SDL_SetError("OPENSTEP AppKit mouse grab is not implemented");
    }
    return SDL_GRAB_OFF;
}

static void OPENSTEP_InitOSKeymap(_THIS)
{
}

static void OPENSTEP_PumpEvents(_THIS)
{
    NSEvent *event;

    for (;;) {
        event = [NSApp nextEventMatchingMask:NSAnyEventMask
                                    untilDate:[NSDate distantPast]
                                       inMode:NSDefaultRunLoopMode
                                      dequeue:YES];
        if (event == nil) break;
        [NSApp sendEvent:event];
    }
    [NSApp updateWindows];
}

static void OPENSTEP_SendKey(SDL_VideoDevice *device, NSEvent *event,
                             Uint8 state)
{
    SDL_keysym key;
    NSString *characters;
    unsigned short character;

    SDL_memset(&key, 0, sizeof(key));
    characters = [event characters];
    if ([characters length] == 0) {
        key.sym = SDLK_UNKNOWN;
    } else {
        character = (unsigned short)[characters characterAtIndex:0];
        key.sym = OPENSTEP_KeyForCharacter(character);
        key.unicode = (Uint16)character;
    }
    key.mod = OPENSTEP_Modifiers(device, event);
    SDL_PrivateKeyboard(state, &key);
}

static SDLKey OPENSTEP_KeyForCharacter(unsigned short character)
{
    /* AppKit represents these editing/control keys as ASCII control
       characters, while SDLKey reserves the same numeric values. */
    switch (character) {
    case 8: return SDLK_BACKSPACE;
    case 9: return SDLK_TAB;
    case 13: return SDLK_RETURN;
    case 27: return SDLK_ESCAPE;
    case 127: return SDLK_DELETE;
    default: break;
    }
    if ((character >= 32) && (character <= 127)) return (SDLKey)character;
    switch (character) {
    case NSUpArrowFunctionKey: return SDLK_UP;
    case NSDownArrowFunctionKey: return SDLK_DOWN;
    case NSLeftArrowFunctionKey: return SDLK_LEFT;
    case NSRightArrowFunctionKey: return SDLK_RIGHT;
    case NSInsertFunctionKey: return SDLK_INSERT;
    case NSDeleteFunctionKey: return SDLK_DELETE;
    case NSHomeFunctionKey: return SDLK_HOME;
    case NSEndFunctionKey: return SDLK_END;
    case NSPageUpFunctionKey: return SDLK_PAGEUP;
    case NSPageDownFunctionKey: return SDLK_PAGEDOWN;
    case NSHelpFunctionKey: return SDLK_HELP;
    case NSPauseFunctionKey: return SDLK_PAUSE;
    case NSPrintFunctionKey: return SDLK_PRINT;
    case NSClearDisplayFunctionKey: return SDLK_CLEAR;
    case NSF1FunctionKey: return SDLK_F1;
    case NSF2FunctionKey: return SDLK_F2;
    case NSF3FunctionKey: return SDLK_F3;
    case NSF4FunctionKey: return SDLK_F4;
    case NSF5FunctionKey: return SDLK_F5;
    case NSF6FunctionKey: return SDLK_F6;
    case NSF7FunctionKey: return SDLK_F7;
    case NSF8FunctionKey: return SDLK_F8;
    case NSF9FunctionKey: return SDLK_F9;
    case NSF10FunctionKey: return SDLK_F10;
    case NSF11FunctionKey: return SDLK_F11;
    case NSF12FunctionKey: return SDLK_F12;
    case NSF13FunctionKey: return SDLK_F13;
    case NSF14FunctionKey: return SDLK_F14;
    case NSF15FunctionKey: return SDLK_F15;
    default: return SDLK_UNKNOWN;
    }
}

static SDLMod OPENSTEP_Modifiers(SDL_VideoDevice *device, NSEvent *event)
{
    unsigned int flags;
    SDLMod mod;

    flags = [event modifierFlags];
    if (flags == 0) flags = device->hidden->modifier_flags;
    mod = KMOD_NONE;
    if (flags & NSShiftKeyMask) mod = (SDLMod)(mod | KMOD_LSHIFT);
    if (flags & NSControlKeyMask) mod = (SDLMod)(mod | KMOD_LCTRL);
    if (flags & NSAlternateKeyMask) mod = (SDLMod)(mod | KMOD_LALT);
    if (flags & NSCommandKeyMask) mod = (SDLMod)(mod | KMOD_LMETA);
    if (flags & NSAlphaShiftKeyMask) mod = (SDLMod)(mod | KMOD_CAPS);
    if (flags & NSNumericPadKeyMask) mod = (SDLMod)(mod | KMOD_NUM);
    if (flags & NSFunctionKeyMask) mod = (SDLMod)(mod | KMOD_MODE);
    return mod;
}

static void OPENSTEP_SendMouse(SDL_VideoDevice *device, NSEvent *event,
                               Uint8 state, Uint8 button)
{
    NSPoint point;
    NSView *view;
    int x;
    int y;

    view = (NSView *)device->hidden->view;
    if (view == nil) return;
    point = [view convertPoint:[event locationInWindow] fromView:nil];
    x = (int)point.x;
    y = (int)point.y;
    SDL_PrivateMouseButton(state, button, (Sint16)x, (Sint16)y);
}
