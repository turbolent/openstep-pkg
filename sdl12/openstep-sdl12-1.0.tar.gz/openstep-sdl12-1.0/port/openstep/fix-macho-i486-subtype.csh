#!/bin/csh -f
# OPENSTEP cc-744.13 emits an i586 Mach-O subtype even with -m486.  The
# target loader rejects it on the i486 system used for this port.  After a
# successful -m486 link, rewrite only mach_header.cpusubtype (offset 8) from
# 5 to 4 in the generated executable.  This never touches source or NFS.

if ($#argv != 1) then
    echo "usage: fix-macho-i486-subtype.csh executable"
    exit 2
endif
if (! -f $argv[1]) then
    echo "fix-macho-i486-subtype: file not found: $argv[1]"
    exit 2
endif

/usr/bin/perl -0777 -pi -e 'substr($_,8,1)=chr(4)' $argv[1]
if ($status != 0) exit 1
otool -h $argv[1]
