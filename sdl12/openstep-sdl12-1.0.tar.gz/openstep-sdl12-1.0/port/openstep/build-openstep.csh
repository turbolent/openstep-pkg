#!/bin/csh -f
# OPENSTEP's make does not expand wildcard source lists.  Let csh do that
# expansion and compile each C89 source explicitly.  Run from the copied
# /tmp/SDL12/build/SDL-1.2.15-openstep tree.

set cflags = "-m486 -O -Wall -D__OPENSTEP__ -I./include"
set nonomatch
set objects = ()
set number = 0

rm -f libSDL.a
if (! -d obj) mkdir obj
rm -f obj/*.o

foreach source (src/*.c src/audio/*.c src/cdrom/*.c src/cpuinfo/*.c src/events/*.c src/file/*.c src/joystick/*.c src/stdlib/*.c src/thread/*.c src/timer/*.c src/video/*.c src/audio/dummy/*.c src/cdrom/dummy/*.c src/joystick/dummy/*.c src/thread/openstep/*.c src/timer/openstep/*.c src/loadso/dummy/*.c)
    @ number = $number + 1
    set object = obj/$number.o
    echo "CC $source"
    cc $cflags -c $source -o $object
    if ($status != 0) exit 1
    set objects = ($objects $object)
end

foreach source (src/video/openstep/*.m)
    @ number = $number + 1
    set object = obj/$number.o
    echo "CC $source"
    cc $cflags -c $source -o $object
    if ($status != 0) exit 1
    set objects = ($objects $object)
end

foreach source (src/audio/openstep/*.m)
    @ number = $number + 1
    set object = obj/$number.o
    echo "CC $source"
    cc $cflags -c $source -o $object
    if ($status != 0) exit 1
    set objects = ($objects $object)
end

ar cr libSDL.a $objects
if ($status != 0) exit 1
ranlib libSDL.a
exit $status
