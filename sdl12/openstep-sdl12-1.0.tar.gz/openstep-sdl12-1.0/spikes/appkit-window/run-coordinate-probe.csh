#!/bin/csh -f
# Run the standalone AppKit coordinate probe from an OPENSTEP GUI Terminal.

set program_dir = /tmp/SDL12/src/spikes/appkit-window
set program = $program_dir/appkit-window
set log = /tmp/SDL12/log/appkit-coordinate-probe.log

if (! -x $program) then
    echo "run-coordinate-probe: missing $program"
    echo "build it first: cd $program_dir; make"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

echo "AppKit coordinate probe: click once near top and once near bottom, then close"
$program >&! $log &
exit 0
