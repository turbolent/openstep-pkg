/*
 * OPENSTEP SDL 1.2 port -- Phase 0 AppKit/DPS window probe.
 *
 * This intentionally has no SDL dependency.  It proves that a code-only
 * AppKit application can create an NSView, receive the first-responder input
 * events that SDL must translate, and redraw after exposure or resize.
 */

#import <AppKit/AppKit.h>
#include <stdio.h>

@interface SDL12ProbeView : NSView
@end

@interface SDL12ProbeController : NSObject
@end

@implementation SDL12ProbeView

- (BOOL)isFlipped
{
    /* SDL screen coordinates have their origin at the upper left. */
    return YES;
}

- (BOOL)acceptsFirstResponder
{
    return YES;
}

- (void)drawRect:(NSRect)rect
{
    NSRect bounds;
    NSColor *color;
    int x;
    int y;
    int cell;

    bounds = [self bounds];
    cell = 32;

    [[NSColor blackColor] set];
    NSRectFill(bounds);

    /* A fixed RGB checkerboard makes expose/redraw failures obvious. */
    for (y = 0; y < (int)NSHeight(bounds); y += cell) {
        for (x = 0; x < (int)NSWidth(bounds); x += cell) {
            if (((x / cell) + (y / cell)) & 1) {
                color = [NSColor colorWithCalibratedRed:0.10
                                                   green:0.35
                                                    blue:0.85
                                                   alpha:1.0];
            } else {
                color = [NSColor colorWithCalibratedRed:0.85
                                                   green:0.25
                                                    blue:0.10
                                                   alpha:1.0];
            }
            [color set];
            NSRectFill(NSMakeRect((float)x, (float)y,
                                  (float)cell, (float)cell));
        }
    }

    [[NSColor whiteColor] set];
    [@"OPENSTEP SDL 1.2 AppKit/DPS probe" drawAtPoint:NSMakePoint(12.0, 12.0)
                                         withAttributes:nil];
    fprintf(stderr, "APPKIT_PROBE_DRAW %.0f %.0f\n",
            NSWidth(bounds), NSHeight(bounds));
}

- (void)keyDown:(NSEvent *)event
{
    fprintf(stderr, "APPKIT_PROBE_KEYDOWN code=%u flags=%lu\n",
            (unsigned int)[event keyCode], (unsigned long)[event modifierFlags]);
}

- (void)keyUp:(NSEvent *)event
{
    fprintf(stderr, "APPKIT_PROBE_KEYUP code=%u flags=%lu\n",
            (unsigned int)[event keyCode], (unsigned long)[event modifierFlags]);
}

- (void)mouseDown:(NSEvent *)event
{
    NSPoint raw;
    NSPoint point;
    NSRect bounds;

    raw = [event locationInWindow];
    point = [self convertPoint:raw fromView:nil];
    bounds = [self bounds];
    fprintf(stderr,
            "APPKIT_PROBE_MOUSEDOWN raw=%.0f,%.0f view=%.0f,%.0f manual=%.0f\n",
            raw.x, raw.y, point.x, point.y, NSHeight(bounds) - raw.y);
}

- (void)mouseMoved:(NSEvent *)event
{
    NSPoint raw;
    NSPoint point;
    NSRect bounds;

    raw = [event locationInWindow];
    point = [self convertPoint:raw fromView:nil];
    bounds = [self bounds];
    fprintf(stderr,
            "APPKIT_PROBE_MOUSEMOVE raw=%.0f,%.0f view=%.0f,%.0f manual=%.0f\n",
            raw.x, raw.y, point.x, point.y, NSHeight(bounds) - raw.y);
}

@end

@implementation SDL12ProbeController

- (void)windowWillClose:(NSNotification *)notification
{
    fprintf(stderr, "APPKIT_PROBE_CLOSE\n");
    [NSApp stop:nil];
}

@end

int main(int argc, const char *argv[])
{
    NSAutoreleasePool *pool;
    NSApplication *app;
    NSWindow *window;
    SDL12ProbeView *view;
    SDL12ProbeController *controller;
    NSRect frame;

    pool = [[NSAutoreleasePool alloc] init];
    app = [NSApplication sharedApplication];
    frame = NSMakeRect(120.0, 120.0, 640.0, 480.0);
    window = [[NSWindow alloc] initWithContentRect:frame
                                         styleMask:(NSTitledWindowMask |
                                                    NSClosableWindowMask |
                                                    NSResizableWindowMask |
                                                    NSMiniaturizableWindowMask)
                                           backing:NSBackingStoreBuffered
                                             defer:NO];
    view = [[SDL12ProbeView alloc] initWithFrame:
              NSMakeRect(0.0, 0.0, 640.0, 480.0)];
    controller = [[SDL12ProbeController alloc] init];

    [window setTitle:@"SDL 1.2 OPENSTEP Probe"];
    [window setDelegate:controller];
    [window setContentView:view];
    [window makeFirstResponder:view];
    [window setAcceptsMouseMovedEvents:YES];
    [window makeKeyAndOrderFront:nil];
    [app activateIgnoringOtherApps:YES];
    fprintf(stderr, "APPKIT_PROBE_READY\n");
    [app run];

    [controller release];
    [view release];
    [window release];
    [pool release];
    return 0;
}
