# AppKit/DPS window probe

상태: **OPENSTEP 4.2 WindowServer 실기 통과 (2026-08-11)**. SDL backend가
완성된 현재는 AppKit/DPS 회귀 진단용으로 보존한다.

Phase 0의 첫 실기 검증 프로그램이다. SDL을 링크하지 않는다. 코드만으로 만든
`NSApplication`/`NSWindow`/`NSView`가 DPS drawing을 수행하고, 화면 좌상단 원점으로
전환한 view가 keyboard/mouse event를 받는지를 확인한다.

## OPENSTEP 실행

NFS 원본을 먼저 `/tmp/SDL12/src`로 staging한 뒤 실행한다.

```csh
cd /tmp/SDL12/src/spikes/appkit-window
make clean
make
./appkit-window >& /tmp/SDL12/log/appkit-window.log &
```

WindowServer가 있는 실기 콘솔에서 창을 가리고 다시 노출하고, 크기를 바꾸고, 창을
클릭한 뒤 키와 마우스를 움직인다. 로그에는 다음 marker가 나와야 한다.

- `APPKIT_PROBE_READY`
- `APPKIT_PROBE_DRAW <width> <height>` (초기 표시·노출·resize 뒤)
- `APPKIT_PROBE_KEYDOWN` 및 `APPKIT_PROBE_KEYUP`
- `APPKIT_PROBE_MOUSEDOWN` 및 `APPKIT_PROBE_MOUSEMOVE` (`raw`, view 변환,
  수동 y 반전 값을 함께 기록)
- 창을 닫으면 `APPKIT_PROBE_CLOSE`

실기에서 초기 표시, 가림/재노출, resize, key/mouse와 close marker를
확인했다. 이 결과로 AppKit run loop·flipped view 좌표·기본 event 경로를
확정했으며, 최종 SDL 결과는 `../../TESTING.md`와
`../../notes/completion-audit.md`에 기록한다. 이 프로그램 자체는 SDL video
backend가 아니다.
