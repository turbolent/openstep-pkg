# Bitmap presenter probe

상태: **OPENSTEP 4.2 WindowServer 실기 통과 (2026-08-11)**. caller buffer의
row 0이 화면 아래에 표시되어 `NSBitmapImageRep` backing이 bottom-up임을
확인했다.

SDL 1.2 screen surface와 같은 호출자 소유 RGB 메모리를 `NSBitmapImageRep`으로
직접 표시하는 Phase 0 검증 프로그램이다. 실기 OPENSTEP 4.2 Framework 헤더의
`-initWithBitmapDataPlanes:pixelsWide:pixelsHigh:bitsPerSample:samplesPerPixel:hasAlpha:isPlanar:colorSpaceName:bytesPerRow:bitsPerPixel:`와
상속된 `-drawInRect:`를 사용한다. plane이 NULL이 아닐 때 image rep은 buffer를
복사하거나 해제하지 않는다는 API 규약에 의존한다.

## OPENSTEP 실행

```csh
cd /tmp/SDL12/src/spikes/bitmap-presenter
make clean
make
./bitmap-presenter >& /tmp/SDL12/log/bitmap-presenter.log &
```

caller buffer의 첫 16행은 빨강, 마지막 16행은 파랑이며, 그 사이에는 가로(red)·
세로(green) gradient와 blue XOR pattern이 있다. 이 probe의 화면상 red/blue 위치는
`NSBitmapImageRep` backing row 원점의 실측 근거다. 창 가림/노출과 resize 뒤에도
같은 이미지가 다시 그려져야 한다.

필수 log marker:

- `BITMAP_PROBE_READY`
- `BITMAP_PROBE_DRAW <width> <height>` (초기 표시·노출·resize 뒤)
- `BITMAP_PROBE_CLOSE`

최종 SDL presenter는 SDL top-down source row를 caller-owned 24-bit RGB buffer에
반전 복사한다. cursor `NSImage`에는 이 반전을 적용하지 않는다.
8/16/24/32bpp 변환, `displayRect:` dirty clipping, expose/resize와 cursor는
최종 WindowServer 묶음에서 통과했다. 상세 결과는 `../../TESTING.md`와
`../../notes/api-inventory.md`에 기록한다.
