#!/bin/csh -f
# Run the AppKit/DPS caller-owned bitmap backing-store probe.

set program_dir = /tmp/SDL12/src/spikes/bitmap-presenter
set program = $program_dir/bitmap-presenter
set log = /tmp/SDL12/log/bitmap-presenter.log

if (! -x $program) then
    echo "run-bitmap-probe: missing $program"
    echo "build it first: cd $program_dir; make"
    exit 1
endif
if (! -d /tmp/SDL12/log) mkdir /tmp/SDL12/log

echo "Bitmap backing probe: verify red/blue edge bands, then cover and uncover"
$program >&! $log &
exit 0
