/*
 * OPENSTEP SDL 1.2 port -- Phase 0 software surface presenter probe.
 *
 * NSBitmapImageRep is deliberately initialized with a caller-owned RGB buffer.
 * OPENSTEP documents that initData:... references a non-NULL buffer rather
 * than copying or freeing it.  This is the intended first presenter path for
 * SDL's software screen surface.
 */

#import <AppKit/AppKit.h>
#include <stdio.h>
#include <stdlib.h>

#define PROBE_WIDTH  320
#define PROBE_HEIGHT 240
#define PROBE_BPP    3

@interface SDL12BitmapView : NSView
{
    unsigned char *_pixels;
    NSBitmapImageRep *_bitmap;
}
- (void)fillPattern;
@end

@interface SDL12BitmapController : NSObject
@end

@implementation SDL12BitmapView

- initWithFrame:(NSRect)frame
{
    int pitch;
    unsigned char *planes[1];

    [super initWithFrame:frame];
    pitch = PROBE_WIDTH * PROBE_BPP;
    _pixels = (unsigned char *)malloc((unsigned long)pitch * PROBE_HEIGHT);
    if (_pixels == NULL) return nil;

    [self fillPattern];
    planes[0] = _pixels;
    _bitmap = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:planes
                                                        pixelsWide:PROBE_WIDTH
                                                        pixelsHigh:PROBE_HEIGHT
                                                     bitsPerSample:8
                                                   samplesPerPixel:3
                                                          hasAlpha:NO
                                                           isPlanar:NO
                                                 colorSpaceName:NSCalibratedRGBColorSpace
                                                    bytesPerRow:pitch
                                                   bitsPerPixel:24];
    if (_bitmap == nil) {
        free(_pixels);
        _pixels = NULL;
        return nil;
    }
    return self;
}

- (void)dealloc
{
    [_bitmap release];
    if (_pixels != NULL) free(_pixels);
    [super dealloc];
}

- (BOOL)isFlipped
{
    return YES;
}

- (void)fillPattern
{
    int x;
    int y;
    int offset;

    for (y = 0; y < PROBE_HEIGHT; ++y) {
        for (x = 0; x < PROBE_WIDTH; ++x) {
            offset = (y * PROBE_WIDTH + x) * PROBE_BPP;
            if (y < 16) {
                /* Caller buffer row 0: used to establish bitmap row origin. */
                _pixels[offset + 0] = 255;
                _pixels[offset + 1] = 0;
                _pixels[offset + 2] = 0;
            } else if (y >= (PROBE_HEIGHT - 16)) {
                /* Last caller buffer row: must appear at the opposite edge. */
                _pixels[offset + 0] = 0;
                _pixels[offset + 1] = 0;
                _pixels[offset + 2] = 255;
            } else {
                _pixels[offset + 0] = (unsigned char)((x * 255) /
                                                       (PROBE_WIDTH - 1));
                _pixels[offset + 1] = (unsigned char)((y * 255) /
                                                       (PROBE_HEIGHT - 1));
                _pixels[offset + 2] = (unsigned char)((x ^ y) & 0xff);
            }
        }
    }
}

- (void)drawRect:(NSRect)rect
{
    NSRect target;

    target = [self bounds];
    [_bitmap drawInRect:target];
    fprintf(stderr, "BITMAP_PROBE_DRAW %.0f %.0f\n",
            NSWidth(target), NSHeight(target));
}

@end

@implementation SDL12BitmapController

- (void)windowWillClose:(NSNotification *)notification
{
    fprintf(stderr, "BITMAP_PROBE_CLOSE\n");
    [NSApp stop:nil];
}

@end

int main(int argc, const char *argv[])
{
    NSAutoreleasePool *pool;
    NSApplication *app;
    NSWindow *window;
    SDL12BitmapView *view;
    SDL12BitmapController *controller;
    NSRect frame;

    pool = [[NSAutoreleasePool alloc] init];
    app = [NSApplication sharedApplication];
    frame = NSMakeRect(160.0, 160.0, 640.0, 480.0);
    window = [[NSWindow alloc] initWithContentRect:frame
                                         styleMask:(NSTitledWindowMask |
                                                    NSClosableWindowMask |
                                                    NSResizableWindowMask)
                                           backing:NSBackingStoreBuffered
                                             defer:NO];
    view = [[SDL12BitmapView alloc] initWithFrame:
              NSMakeRect(0.0, 0.0, 640.0, 480.0)];
    controller = [[SDL12BitmapController alloc] init];
    if ((window == nil) || (view == nil)) {
        fprintf(stderr, "BITMAP_PROBE_INIT_FAILED\n");
        return 1;
    }

    [window setTitle:@"SDL 1.2 OPENSTEP Bitmap Probe"];
    [window setDelegate:controller];
    [window setContentView:view];
    [window makeKeyAndOrderFront:nil];
    [app activateIgnoringOtherApps:YES];
    fprintf(stderr, "BITMAP_PROBE_READY\n");
    [app run];

    [controller release];
    [view release];
    [window release];
    [pool release];
    return 0;
}
