# stars-1.0 source record

- Program: `stars`, rotating starfield by Nathan Strong; SDL port credited to
  Sam Lantinga in the program output.
- Mirror: `https://github.com/jprzywoski/sdl-docs`
- Commit: `3cfbd844de2b32f48aaabe17f3c4f647e1646e0f`
- Mirror path: `Demos/stars-1.0/`
- Acquired: 2026-08-11
- `main.c` SHA-256:
  `c71add8a2f9bff440970c23c030ea1328268c6c76ee2d794d7c9ae772ba1c59c`
- `README` SHA-256:
  `4797aba0d964d6cf84734aeebadac20ce6f50562e9adeb27f740c8f9cfa45e66`

The source header states that there is no copyright or restriction, permits
any use and asks for credit.  The header and README are retained verbatim.
The C source is not modified for OPENSTEP.
