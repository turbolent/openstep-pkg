# xflame-1.0 source record

- Program: `XFlame v1.0`, by The Rasterman (Carsten Haitzler), ported to SDL
  by Sam Lantinga.
- Mirror: `https://github.com/jprzywoski/sdl-docs`
- Commit: `3cfbd844de2b32f48aaabe17f3c4f647e1646e0f`
- Mirror path: `Demos/xflame-1.0/`
- Acquired: 2026-08-11
- `main.c` SHA-256:
  `3a89af884a6f08749c7a22fe62d5033e802082fb3595ea80230313248af33f74`
- `README` SHA-256:
  `99bf9bdb338b08ddd70e7d86c6ff18150fc2043b48d1305ce995d98cc363e97e`

The retained source header calls the code freeware, permits copying,
modification and any use, and prohibits claiming copyright on derived code.
The source and README are byte-for-byte copies of the recorded commit and are
not modified for OPENSTEP. Despite its historical name, this SDL port includes
no X11 header or Xlib call.
