# External SDL 1.2 compatibility programs

This directory contains small third-party SDL 1.2 programs used unchanged at
the source level to verify that the OPENSTEP backend works outside SDL's own
test suite.  Each subdirectory records its exact source commit, hashes and
license statement.  OPENSTEP-specific include/link commands live separately
under `test/openstep/`.

All retained programs depend only on SDL 1.2 and, where used, the C math
library. They do not introduce SDL_image, SDL_mixer, SDL_ttf, OpenGL or X11
dependencies. `stars-1.0` and `xflame-1.0` are the final compatibility
acceptance programs because their loops explicitly ignore unrelated SDL
events and exit only on key/quit. `plasma-1.0` is retained as an additional
public-domain source/build probe, but its original loop exits on any queued
event—including a legitimate initial `SDL_VIDEOEXPOSE`—so it is not used as
a cross-driver runtime acceptance test.
