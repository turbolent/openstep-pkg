# plasma-1.0 source record

- Program: `plasma`, by Bini Michele.
- Mirror: `https://github.com/jprzywoski/sdl-docs`
- Commit: `3cfbd844de2b32f48aaabe17f3c4f647e1646e0f`
- Mirror path: `Demos/plasma-1.0/`
- Acquired: 2026-08-11
- `main.c` SHA-256:
  `4d793f054ae6b9271ed0f422bfbe6b1ca68156e873589a8de8993d79e7c1bbd0`
- `README` SHA-256:
  `43e6bb074121377b5aed1f2fdc6d4ee43392988c76fe604fdef83b9edd7ab1da`

The upstream README declares the demo public domain.  The README is retained
verbatim with the source.  The C source is not modified for OPENSTEP.
