# OPENSTEP 검증 기록

갱신: 2026-08-11

## 통과한 비화면 빌드 관문

OPENSTEP 4.2의 네이티브 `cc`(NeXT Software cc-744.13, gcc 2.7.2.1)에서
`/tmp/SDL12/build/SDL-1.2.15-openstep/libSDL.a`를 만들었다. 다음 구성요소가
실제 대상 컴파일을 통과했다.

- SDL core, event queue, software surface/blit
- `src/video/openstep/SDL_openstepvideo.m` AppKit/DPS 드라이버
- `src/timer/openstep/SDL_systimer.c` BSD `gettimeofday`/`setitimer` timer
- `src/thread/openstep/` Mach cthreads thread/mutex/condition/semaphore backend
- `src/audio/openstep/SDL_openstepaudio.m` SoundKit native C Sound API
  (`SNDStartPlaying` FCFS queue) backend (native compile/link)
- NSEvent의 arrows, Home/End, PageUp/PageDown, Insert/Delete, F1–F15와
  Shift/Ctrl/Alt/Command/Caps/Num modifier를 SDLKey/SDLMod로 매핑하는 AppKit
  입력 코드 (native compile)
- NSWindow key focus 변화의 `SDL_APPACTIVE`/`SDL_APPINPUTFOCUS` 변환
  (native compile)
- `SDL_WM_SetCaption` title 설정 및 `SDL_WM_IconifyWindow` miniaturize
  AppKit callback (native compile)
- SDL 8/16/24/32bpp software surface를 검증된 AppKit 24bpp RGB bitmap으로
  변환하는 presenter와 `displayRect:` 기반 `SDL_UpdateRects()` dirty-rect 표시
  (native compile)
- `SDL_RESIZABLE` window mask, `windowDidResize:` → `SDL_VIDEORESIZE`, 재호출한
  `SDL_SetVideoMode()` 경로 (native compile)
- OPENSTEP `NSCursor` 기반 16x16 이하 custom cursor/표시·숨김과, Display
  PostScript `PSsetmouse` 기반 `SDL_WarpMouse()` (native compile)
- `test/openstep/sdl-video-events.c`와 AppKit/Foundation 링크

이 빌드는 X11 헤더·라이브러리·서버를 사용하지 않는다.
Overlay/config 정적 점검에서도 `SDL_VIDEO_DRIVER_OPENSTEP`,
`SDL_AUDIO_DRIVER_OPENSTEP`, `SDL_THREAD_OPENSTEP`, `SDL_TIMER_OPENSTEP`만
활성화되고 X11/Xlib/pthread backend는 활성화되지 않음을 확인했다.

## 검증 상태와 제한

- headless shell에는 WindowServer 연결이 없으므로 AppKit 창의 표시, redraw,
  입력은 console GUI session에서만 확인할 수 있다. dirty-rect, resize,
  cursor visibility, warp와 외부 예제는 이 문서 마지막의 7단계
  WindowServer 묶음 검증을 통과했다.
- 대상 `cc`는 `-m486`에도 Mach-O subtype을 i586(5)으로 표기하며 loader가 이를
  거부한다. `port/openstep/fix-macho-i486-subtype.csh`가 성공한 `-m486` 링크
  결과의 header subtype만 i486(4)으로 보정한다. 이 절차를 적용한
  `sdl-timer`는 최종 headless run에서 `SDL_TIMER_OK: 240 callback=1`을
  출력했다. `gettimeofday`가 역행할 때는 마지막 `timeval`로 clamp하되,
  SDL 문서가 정한 약 49일의 `Uint32` wrap은 허용한다. 인위적인 경계 산술 시험은
  `SDL_TIMER_WRAP_OK: 1234`를 출력했다.
- `sdl-threads`는 같은 방식으로 `SDL_THREAD_OK`를 출력했다. 즉
  `SDL_CreateThread`, mutex, semaphore, join과 condition wait/signal 및
  timeout의 Mach cthreads 경로는 실기 runtime을 통과했다.
- video는 창 모드에서 8/16/24/32bpp software surface, 개별 dirty-rect 즉시 표시,
  `SDL_RESIZABLE`과 `SDL_VIDEORESIZE`를 구현한다. 여러 dirty rect는 합치지 않고
  `displayRect:`로 각각 clip해 표시한다. fullscreen과 grab/relative mouse는
  지원하지 않는다. 모든 bpp의 색상/palette와 일반·특수키/drag/focus는 실기
  통과했으며, modifier flag와 물리적 우클릭 일부는 현재 입력 장치 경로의 제한으로
  보류한다. resize/dirty clipping은 서로 다른 resize 3회와
  두 dirty rect의 단계적 표시로 최종 GUI 묶음에서 통과했다.
- `SDL_GrabInput(SDL_GRAB_ON)`은 현재 명시적으로 `SDL_GRAB_OFF`와 오류를
  반환한다. 상대 mouse mode도 제공하지 않는다. 반면 `SDL_WarpMouse()`는
  OPENSTEP DPS의 `PSsetmouse`로 구현했으며 요청/state가 같은 세 좌표와
  상하 mirror 부재를 최종 GUI 묶음에서 통과했다.
- `NXPlayStream`은 explicit activation 뒤에도 i486 PCM byte order와 단일 buffer
  재사용 때문에 GUI에서 잡음·underrun을 냈다. backend는 native
  `SNDStartPlaying()` FCFS queue를 모든 세션에서 사용한다. 이 경로의 WAV callback,
  30초 지속 재생, pause/resume/close와 GUI video 동시 부하는 실기 통과했다.
  GUI 300초 장기 청취·video 동시 부하와 audio-only `sdl-audio-loop` 300초 회귀도
  실기 통과했다.

## 제공 MP3의 SoundKit 재생 검증

사용자가 지정한 로컬 MP3는 저장소에 넣지 않고, 작업용 `assets/`에만 표준 RIFF
WAV(44.1 kHz, stereo, signed 16-bit little-endian PCM)로 변환한다. 이 형식은
OPENSTEP i486의 `AUDIO_S16SYS`와 일치하며 SDL의 `SDL_LoadWAV()` 경로도 함께
검증한다. 변환 결과는 `.gitignore` 처리되어 배포물에 포함하지 않는다. 전체 WAV는
약 43 MB이므로 old `tar`의 archive+extract가 target `/tmp`를 두 배로 점유하지
않도록 stage archive에서는 제외한다.

console GUI session에서 stage/build 후 다음처럼 실행한다.

```csh
cd /tmp/SDL12/src/test/openstep
if (! -d /tmp/SDL12/audio) mkdir /tmp/SDL12/audio
cp /ndrv/openstep-sdl12/assets/hiyuki-openstep-test-15s-44100-s16.wav /tmp/SDL12/audio/
./sdl-wav-audio /tmp/SDL12/audio/hiyuki-openstep-test-15s-44100-s16.wav
```

성공 시 시작 전 `SDL_WAV_AUDIO_READY`가 출력되고, 재생이 끝나면
`SDL_WAV_AUDIO_OK`가 출력된다. 실제 가청 출력은 사용자가 확인한다.

`sound-api-play`은 SDL driver를 우회하는 legacy C Sound API 진단이다. 같은
15초를 NeXT `.snd`로 변환해 다음처럼 실행한다. `SDL_WAV_AUDIO_OPEN_FAILED`
가 발생할 때 이것도 실패하면, 문제는 SDL PCM callback이 아니라 target의
sound device/service 구성이다.

```csh
cp /ndrv/openstep-sdl12/assets/hiyuki-openstep-test-15s-44100-s16.snd /tmp/SDL12/audio/
./sound-api-play /tmp/SDL12/audio/hiyuki-openstep-test-15s-44100-s16.snd
```

SDL backend는 모든 세션에서 native `SNDStartPlaying()`를 사용한다.
`openstep-mp3player/src/PlaybackEngine.m`에서 실기 검증된 방식대로
0.25초 chunk를 최대 8개로 제한된 bookkeeping에 보관하고, 정상 상태에서는 4개를
`preempt=0` FCFS queue로 선행 제출한다. 그 뒤 가장 오래된 tag만 `SNDWait()`으로
회수해 해당 block을 해제한다. SDL audio callback 자체는 할당하지 않고 mix buffer만
채운다. chunk마다 play/wait를 직렬화하면
DAC 경계마다 gap이 생겨 느리게 들리므로 금지한다. 이 구현은 16-bit PCM을 NeXT
big-endian `SND_FORMAT_LINEAR_16`로 변환한다.

2026-08-11 target run에서 `sound-api-play`은 `SOUND_API_READY`와
`SOUND_API_OK`를, queued fallback을 사용한 `sdl-wav-audio`는
`SDL_WAV_AUDIO_READY`와 `SDL_WAV_AUDIO_OK`를 각각 출력했다. 후자는
`SDL_LoadWAV()` → SDL callback → native sound queue 전체를 실행한 결과다.
console 사용자는 15초 WAV가 정상 속도·끊김 없이 들렸음을 확인했다.

지속 재생 회귀는 `sdl-audio-loop [wav] [seconds]`로 실행한다. 기본값은 300초,
허용 범위는 1–300초다. GUI Terminal에서는 `run-audio-loop.csh`가 NFS WAV 경로와
`/tmp/SDL12/log/sdl-audio-loop.log`를 설정한다. 첫 인자로 1–300초를 줄 수 있다.
먼저 30초로 queue/callback 지속성을 확인한 뒤 300초 실행을 기록한다.

2026-08-11의 30초 실기 결과는 `SDL_AUDIO_LOOP_OK: callbacks=123
bytes=5424300 elapsed=31049`이다. process가 남지 않았고, queue 기반 callback
경로의 지속성은 이 범위에서 통과했다. 같은 날 audio-only 300초 회귀는
`SDL_AUDIO_LOOP_OK: callbacks=1199 bytes=52875900 elapsed=300833`으로
자연 종료했다. 즉 native sound queue, SDL audio callback thread, close/drain
경로가 UI 없이도 5분 동안 지속됐고 process가 남지 않았다.

`sdl-audio-pause`는 callback 수와 `SDL_GetAudioStatus()`를 이용해 pause/resume/
close 계약을 점검한다. SDL 원본 `SDL_PauseAudio.3`에 따라 paused 구간에는 callback
대신 silence가 공급되어야 한다. 2026-08-11 실제 fallback queue 실행 결과는
`SDL_AUDIO_PAUSE_OK: 3 3 8`이었다. 즉 pause 전 callback 3회가 1초 pause 뒤에도
3회로 유지됐고, resume 뒤 8회로 다시 증가했다. test는 close 뒤
`SDL_AUDIO_STOPPED`도 확인한다. 보존한 target log는
`notes/sdl-audio-pause-20260811.log`다.

5분 audio+video 동시 부하용 `sdl-av-stress`는 위 15초 WAV를 callback에서 끝까지
읽을 때마다 처음으로 되감아 반복 재생한다. 따라서 장시간 실기는 큰 미디어 파일을
옮기지 않고도 queue 지속성, video 갱신, AppKit event pump를 함께 확인한다. target
log에는 30초마다 callback/byte progress를 남긴다.

이 test는 5분간 가청 출력과 창 갱신을 수행하므로 GUI Terminal에서만 실행한다.
새 source가 아직 `/tmp/SDL12/src`에 stage되지 않은 경우 먼저 다음 build를 수행한다.

```csh
cp /ndrv/openstep-sdl12/test/openstep/sdl-av-stress.c /tmp/SDL12/src/test/openstep/
cp /ndrv/openstep-sdl12/test/openstep/Makefile /tmp/SDL12/src/test/openstep/
cd /tmp/SDL12/src/test/openstep
make sdl-av-stress
```

그 다음 짧은 WAV를 반복 재생하는 5분 실기를 시작한다. WAV는 NFS 원본에서
읽기만 하므로, root-squash가 적용된 중첩 NFS 디렉터리에 쓰기를 시도하지 않는다.
창을 닫지 말고, 필요하면 다른 창으로 가렸다가 다시 보이게 하거나 mouse를
움직여 video/event 부하도 준다. GUI Terminal에서는 `run-av-stress.csh`만
실행하면 된다. 첫 인자로 1–300초를 주면 그 길이로 단축할 수 있다.

```csh
./run-av-stress.csh

# 예: 30초 단축 점검
./run-av-stress.csh 30
```

성공 조건은 `/tmp/SDL12/log/sdl-av-stress.log`의 30초 progress 행들과 마지막
`SDL_AV_OK`다. 이 행은 AppKit 최종 window teardown 전에 기록된다. close로 중단하면
`SDL_AV_QUIT_EARLY` 및 `SDL_AV_FAILED`가 남아 실기 실패로 구분된다.

## console GUI session에서 실행할 명령

CPU subtype 문제가 해결된 대상 컴파일러를 사용한다는 전제에서 다음 순서다.

```csh
/ndrv/openstep-sdl12/build/stage-openstep.csh
/bin/csh -f /tmp/SDL12/src/build/prepare-openstep-tree.csh
cd /tmp/SDL12/build/SDL-1.2.15-openstep
make
cd /tmp/SDL12/src/test/openstep
make
./sdl-video-events
```

`./sdl-video-events 8`, `16`, `24`, `32`로 각 software surface 포맷을
확인한다. 모두 RGB gradient가 동일하게 보이고 palette(8bpp)가 적용돼야 한다.

WindowServer console 검증용으로는 `sdl-video-events`를
`/tmp/SDL12/bin/SDLVideoEvents.app` bundle에 넣고 Workspace `open`으로 실행한다.
기본 실행 시간은 600초이며 `/tmp/SDL12/log/sdl-video-events.log`에 key, mouse,
quit 결과를 남긴다. 8/16/24/32bpp variant는 executable을 인수와 함께 직접
WindowServer 문맥에서 실행할 때 기록한다.

GUI console 사용자가 root가 아닐 수 있으므로 stage script는 이 프로젝트 전용
`/tmp/SDL12/log`만 mode 777로 만든다. source/build tree와 `/ndrv`의 권한은
변경하지 않는다.

인수 전달에 의존하지 않는 90초 전용 visual test도 제공한다:
`sdl-video-events-8`, `sdl-video-events-16`, `sdl-video-events-32`.
각 창 제목은 요청한 bpp를 표시하며, `SDLVideoEvents8.app`,
`SDLVideoEvents16.app`, `SDLVideoEvents32.app` bundle의 executable로도
준비된다.

현재 overlay `Makefile`과 test `Makefile`은 `-m486`와 post-link subtype 보정을
포함한다. 외부 SDL 응용 프로그램도 같은 두 단계를 사용해야 한다.

`/tmp/SDL12/src/build/test-openstep.csh`는 timer, 49일 wrap 산술과 cthreads의
headless 회귀를
자동으로 빌드·실행한다. video와 audio의 환경 의존 검증은 의도적으로 실행하지
않는다. 2026-08-11 최종 깨끗한 대상 빌드의 결과는 `SDL_TIMER_OK: 240
callback=1`, `SDL_TIMER_WRAP_OK: 1234`, `SDL_THREAD_OK`,
`test-openstep: timer, wrap arithmetic, and cthreads passed`였다.

### Timer callback 후속 검증

원본 SDL 1.2.15의 `include/SDL_timer.h` 및 `docs/man3/SDL_SetTimer.3`를 기준으로
`SDL_SetTimer()` callback은 반환값 `0`에서 취소되어야 하며, `SDL_SetTimer(0,
NULL)`은 명시적 취소여야 한다. 이에 맞춰 `sdl-timer`에 20 ms one-shot callback
검사를 추가했다. 이 검사는 callback이 정확히 한 번 실행되는지 확인한 뒤 명시적
취소까지 수행한다.

2026-08-11 native 실행 결과는 `SDL_TIMER_CALLBACK_BAD: 0`이다. 반면 SDL과
분리한 `setitimer-probe`는 같은 20 ms `ITIMER_REAL`/SIGALRM one-shot에서
`SETITIMER_PROBE_OK: 1`을 출력했다. 따라서 OS timer/signal이 아니라 SDL backend
또는 archive link 단계에 미해결 원인이 있었다. `SDL_INIT_TIMER` 직후 SIGALRM
handler도 `sdl-signal-probe`에서 custom으로 확인했고, native `sleep(1)` 대기에서는
`SDL_TIMER_SLEEP_OK: 1`이었다. 즉 OPENSTEP `usleep`으로 `SDL_Delay`를 구현한
경우에만 SIGALRM callback이 전달되지 않았다.

`src/timer/openstep/SDL_systimer.c`는 원본 SDL Unix backend와 같은 `select()`+
`EINTR` 재시도 방식으로 교체했다. 이 방식은 `SDL_Delay`가 signal으로 중단돼도
남은 시간을 다시 계산해 최소 요청 시간만큼 기다린다. 대상
`/NextDeveloper/Headers/bsd/libc.h`의 `select()` 및 `sys/errno.h`의 `EINTR` 선언을
확인한 뒤 적용했다. 전체 `libSDL.a` 재빌드와 test binary 강제 재링크 후 callback은
계속 통과한다. 별도로 `SDL_GetTicks.3`의 약 49일 wrap 규약을 대조해, 32비트
signed `long`에 전체 밀리초를 담던 24.8일 overflow와 tick 값 비교가 정상 wrap을
막는 문제를 제거했다. wall clock 역행은 `timeval` 단계에서만 clamp하고 Uint32
산술은 modulo wrap을 허용한다. 실제 대상에서 elapsed `2^32 + 1234` ms를 주입한
산술 시험 결과는 `SDL_TIMER_WRAP_OK: 1234`다.

### Condition timeout 후속 검증

원본 `include/SDL_mutex.h` 및 `docs/man3/SDL_CondWaitTimeout.3`는 timed wait가
signal이면 `0`, 만료면 `SDL_MUTEX_TIMEDOUT`을 반환하고 caller mutex를 다시
잠가야 한다고 정한다. cthreads의 `condition_wait()`에는 timed variant가 없으므로,
OPENSTEP backend는 SDL 1.2 원본 `src/thread/generic/SDL_syscond.c`의 semaphore
handshake 구조를 사용한다. 이는 signal과 timeout 사이의 race를 `wait_done`
handshake로 정리한다.

`sdl-threads`는 30 ms 무신호 timeout, 1000 ms timed wait의 signal wake-up,
mutex 재획득, worker join을 한 번의 target run에서 확인한다. 또한 두 worker가
waiter로 등록된 뒤 `SDL_CondBroadcast()`로 모두 깨우고 각 worker의 반환값을
검사한다. 2026-08-11 target 결과는 `SDL_THREAD_OK`이며, 같은 공식 headless run에서
`SDL_TIMER_OK: 247 callback=1`도 재통과했다. 추가로 네 worker가 공유 mutex를
각 100회 획득해 총 400회 increment하는 contention과, 모든 worker join 뒤 세 번의
`SDL_Quit`/`SDL_Init(SDL_INIT_TIMER)` lifecycle을 통과했다. 실행 중인 worker와
`SDL_Quit`를 겹치는 종료 정책은 SDL 원본도 안전성을 보장하지 않으므로 이 회귀의
범위 밖이다.

창에 RGB pattern이 표시되고, 키와 좌/우 버튼 click이 stderr에 기록되며, close가
`SDL_QUIT`를 만들어야 한다. 이 시각 검증 결과가 다음 video/events 단계의 GO
조건이다.

### `SDL_WaitEvent()` WindowServer 검증

원본 `docs/man3/SDL_WaitEvent.3`는 다음 queue event까지 대기해 성공 시 `1`을
반환한다고 정한다. OPENSTEP driver는 non-blocking AppKit event pump를 사용하므로,
이 test는 expose/active 같은 초기 창 이벤트는 계속 소비하고 key-down, mouse-down,
또는 close의 `SDL_QUIT`에서만 종료한다. GUI Terminal에서 실행한다.

```csh
/tmp/SDL12/src/test/openstep/sdl-wait-event
```

파란 창의 제목은 `SDL WaitEvent: click or press a key`다. 창을 한 번 click하거나
키를 누른 뒤 `/tmp/SDL12/log/sdl-wait-event.log`가 `SDL_WAIT_READY`, 해당 입력 행,
`SDL_WAIT_OK` 순서를 보여야 한다. 이 검증은 WindowServer 문맥이 필요하며
headless shell에서 실행하지 않는다.

2026-08-11 GUI Terminal 실기 로그는 `SDL_WAIT_READY`, 창 내부 event type `17` 두 건,
`SDL_WAIT_MOUSE: 1 199 69`, `SDL_WAIT_OK` 순서였다. 즉 초기 window event는 계속
소비하고 physical left click에서 `SDL_WaitEvent()`가 성공 반환했다. 보존한 원본 로그는
`notes/sdl-wait-event-20260811.log`다.

## WindowServer 24bpp video/events 실기 결과

2026-08-11 GUI Terminal에서 executable을 직접 실행해 24bpp AppKit 창 생성을
확인했다. WindowServer Mach port가 없는 headless 문맥에서는 Workspace
`open`이 거부되므로 GUI Terminal의 direct execution이 필요했다. event log에는
다음이 기록됐다.

- arrows: SDLKey `273`, `274`, `276`, `275` (up/down/left/right)
- F1: SDLKey `102`
- left mouse: `SDL_MOUSEBUTTON 1`와 SDL 화면 좌표
- 60초 timeout의 정상 종료: `SDL_OPENSTEP_VIDEO_DONE`

사용자가 GUI console에서 물리적 우 클릭을 했을 때도 AppKit이 left mouse event로
전달하여 `SDL_MOUSEBUTTON 1`만 기록됐다. driver에는
`rightMouseDown:` → `SDL_BUTTON_RIGHT` 구현이 있으나, 이 console input
mapping에서는 right event가 도달하지 않아 button 3 실측은 보류한다.

event matrix 실기에서는 `SDL_VIDEOEXPOSE`, `SDL_ACTIVE gain=0/1 state=0x6`,
key up/down, left button up/down, 그리고 left-drag의
`SDL_MOUSEMOTION state=0x1` 연속 좌표가 확인됐다. 일반 mouse move와 modifier는
현재 console input path에서 별도 판정이 필요하다.

key matrix 실기에서 `a`, `1`, `-`의 key up/down과 Home(278), End(279),
PageUp(280), PageDown(281), Insert(277), Delete(127), F2(283), F12(293)가
정상 SDLKey로 확인됐다. 일반 mouse move도 `SDL_MOUSEMOTION state=0x0`으로
확인됐다. SDL 1.2 key repeat은 기본 비활성이므로 Right Arrow를 길게 눌러도
한 down/up만 기록된 것은 정상이다. Caps Lock과 keypad/Num Lock은 현재 입력
장치에 없어 미검증이다.

현재 keyboard의 F3–F11도 각각 SDLKey 284–292로 순서대로 확인됐고, Pause는
SDLKey 19로 확인됐다. Pause key-up은 이 keyboard/console path에서 오지 않아
hardware/input path 특성으로 보류한다. F13–F15는 이 keyboard에 없어 미검증이다.

### SDL 원본 `testwm` 호환성 검증

Phase 6의 첫 원본 test로 pristine SDL 1.2.15의 `test/testwm.c`를 선택했다.
이 프로그램은 X11 또는 OpenGL을 요구하지 않으며 8bpp palette, window caption,
`SDL_WaitEvent()`, keyboard/mouse, active/quit event를 한 번에 사용한다. 원본
source는 수정하지 않고 `icon.bmp`만 같은 실행 directory에 둔다.

대상 빌드는 `/tmp/SDL12`에만 생성한다. 2026-08-11에 native `cc`와 i486 Mach-O
subtype 보정을 거쳐 `/tmp/SDL12/src/test/openstep/upstream-testwm/sdl-testwm`을
성공적으로 만들었다. 첫 실행에서 원본 test가 창 생성 전에 설정한 caption이 기본
title로 덮이는 것과 ASCII Escape가 `SDLK_UNKNOWN`으로 변환되는 것을 발견했다.
SDL 원본 `testwm.c`는 바꾸지 않고 backend가 retained `wm_title`을 window 생성 뒤
적용하도록 하고 control character 27을 `SDLK_ESCAPE`로 매핑해 수정했다.

```csh
/bin/csh -f /tmp/SDL12/src/test/openstep/run-upstream-testwm.csh
```

2026-08-11 GUI WindowServer 재실행에서 640x480 palette gradient와
`Testing  1.. 2.. 3...` title을 확인했다. 창 안에서 mouse button 한 번과 Escape
한 번을 눌렀고 프로그램은 자동 종료했다. Escape는 원본 test가 `SDL_USEREVENT`를
넣어 `SDL_WaitEvent()` loop를 종료하는 경로를 검증한다. 종료 뒤 target process가
남지 않은 것도 확인했다. `run-upstream-testwm.csh`의 stdout redirection log는
AppKit final teardown에서 flush되지 않아 0바이트가 될 수 있으므로, 이 test의
성공 판정은 해당 로그가 아니라 위 GUI 관찰과 process 종료로 한다. Ctrl-G(grab),
Ctrl-Z(iconify), Alt-Return(fullscreen)은 이 test의 선택 경로지만 현재 제한
capability이므로 이 첫 기준 실행에서는 누르지 않았다.

### SDL 원본 `loopwave` audio 호환성 검증

두 번째 원본 test로 pristine SDL 1.2.15의 `test/loopwave.c`를 source 수정 없이
빌드했다. 이 프로그램은 전달한 WAV를 `SDL_LoadWAV()`로 읽어 `SDL_OpenAudio()`의
callback에서 반복 재생하고, SIGINT를 받으면 `SDL_CloseAudio()`와 `SDL_Quit()`로
정리한다.

```csh
/bin/csh -f /tmp/SDL12/src/test/openstep/run-upstream-loopwave.csh
```

2026-08-11 GUI Terminal에서 44.1 kHz stereo signed-16 WAV가 정상 속도로
반복 재생됨을 청취로 확인했다. Control-C 뒤 process가 남지 않았고, target log는
`Using audio driver: openstep`을 기록했다. 따라서 native sound queue가 포트 전용
harness뿐 아니라 원본 SDL WAV-load/callback/close 호출 순서에서도 동작함을
확인했다.

### SDL 원본 `testbitmap`과 AppKit bitmap backing 검증

pristine SDL 1.2.15 `test/testbitmap.c`를 source 수정 없이 원본이 제공하는
`-bpp 8` option으로 실행했다. 이 test는 compiled-in `picture.xbm`을 1-bit
software surface로 만들고, mouse click 위치에 `SDL_BlitSurface()`와
`SDL_UpdateRects()`로 표시한다. 2026-08-11 GUI 실기에서 gradient 창 표시와
Escape 종료는 정상이었다. 처음에는 image가 click의 상하 반대쪽에 나타났다.

SDL event 좌표와 AppKit bitmap을 분리한 probe에서 상단 click은 `raw y=473`에서
flipped view `y=16`, 하단 click은 `raw y=38`에서 view `y=451`로 확인됐다. 따라서
mouse event가 아니라 `NSBitmapImageRep` backing row가 원인이었다. caller buffer
첫 16행을 빨강, 마지막 16행을 파랑으로 한 AppKit/DPS probe는 빨강이 화면 아래,
파랑이 위에 나타남을 보였다. presenter가 SDL top-down row를 target bitmap의
`height - 1 - y` row로 반전하도록 보정한 뒤, XBM은 상단 click 위치에 남았다.
가림/재노출에도 red/blue probe가 변하지 않았다. raw hardware framebuffer가 아닌
AppKit/DPS caller-owned bitmap path가 이 포트의 검증된 display 경계다.

### SDL 원본 `graywin` partial update와 native cursor 검증

pristine SDL 1.2.15 `test/graywin.c`를 source 수정 없이 8bpp windowed mode로
실행했다. 이 test는 palette gradient를 만든 뒤 mouse-down 좌표를 중심으로 임의
크기·명도의 사각형을 `SDL_FillRect()`/`SDL_UpdateRects()`로 갱신한다.

```csh
/bin/csh -f /tmp/SDL12/src/test/openstep/run-upstream-graywin.csh
```

초기 backend는 `SDL_UpdateRects()`의 `[view display]`에서도 `drawRect:`가
`SDL_VIDEOEXPOSE`를 발생시켜, 원본 test의 expose handler가 배경을 다시 그리는
재진입 loop를 만들었다. internal present 동안 expose 생성을 억제해 사각형이 계속
유지되며 외부 가림/재노출은 정상 복원하도록 구분했다.

cursor callback이 없을 때에는 SDL software cursor가 surface에 찍히는 동시에
OPENSTEP OS cursor도 표시되어 클릭 사각형에 화살표 잔상이 남았다. NeXT 개발 문서의
Window Server cursor와 `resetCursorRects` 권고, OpenStep conversion 문서의
`NSCursor`/`NSView` API를 기준으로 native `WMcursor`를 구현했다. custom monochrome
cursor는 16x16 RGBA `NSImage`로 변환하고 `NSCursor`로 설정하며, 숨김에는 투명
native cursor를 쓴다. 이 경로는 Quartz/CoreGraphics에 의존하지 않는다. visible
default cursor는 이 test에서 통과했으며, `SDL_ShowCursor()` hide/show 전환은 별도
cursor 회귀 검사에서 확인한다.

구현 검증 중 `getBitmapDataPlanes:`에 1개 포인터 slot만 전달해 시작 즉시
`Bus error`/exit 138이 발생했다. API가 기록할 수 있는 5개 plane slot을 제공한 뒤
SIGBUS가 사라졌다. display presenter와 달리 cursor `NSImage` 행을 반전하면 OS
cursor 자체가 상하 반전됐으므로 SDL cursor 행 순서를 그대로 유지한다.

2026-08-11 GUI 실기에서 gradient, 여러 click 사각형 유지, cursor 잔상 없음,
cursor 상하 방향, Escape 종료를 모두 확인했다. 최종 target log는
`Screen is in windowed mode`만 기록했고 `FREED(id)`, SIGBUS, 잔류 process가 없다.
사용자 close와 SDL shutdown을 구분해 `NSWindow`/content-view를 중복 release하지
않는 종료 경로도 이 과정에서 통과했다.

Shift/Ctrl/Alt/Command 조합은 문자 변화는 보였으나 모든 `mod`가 0이었다.
원본 OPENSTEP `NSEvent.h`의 `modifierFlags`/`NSFlagsChanged` 규약에 맞춰
driver는 처리하지만, 이 console input path가 modifier flag를 event에 싣지 않는
것으로 관측됐다. physical modifier 전달 환경에서 재검증 전까지 modifier runtime
지원은 보류한다.

같은 console에서 `sdl-video-events-8`을 실행해 8bpp palette와 RGB gradient가
정상 표시됨을 사용자 시각 확인으로 통과했다. `sdl-video-events-16`도 정상 표시와
실행 유지가 확인됐다. `sdl-video-events-32`도 정상 표시와 실행 유지를 확인했다.
32bpp 창을 다른 창으로 가렸다가 다시 노출해도 RGB gradient가 손상 없이 복원됐다.
따라서 8/16/24/32bpp software surface의 최초 표시와 redraw(가림/노출) 검증은
통과했다.

2026-08-11 GUI WindowServer 실기에서 `sdl-av-stress`를 300초 실행했다. 음악은
정상 음정으로 재생됐고, 창을 움직이거나 다른 창으로 가렸다 다시 보이게 해도
음 끊김이나 화면 이상 없이 자연 종료했다. 기존 harness는 `SDL_Quit()` 뒤에 결과를
기록해 AppKit 최종 window 종료 때 `SDL_AV_OK`가 남지 않았지만, 30초마다 270초까지
callback/byte progress가 270초까지 증가한 것을 log로 확인했다.

결과 기록 순서를 보정한 harness를 같은 GUI session에서 30초 다시 실행해
`SDL_AV_OK: callbacks=120 bytes=5292000 elapsed=31026 exposes=1494 active=0`를
확인했다. 따라서 300초 runtime 관찰과 30초 clean audio drain 뒤 종료 기록이 모두
통과했다. 이는 `NXPlayStream` 경로 대신 native C Sound API FCFS queue를 선택한
뒤의 통과 기록이다.

### 최종 호환성 프로그램 빌드

pristine SDL 1.2.15의 `test/testcursor.c`를 수정 없이 빌드했다. OPENSTEP
`NSCursor` 문서가 16x16보다 큰 image는 16x16만 표시한다고 정하므로 backend는
16x16 이하를 native cursor로 만들고, 더 큰 cursor는 원본 SDL의 크기 보존 software
fallback에 맡긴다. `testcursor`의 16x16, 32x32, 8x11 순환으로 두 경로를 함께
확인한다.

외부 프로그램은 `sdl-docs` 저장소의 고정 commit
`3cfbd844de2b32f48aaabe17f3c4f647e1646e0f`에서 core SDL만 사용하는
`stars-1.0`, `xflame-1.0`, `plasma-1.0`을 원본 그대로 보관했다. 정확한 경로,
SHA-256과 라이선스는 각 `external/*/SOURCE.md`에 기록한다. 모두 OPENSTEP `cc`로
빌드되고 i486 subtype 보정까지 통과했다. 최종 runtime acceptance에는 unrelated
event를 명시적으로 무시하고 key/quit에서만 끝나는 `stars`와 `xflame`을 쓴다.
`plasma` 원본은 mouse/active 외의 아무 event에서 끝나므로 정상적인 최초
`SDL_VIDEOEXPOSE`만으로 종료될 수 있어 build probe로만 보존한다. `otool -L` 결과는
AppKit, Foundation, SoundKit, System뿐이며 X11 의존성이 없다. 원본 소스 자체의
implicit-int와 system `libm.a` external-relocation 경고는 보존하며 포트 코드
경고와 구분한다.

## 최종 WindowServer 묶음 검증 (통과)

최신 깨끗한 `/tmp/SDL12` tree에서 아래 명령으로 7개 프로그램을 순서대로
실행했다. headless shell에서는 WindowServer에 연결할 수 없으므로 GUI
Terminal에서 수행했다.

```csh
/bin/csh -f /ndrv/openstep-sdl12/test/openstep/run-final-gui-tests.csh
```

검증 순서는 다음과 같다.

1. dirty rect: 처음 5초에는 좌상단 빨강만 보이고 우하단은 배경색이어야 한다.
   다음 5초에는 우하단 초록이 추가되어야 한다.
2. cursor visibility: custom visible → hidden → custom restored → default restored의
   네 단계에서 잔상·이중 cursor·상하 반전이 없어야 한다.
3. warp: OS pointer가 upper-left → upper-right → lower-center의 세 square 중심으로
   자동 이동하고 상하 mirror가 없어야 한다.
4. resize: 창을 서로 다른 크기로 두 번 바꾼다. 매번 파랑 상단 띠, 빨강 하단 띠와
   중앙 marker가 새 크기에 맞게 다시 나타나면 Escape를 누른다.
5. 원본 `testcursor`: 창 안을 세 번 click해 16x16 native, 32x32 SDL software,
   8x11 native cursor를 순환한다. 크기·방향·잔상이 정상이라면 Escape를 누른다.
6. `stars`: animation과 입력 반응을 확인한 뒤 아무 키나 눌러 종료한다.
7. `xflame`: 작은 8bpp flame animation의 색상과 여러 partial update가 계속
   움직이는지 확인한 뒤 아무 키나 눌러 종료한다.

2026-08-11 WindowServer 실행에서 7단계가 모두 끝까지 진행됐다. 사용자는 dirty
rect의 단계적 표시, 네 cursor visibility 단계, mirror 없는 warp, resize 뒤 파랑
상단/빨강 하단/초록 중앙 pattern, 원본 `testcursor`의 세 cursor, stars와 XFlame
animation을 모두 정상으로 판정했다. 자동 로그는 `SDL_DIRTYRECT_OK`,
`SDL_CURSOR_OK`, 세 requested/state 좌표가 같은 `SDL_WARP_OK`, 서로 다른 resize
3회의 `SDL_RESIZE_OK: count=3`을 기록했다. `stars`는 19.71 fps와 정상 종료를
기록했다. 원본 `testcursor`와 XFlame은 AppKit teardown 뒤 redirected stdout가
0바이트였지만 runner가 다음 단계/끝까지 진행했으므로 exit status는 0이며 시각
판정도 통과했다. 전체 transcript는 `notes/final-gui-20260811.log`에 보존한다.

갱신된 runner는 이후 재실행부터 각 단계의 PASS/FAIL과 마지막
`SDL12_FINAL_GUI_SEQUENCE_OK`를 `/tmp/SDL12/log/final-gui-sequence.log`에도 남긴다.
각 프로그램의 stdout/stderr는 같은 log directory에 있으므로 사용자가 직접
`cat`할 필요가 없다.
