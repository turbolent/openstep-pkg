# SDL 1.2 for OPENSTEP

This project is a native SDL 1.2.15 port for OPENSTEP 4.2 on Intel i386.
It uses Application Kit, Display PostScript, SoundKit, BSD system services,
and Mach cthreads directly. It does **not** use X11, Xlib, an X server, Quartz,
or a modern Cocoa compatibility layer.

Status: **the native backend and the final OPENSTEP hardware acceptance suite
passed on 2026-08-11.**

The pristine SDL 1.2.15 source is retained under `upstream/SDL-1.2.15/`.
OPENSTEP code is maintained as a separate overlay under `port/openstep/`,
with small bootstrap patches kept for review and redistribution.

## OPENSTEP-specific features

| SDL subsystem | Native OPENSTEP implementation |
|---|---|
| Video | Windowed software surfaces in 8, 16, 24, or 32 bpp, converted to a 24-bit `NSBitmapImageRep` and displayed by an AppKit `NSView` |
| Presentation | `SDL_Flip()` and clipped `SDL_UpdateRect(s)` through `-[NSView displayRect:]` |
| Resize | `SDL_RESIZABLE`, `NSResizableWindowMask`, and `windowDidResize:` translated to `SDL_VIDEORESIZE` |
| Events | AppKit `NSEvent` translation for keyboard, mouse, focus, expose, and window close |
| Cursor | Native `NSCursor` for cursors up to 16x16; larger SDL cursors retain SDL's software fallback |
| Mouse warp | Display PostScript `PSsetmouse` in the flipped SDL view coordinate system |
| Audio | SoundKit `SNDStartPlaying(..., preempt=0)` FCFS queue with retained 0.25-second PCM blocks |
| Timer | BSD `gettimeofday`, `select`, `signal`, and `setitimer`, including SDL's documented approximately 49-day `Uint32` wrap |
| Threads | Mach cthreads implementation of SDL threads, recursive mutexes, semaphores, and condition variables |

### Display PostScript details

SDL surfaces use a top-left origin. The OPENSTEP `NSBitmapImageRep` backing
store was verified on the target to store its first row at the lower edge.
The presenter therefore reverses bitmap rows exactly once while preserving
SDL coordinates for events and dirty rectangles. Cursor image rows are not
reversed; doing so would invert the Window Server cursor itself.

No raw framebuffer access is used. Redraw, exposure, and clipping remain
inside the supported AppKit/Display PostScript path.

### Native cursor behavior

The OPENSTEP cursor documentation limits the displayed native cursor image to
16x16 pixels. Smaller SDL cursors are padded to 16x16 and use `NSCursor`.
Larger cursors deliberately return to SDL's size-preserving software cursor
path. Cursor hiding uses a transparent native cursor, preventing the native
and software cursor from being drawn simultaneously.

### Native audio behavior

The audio driver accepts these target formats:

- 22050 or 44100 Hz
- mono or stereo
- signed 16-bit PCM, little- or big-endian at the SDL boundary

SoundKit consumes big-endian `SND_FORMAT_LINEAR_16`, so little-endian samples
are byte-swapped before submission. Four chunks are normally kept queued and
the oldest tag is reclaimed with `SNDWait()`. This avoids the audible gaps
caused by starting and waiting for each chunk serially. The SDL audio callback
only fills its mix buffer; SoundKit buffer lifetime is managed afterward by
the backend.

## Target and toolchain

- OS: OPENSTEP 4.2
- CPU: Intel i386/i486-compatible target
- Compiler: NeXT `cc-744.13`, based on GCC 2.7.2.1
- Language baseline: C89 and the historical NeXT Objective-C runtime
- Output: static `libSDL.a`

The compiler emits an i586 Mach-O subtype even when `-m486` is used. OPENSTEP
on the target machine rejects that subtype, so every linked executable is
processed by `fix-macho-i486-subtype.csh`. The helper changes only the
Mach-O CPU subtype from 5 to 4 after a successful `-m486` link.

## Building on OPENSTEP

The NFS source is mounted at `/ndrv/openstep-sdl12`. Treat that directory as
read-only: the export may use NFS root-squash, including when logged into
OPENSTEP as root.

All target-side source copies, objects, binaries, and logs belong under the
project-specific `/tmp/SDL12` tree.

```csh
# Run in an OPENSTEP shell.
/ndrv/openstep-sdl12/build/stage-openstep.csh
/bin/csh -f /tmp/SDL12/src/build/prepare-openstep-tree.csh

cd /tmp/SDL12/build/SDL-1.2.15-openstep
make

cd /tmp/SDL12/src/test/openstep
make

/bin/csh -f /tmp/SDL12/src/build/test-openstep.csh
```

The stage script deletes and recreates only `/tmp/SDL12/src`. It never writes
below `/ndrv/openstep-sdl12` and does not share a temporary directory with
other OPENSTEP projects.

GUI applications must be run from a WindowServer GUI Terminal. A headless
remote shell is suitable for builds and timer/thread tests, but it has no
WindowServer connection. Site-specific remote access procedures are not part
of this source package.

## Linking an SDL application

A minimal native link uses the static SDL library and the three OPENSTEP
frameworks:

```csh
set SDLROOT = /tmp/SDL12/build/SDL-1.2.15-openstep

cc -m486 -O -I${SDLROOT}/include -o my-sdl-app my-sdl-app.c \
    ${SDLROOT}/libSDL.a \
    -framework AppKit -framework Foundation -framework SoundKit

/bin/csh -f ${SDLROOT}/fix-macho-i486-subtype.csh my-sdl-app
```

The resulting program uses the `openstep` video and audio drivers. No X11
include path or library should be added.

## Verified on real OPENSTEP hardware

The following paths were built and exercised on the target:

- 8/16/24/32-bit software surfaces, palettes, dirty rectangles, expose, and resize
- key down/up, function and navigation keys, mouse motion/drag/button, focus, and quit
- native cursor show/hide, custom cursors, software fallback, and DPS mouse warp
- SDL audio load/callback/pause/resume/close
- 300-second audio-only playback and 300-second simultaneous audio/video stress
- timer callback, interrupted delay, monotonic clock handling, and 49-day wrap arithmetic
- thread creation/join, recursive mutexes, semaphores, condition timeout/signal/broadcast, and contention
- pristine SDL tests: `testwm`, `loopwave`, `testbitmap`, `graywin`, and `testcursor`
- unmodified external SDL programs: `stars-1.0` and `xflame-1.0`

The seven-stage final WindowServer suite passed, including partial display,
cursor direction and residue, resize patterns, palette animation, and clean
input-driven exits.

Re-run it from a GUI Terminal with:

```csh
/bin/csh -f /ndrv/openstep-sdl12/test/openstep/run-final-gui-tests.csh
```

Detailed commands, measured results, and known hardware-input coverage limits
are in [TESTING.md](TESTING.md). The final evidence transcript is in
[notes/final-gui-20260811.log](notes/final-gui-20260811.log).

## Supported scope and limitations

This is a native software SDL 1.2 backend. It intentionally does not advertise
features that were not implemented or verified.

Supported:

- windowed software video
- 8/16/24/32-bit SDL surfaces and 8-bit software palettes
- dirty updates, expose redraw, resize, and window captions
- absolute keyboard and mouse input
- native cursor visibility and absolute mouse warp
- SoundKit PCM playback
- SDL timer and thread APIs used by SDL 1.2 applications

Not supported:

- X11 or X11 compatibility layers
- OpenGL
- exclusive fullscreen
- hardware surfaces or accelerated blits
- mouse grab and relative mouse mode
- CD-ROM and joystick backends
- dynamic library loading

Some physical keys could not be covered by the available keyboard: F13-F15,
keypad/Num Lock, and Caps Lock. The console input path also did not expose a
distinct physical right-button or modifier flag in every session. The backend
contains the documented AppKit translations, but these hardware paths remain
explicit coverage limitations.

## Repository layout

```text
openstep-sdl12/
|-- upstream/                 pristine SDL 1.2.15 source and source record
|-- port/openstep/            native backend, build overlay, and patches
|-- build/                    staging, preparation, test, and package scripts
|-- test/openstep/            target regression programs and runners
|-- external/                 third-party SDL compatibility programs
|-- spikes/                   isolated OPENSTEP API probes
|-- notes/                    API inventory and preserved target evidence
|-- dist/                     reproducible source archive and SHA-256 sidecar
|-- PLAN_SDL12.md             implementation plan and completed phase gates
|-- TESTING.md                detailed verification record
|-- COPYING                   LGPL 2.1 notice pointer
`-- NOTICE                    modification and third-party notices
```

## Source archive

The verified source archive is attached to the GitHub release as
`openstep-sdl12-20260811-src.tar.gz`, with its SHA-256 sidecar. It expands to a
single `openstep-sdl12/` directory and needs no other download to build.

To reproduce it on the Linux host:

```sh
# Defaults to /tmp; the argument is the output file path, not a directory.
./openstep-sdl12/build/package-source.sh
./openstep-sdl12/build/package-source.sh dist/openstep-sdl12-20260811-src.tar.gz
```

The archive and this repository carry the same file set, so a clone and an
unpacked archive build identically. Test MP3/WAV media, target build products,
and the local `dist/` directory are excluded from both.

## License and provenance

SDL 1.2.15 and this OPENSTEP backend are distributed under the GNU Lesser
General Public License 2.1. The complete license text is retained at
`upstream/SDL-1.2.15/COPYING`; see [COPYING](COPYING) and [NOTICE](NOTICE).

Upstream files are carried unmodified, but not all of them are carried. The
tree holds what this port builds from -- `include/`, `src/`, `test/`,
`configure`, `Makefile.minimal` -- plus `COPYING`, `CREDITS`, and `README`. The
other-platform IDE projects (VisualC, VisualCE, Xcode), the autotools helpers,
and the HTML manual are left out; nothing here builds from them. The pristine
release URL and SHA-256 for the complete archive are recorded in
[upstream/SDL-1.2.15.SOURCE.md](upstream/SDL-1.2.15.SOURCE.md).
Each program under `external/` retains its own license statement and an exact
commit/path/hash record in its `SOURCE.md`.
