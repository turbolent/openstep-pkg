# OPENSTEP audio test assets

This directory is deliberately limited to locally generated test media.  The
WAV made from the user-provided MP3 is ignored by Git and is staged to the
private `/tmp/SDL12` tree only for SoundKit playback verification.

Expected local test files:

`hiyuki-openstep-44100-s16.wav` — RIFF/WAVE, 44,100 Hz, stereo, signed
16-bit little-endian PCM.  This is the complete conversion, retained locally.

`hiyuki-openstep-test-15s-44100-s16.wav` — the first 15 seconds in the same
format.  Only this small sample is copied directly to `/tmp/SDL12/audio/` on
the target after source staging, avoiding a temporary-disk spike from putting
the 43 MB full WAV into an old tar archive.

`hiyuki-openstep-test-15s-44100-s16.snd` — the same test excerpt in NeXT
`.snd` form (44.1 kHz, stereo, linear 16-bit big-endian).  It is only for the
legacy C Sound API diagnostic; SDL itself loads the WAV file.

The 15-second WAV and SND paths passed native playback. The short WAV was also
looped by the SDL callback path for the 300-second audio-only and combined
audio/video stress runs without audible corruption or interruption. All
`*.wav` and `*.snd` files remain Git-ignored and are excluded from the source
package.
