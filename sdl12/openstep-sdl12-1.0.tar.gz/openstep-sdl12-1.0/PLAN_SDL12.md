# OPENSTEP용 SDL 1.2 네이티브 포트 작업계획

작성: 2026-08-10  
상태: **완료 — native backend, 원본/외부 프로그램, 최종 WindowServer 검증 통과**

## 1. 목표와 성공 기준

SDL 1.2를 OPENSTEP 4.2에서 X11을 거치지 않고 실행한다. 게임/응용 프로그램은
표준 SDL 1.2 API만 호출하고, 포트 계층이 OPENSTEP의 AppKit, DPS, Sound Kit,
Mach/BSD 서비스를 사용한다.

완료판의 최소 성공 기준은 다음과 같다.

- X11 헤더·라이브러리·서버에 빌드/실행 의존성이 없다.
- `SDL_SetVideoMode()`로 만든 소프트웨어 화면이 AppKit 창에 정확히 표시되고
  `SDL_Flip()`/`SDL_UpdateRect()`가 손상 영역만 갱신한다.
- 키보드·마우스·창 닫기·활성화 이벤트가 SDL 이벤트 큐로 전달된다.
- SDL 오디오 callback이 SoundKit 재생 queue에 지속 공급되며 callback/bytes/time
  진행량과 queue API 오류를 계측할 수 있다.
- `SDL_Delay`, `SDL_GetTicks`, mutex/condition/thread가 단일 검증 프로그램과
  실제 SDL 예제로 동작한다.
- 실기에서 최소 두 개의 SDL 1.2 프로그램(비디오/입력 하나, 오디오 포함 하나)을
  빌드·실행하고, 결과와 제한을 `TESTING.md`에 남긴다.

## 2. 목표 구조

```
SDL 1.2 core
 ├─ video     src/video/openstep/       AppKit NSWindow/NSView + DPS presenter
 ├─ events    src/video/openstep/       NSEvent → SDL_Event translator
 ├─ keyboard  video/events backend      AppKit key event / modifier state
 ├─ mouse     video/events backend      AppKit pointer event / cursor / grab
 ├─ audio     src/audio/openstep/       SoundKit / native Sound API queue
 ├─ timer     src/timer/openstep/       BSD monotonic-like clock + sleep
 └─ threads   src/thread/openstep/      Mach cthreads implementation
```

`src/video/openstep/`은 SDL의 기존 플랫폼 드라이버와 같은 내부 인터페이스
(`VideoBootStrap`, `SDL_VideoDevice`)를 구현한다. Objective-C 객체는 앱/창/뷰와
이벤트 수신에만 한정하고, SDL에 노출되는 ABI와 surface/blit 경로는 C로 유지한다.

### 2.1 서브시스템별 설계 방침

| SDL 영역 | OPENSTEP 구현 | 최종 지원 범위 | 확인한 핵심 항목 |
|---|---|---|---|
| video | `NSApplication` + 전용 `NSWindow`/`NSView`, DPS로 software surface 복사 | 창 모드, RGB software surface, dirty rect | 픽셀 포맷/stride/좌표 원점, draw cycle 내 DPS flush 순서 |
| events | AppKit event loop에서 `NSEvent` 변환 | quit, active, expose, key, mouse, wheel(존재 시) | SDL loop와 AppKit run loop의 공존, autorelease/객체 수명 |
| keyboard/mouse | `NSEvent` key/mouse, AppKit cursor API | 일반 키, modifier, button, motion, cursor 표시/숨김 | 가상키→SDLKey 표, dead key/IME, grab 및 상대 좌표 가능 여부 |
| audio | native `SNDStartPlaying(..., preempt=0)` FCFS queue | PCM callback, pause/close, bounded queue | 22050/44100 Hz, mono/stereo, signed 16-bit PCM, 지속 재생 |
| timer | BSD `gettimeofday`/`select`/`setitimer` | 32-bit `SDL_GetTicks`, delay, callback | 벽시계 역행 clamp, 약 49일 wraparound, `EINTR` 재시도 |
| threads | Mach `cthreads.h` | thread, mutex, cond, semaphore | SDL의 recursive mutex/condition timeout 의미, 종료/취소 안전성 |

### 2.2 실기 작업 트리 분리

실기의 NFS mount `/ndrv/openstep-sdl12`은 호스트에서 관리하는 **읽기 기준 원본**이다.
NFS export의 root-squash 가능성 때문에 OPENSTEP root도 이 tree에 쓸 수 있다고
가정하지 않는다. OPENSTEP 안의 빌드·실행 작업은 전용 디렉터리
**`/tmp/SDL12`**에서만 수행한다.

```
/ndrv/openstep-sdl12/       호스트 편집 원본 (NFS, 다른 프로젝트와 공존)
/tmp/SDL12/src/             이 프로젝트만의 staged source와 source-local GUI test
/tmp/SDL12/build/           configure 산출물·object·library
/tmp/SDL12/bin/             headless regression·AppKit bundle 실행 파일
/tmp/SDL12/log/             실기 측 임시 로그
```

각 단계 시작 전 `/ndrv/openstep-sdl12/build/stage-openstep.csh`를 실행해
`/tmp/SDL12/{src,build,bin,log}`만 만든다. 스크립트는 tar stream으로 NFS를
읽고 `/tmp`에만 쓴다. 다른 프로젝트의 `/tmp` 경로, 공유 NFS 원본 또는 `/tmp`
전체를 정리 대상으로 사용하지 않는다. 보존할 결과는 실기에서 NFS로
다시 쓰지 않고 호스트의 사이트 전용 회수 경로를 사용한다.

## 3. 핵심 설계 결정

### 3.1 비디오는 처음부터 software surface만

`SDL_SetVideoMode()`는 앱 창과 화면 surface를 만든다. SDL이 화면 메모리에
그린 뒤 `SDL_Flip()` 또는 `SDL_UpdateRects()`를 호출하면, 백엔드는 변경
직사각형만 presenter buffer로 변환하고 각 rect를 `displayRect:`로 즉시 clip
redraw한다. 이 방식은 X11·OpenGL·전용 framebuffer 접근을 배제하면서 SDL 1.2의
가장 널리 쓰이는 2D 경로를 먼저 확보한다.

`SDL_HWSURFACE`, hardware palette, gamma, OpenGL은 capability로 광고하지 않는다.
fullscreen/OpenGL은 명시적으로 실패하고, hardware surface 요청은 SDL 1.2의
software surface로 폴백한다. `SDL_DOUBLEBUF`는 별도 hardware buffer가 아니며
software screen의 `SDL_Flip()` 표시 규약으로만 동작한다.

### 3.2 AppKit run loop가 주 루프를 소유한다

OPENSTEP 앱은 `NSApplication`의 이벤트 전달·화면 갱신 규약을 따라야 한다.
따라서 별도 X식 이벤트 thread를 만들지 않는다. `SDL_PumpEvents()`가 non-blocking
방식으로 AppKit의 pending event를 꺼내 SDL 큐에 번역한다. `SDL_WaitEvent()`는
초기 expose/active event를 계속 pump하면서 입력 또는 quit event를 기다리는 경로로
실기 검증했다.

SDL main loop가 아직 AppKit application을 만들지 않은 경우에는 포트가 한 번만
초기화한다. 이미 AppKit 앱 안에 SDL을 임베드하는 경우는 초기판의 비보장 항목으로
문서화하고, 독립 SDL 앱이 안정된 뒤에 지원 여부를 정한다.

### 3.3 입력 변환 규칙

- `keyDown:`/`keyUp:`의 키 코드와 modifier flag를 SDL 1.2 `SDL_keysym`으로
  변환한다. 문자 문자열이 아닌 물리/가상 키 기준 매핑 표를 소스와 문서에 둔다.
- 마우스 좌표는 SDL 화면 좌표(좌상단 원점)로 정규화한다. NSView/DPS 좌표계와의
  y축 반전은 변환 함수 한 곳에 고정한다.
- AppKit의 창 이동/resize/expose/activate/deactivate/close를 각각 SDL window
  이벤트 또는 SDL 1.2에서 가능한 `SDL_ACTIVEEVENT`/`SDL_QUIT`로 매핑한다.
- cursor 표시/숨김은 native `NSCursor`, warp은 Display PostScript `PSsetmouse`로
  구현한다. 마우스 grab과 상대 모드는 지원하지 않는 capability로 명시하고,
  `SDL_GrabInput(SDL_GRAB_ON)`은 안전하게 오류/`SDL_GRAB_OFF`를 반환한다.

### 3.4 오디오: native SoundKit C API queue

`NXPlayStream`은 i486 PCM byte order와 단일 buffer 재사용 문제로 GUI에서
잡음·underrun을 냈다. 따라서 모든 문맥에서 `openstep-mp3player` 실기 이력으로
검증한 native `SNDStartPlaying(..., preempt=0)` FCFS queue를 사용한다. audio
callback은 하나의 SDL mix buffer만 채우며 할당하지 않는다. `PlayAudio` 단계가
0.25초 PCM block의 수명을 별도로 보존하고 4개를 먼저 enqueue한 뒤 가장 오래된
tag만 `SNDWait()`으로 회수·해제한다. queue bookkeeping은 최대 8개로 제한한다.
block마다 play/wait를 직렬화하면 DAC gap이 생기므로
금지한다. 16-bit SDL little-endian PCM은 NeXT `SND_FORMAT_LINEAR_16`
big-endian으로 변환한다.

### 3.5 타이머와 스레드의 이식 경계

SDL의 공개 API 의미를 보존하고 구현은 플랫폼 파일에 고립한다. 대상에서
이용 가능한 `gettimeofday()`를 쓰되, 벽시계 역행은 `timeval` 단계에서
마지막 값으로 clamp한다. 공개 tick은 `Uint32` modulo 산술을 유지해 SDL이
문서화한 약 49일 wrap을 허용한다. thread/mutex/condition/semaphore는
OPENSTEP에서 확인한 Mach cthreads로 구현했다.

## 4. 단계별 계획과 GO/NO-GO 관문

### Phase 0 — 소스·SDK 인벤토리 및 최소 AppKit 스파이크 (완료)

목적: 포트의 전제와 정확한 SDK 호출을 실기에서 확정했다.

- 확보한 SDL 1.2.15 pristine 원본의 버전·SHA-256·라이선스·디렉터리 상태를
  확인한다. 라이선스가 다른 SDL 2/SDL 1.3 코드는 섞지 않는다.
- OPENSTEP의 AppKit/DPS 헤더·예제에서 application 생성, event polling,
  NSView drawing, resize/close, cursor API를 추출해 `notes/api-inventory.md`에
  헤더 경로와 짧은 예제로 기록한다.
- `spikes/appkit-window`를 만든다: NSApplication + 창 + view를 띄우고 C 메모리의
  RGB pattern을 DPS로 표시한다. expose/resize 뒤에도 갱신되는지 확인한다.
- event dump는 별도 스파이크 대신 `appkit-window`와 이후
  `test/openstep/sdl-video-events`, `sdl-wait-event`에서 좌표·key·mouse·close·active를
  수집했다.
- audio API는 `sound-api-play`, `sdl-wav-audio`, `sdl-audio-loop`로 native
  `SNDStartPlaying` queue와 SDL callback 경로를 분리 검증했다.
- timer/thread API는 `sdl-timer`, `sdl-timer-wrap`, `sdl-threads`로
  BSD timer와 Mach cthreads를 대상에서 검증했다.
- spike는 staged source 디렉터리에서, headless regression과 AppKit bundle은
  `/tmp/SDL12/bin`에서 실행했다. 결과는 `/tmp/SDL12/log`에 남기고
  보존할 증거만 호스트의 `notes/`로 복사했다.

**결과:** 창 redraw, 이벤트, native PCM 출력, thread/timer를 실기에서
모두 확인해 GO를 통과했다. DPS presenter는 caller-owned bitmap의 bottom-up
backing을 적용했고, 오디오는 문제가 있던 `NXPlayStream` 대신 native SoundKit
FCFS queue로 확정했다.

### Phase 1 — 빌드 기반과 공통 플랫폼 골격 (완료)

- SDL configure/build 체인을 OPENSTEP `cc`에 맞춘다. configure가 구형 shell/tool에
  맞지 않으면 결과 config header와 플랫폼 makefile을 최소 패치로 관리한다.
- `src/{video,audio,timer,thread}/openstep/` 및 `test/openstep/` 골격을 추가하고
  event translator는 AppKit view와 함께 `src/video/openstep/`에 둔다. SDL의
  bootstrap 등록, `SDL_config_openstep.h`, 링크 라이브러리를 정한다.
- configure·make는 `/tmp/SDL12/build`에서 수행한다. `/ndrv/openstep-sdl12`과
  `/tmp/SDL12/src`를 각각 다른 프로젝트의 source/build tree로 겸용하지 않는다.
- C89 검사: `//` 주석, C99 선언/정수형, 모던 libc 의존을 포트 코드에서 피한다.
- `SDL_Init`/`SDL_Quit`, timer, threads의 headless regression을 만든다.

**산출물:** 실기에서 정적 `libSDL.a`와 `sdl-timer`, `sdl-timer-wrap`,
`sdl-threads`가 빌드·실행·종료했다.

### Phase 2 — video + 기본 events (완료)

- OPENSTEP video driver를 등록하고 `SDL_ListModes`, `SDL_SetVideoMode`,
  `SDL_SetColors`(필요 시), `SDL_UpdateRects`, `SDL_Flip`, `SDL_VideoQuit`를 구현한다.
- NSWindow/NSView 수명과 SDL surface pixels의 소유권을 분리한다. AppKit drawing은
  SDL lock 또는 snapshot 규약 안에서만 pixels를 읽는다.
- key/mouse motion/button, quit, active, expose를 SDL event로 변환한다.
- 고정 색상 패턴, dirty rectangle, 키/마우스 표시 프로그램을 만들고 8/16/24/32-bit
  요청별 지원·거절 동작을 기록한다.

**GO 결과:** 창 가림/노출·resize 반복에도 크래시·깨짐 없이 redraw되고,
기본 입력과 종료가 동작했다.  
**산출물:** `test/openstep/sdl-video-events.c` 및 bpp별 executable/bundle.

### Phase 3 — 키보드·마우스 호환성 완성 (완료, hardware coverage 제한 기록)

- OPENSTEP key code→`SDLKey` 매핑 표를 작성하고 영문/숫자/기호/화살표/F키/keypad,
  Shift/Ctrl/Alt/Command/Caps Lock 조합을 검증한다.
- repeat, focus 전환 시 key-up 정리, text/unicode 지원 여부를 SDL 1.2 규약과 대조한다.
- cursor visibility, warp, grab, relative motion을 각각 capability test로 판단한다.
- 지원하지 못하는 기능은 잘못된 이벤트를 만들지 말고 문서화된 폴백으로 제한한다.

**산출물:** 자동화 가능한 event transcript 검사와 수동 키보드 매트릭스 결과.

**실기 결과 (2026-08-11):** 일반 key, 화살표, Home/End, PageUp/PageDown,
Insert/Delete, F1–F12, Pause, key up/down, motion/drag, left button, focus를 통과했다.
F13–F15, keypad/Num/Caps은 물리 keyboard에 없었고, right/modifier event의 일부는
console input path가 별도 flag/button으로 전달하지 않아 hardware coverage 제한으로
남겼다. cursor visibility, 16x16 이하 native cursor, 큰 software cursor fallback,
DPS warp는 최종 WindowServer 검증을 통과했다.

### Phase 4 — audio backend (완료)

- `SDL_AudioSpec`과 확인된 장치 포맷을 협상하고, 필요 시 sample format/rate/channel
  변환 위치를 정한다.
- SDL callback은 고정 mix buffer만 채우고 할당·UI 호출·blocking SoundKit
  호출을 하지 않는다. `PlayAudio`가 0.25초 PCM block을 별도로 보존하고
  4개를 선행 enqueue하며 bookkeeping은 최대 8개로 제한한다.
- open/pause/close, silence, callback/bytes/time progress, queue API 오류 처리를
  구현한다. SoundKit API가 별도 hardware underrun counter를 제공하지 않는
  제한은 문서화한다.
- 최소 5분 loop 재생과 동시에 video/events 부하를 주는 검증 프로그램을 실행한다.

**GO 결과:** queue API 오류 없이 callback/bytes/time이 지속 증가했고,
일반 video/event 부하에서 청감상 끊김 없이 종료·재시작됐다.  
**산출물:** `test/openstep/sdl-audio-loop.c`와 포맷/지속성 측정 결과.

**실기 결과 (2026-08-11):** native FCFS queue로 44.1 kHz stereo signed-16 WAV를
GUI video 동시 부하 300초와 audio-only 300초에서 정상 재생·자연 종료했다.
`NXPlayStream` 경로는 선택하지 않는다. SoundKit의 이 API가 독립적인 hardware
underrun counter를 제공하지 않으므로 callback count/bytes/time progress,
`SNDStartPlaying`/`SNDWait` 오류와 실제 청취를 측정 근거로 삼았다. 300초 동안
청감상 끊김과 queue API 오류가 없었다. 지원 포맷은 22050/44100 Hz, mono/stereo,
signed 16-bit PCM으로 명시한다.

### Phase 5 — timer + threads (완료)

- `SDL_GetTicks`, `SDL_Delay`, timer callback 등록/해제를 구현하고 1 ms 요구를
허위로 보장하지 않는다. 실측 분해능과 drift를 공개한다.
- `SDL_CreateThread`, semaphore, mutex, condition을 cthreads로 구현한다. SDL 1.2
  공개 thread API에는 TLS가 없으므로 별도 비공개 TLS 확장은 범위에 넣지 않는다.
- lock contention, condition signal/broadcast/timeout, semaphore, worker join을 검증한 뒤
  `SDL_Quit`/`SDL_Init(SDL_INIT_TIMER)` lifecycle을 3회 반복한다. SDL 원본도
  안전성을 보장하지 않는 live worker와 `SDL_Quit`의 중첩은 범위 밖이다.

**GO 결과:** 타이머 wraparound 포함 단위 시험과 thread stress test를
실기에서 통과했다.

**실기 결과 (2026-08-11):** callback/delay, `gettimeofday` 역행 clamp,
약 49일 `Uint32` wrap 산술을 각각 통과했다. condition signal/timeout/broadcast,
4-worker mutex contention, semaphore, join과 3회 SDL lifecycle도 통과했다.

### Phase 6 — SDL 1.2 호환성, 예제, 배포 (완료)

- SDL 표준 test 프로그램 중 이식 가능한 것을 빌드하고, 외부 SDL 1.2 앱 두 개 이상을
  포팅 없이 또는 최소 makefile 변경만으로 실행한다.
- 지원 API/flag/제한, 알려진 문제, 실기 명령과 결과를 `TESTING.md`와 README에 정리한다.
- SDL 원본 diff를 작은 논리 단위 patch로 유지하고, COPYING/NOTICE/소스 재현 절차를
  포함한다.
- 최종 패키지와 깨끗한 NFS 경로 빌드를 검증한다.

**최종 결과:** 원본 SDL 1.2.15 `test/testwm.c`, `test/loopwave.c`,
`test/testbitmap.c`, `test/graywin.c`를 source 수정 없이 OPENSTEP에서
빌드·실행했다. `testwm`은
8bpp palette, 창 생성 전
`SDL_WM_SetCaption`/GetCaption, mouse, Escape key, event filter,
`SDL_USEREVENT`, `SDL_WaitEvent` 종료 경로를 GUI 실기에서 통과했다.
`loopwave`는 `SDL_LoadWAV` → `SDL_OpenAudio` → callback loop → SIGINT close를
native `openstep` audio driver로 통과했다. `testbitmap`은 1-bit XBM→8bpp screen
blit와 dirty update, mouse 위치를 통과했다. 별도 AppKit backing probe로
`NSBitmapImageRep`가 bottom-up임을 실측해 SDL top-down source row를 presenter에서
반전했다. `graywin`은 partial update 유지, expose 구분, 사용자 close/SDL shutdown
수명 관리와 native `NSCursor`를 통과했다. AppKit/DPS bitmap presenter의 행 반전은
cursor image에는 적용하지 않는 것도 실기로 확인했다. `testwm`으로 발견한
pre-video-mode caption 보존과 ASCII Escape 변환 누락도 backend에서 수정했다.
추가 원본 video/input 사례는 X11·OpenGL·별도 asset 의존이 없는
`testcursor.c`를 선택했다. 외부 core-SDL 프로그램
`stars-1.0`, `xflame-1.0`을 수정 없이 최종 acceptance 대상으로 선택했다.
`plasma-1.0`도 대상 컴파일했지만 원본 loop가 정상적인 최초 expose를 포함한 아무
event에서 종료하므로 runtime acceptance에는 쓰지 않는다. `SDL_RESIZABLE`, native
cursor 표시/숨김, DPS warp와 `displayRect:` dirty clipping도 구현·대상 빌드와
최종 WindowServer 묶음의 화면 동작을 통과했다. fullscreen과 cursor
grab/relative mode는 지원하지 않는 capability로 문서화한다.

## 5. 최종 디렉터리 구성

```
openstep-sdl12/
├─ README.md                 프로젝트 범위와 사용법
├─ PLAN_SDL12.md             이 계획
├─ TESTING.md                실기 검증 명령·결과·제한
├─ COPYING / NOTICE           SDL 라이선스·고지
├─ upstream/                 검증된 pristine SDL 1.2 원본 (버전 기록 포함)
├─ port/openstep/            pristine tree에 overlay하는 포트 소스·config·patch
├─ build/                    staging/build/test script와 subtype 보정 helper
├─ spikes/                   API 검증용 독립 프로그램
├─ notes/                    SDK 인벤토리·측정·최종 검증 기록
├─ test/openstep/            포트 전용 회귀 검사
├─ external/                 고정 출처의 외부 core-SDL acceptance 프로그램
├─ assets/                   배포에서 제외되는 로컬 오디오 실험 자산
└─ dist/                     재현 가능한 source archive와 SHA-256 sidecar
```

`upstream/SDL-1.2.15/`는 수정하지 않는다. `prepare-openstep-tree.csh`가
`port/openstep/`의 config, backend source, 최소 core patch를 disposable
`/tmp/SDL12/build/SDL-1.2.15-openstep/`에 overlay한다. 이 구조로 pristine source와
포트 차이를 분리하고, root-squash NFS에 write하지 않는다.

## 6. 위험 요소와 최종 대응

| 위험 | 영향 | 최종 대응/판정 |
|---|---|---|
| AppKit event loop를 SDL이 잘못 소유 | repaint·입력 멈춤 | `SDL_PumpEvents` non-blocking pump와 `SDL_WaitEvent` 실기를 모두 통과 |
| DPS와 SDL surface 포맷이 불일치 | 색상·좌표·cursor 오류 | bottom-up bitmap backing을 presenter에서만 반전; cursor image는 무변환. 8/16/24/32bpp 통과 |
| fullscreen/grab이 AppKit 정책상 제한 | 일부 게임 호환성 저하 | 창 software surface만 지원; fullscreen/OpenGL/grab/relative mode를 명시적 제한으로 문서화 |
| Sound Driver stream의 byte order/buffer 재사용 | 잡음·끊김 | `NXPlayStream`을 제외하고 native `SNDStartPlaying` FCFS queue로 300초 audio/AV 통과 |
| 구형 cc/autoconf 호환성 | SDL 빌드 중단 | GCC 2.7/C89 overlay makefile과 i486 Mach-O subtype post-link 보정을 고정 |
| cthreads 의미가 SDL 기대와 다름 | race/deadlock | generic semaphore handshake condition을 사용하고 timeout/broadcast/contention/lifecycle 통과 |
| 단일 프로세스 AppKit 결합 | SDL 임베드 앱 제약 | 현재 지원 범위를 독립 SDL application으로 한정; 기존 AppKit app embedding은 미검증 |

## 7. 완료된 착수 순서 (역사 기록)

1. `appkit-window`와 `bitmap-presenter`로 AppKit run loop, event, DPS bitmap
   backing row를 먼저 확정했다.
2. SDL overlay를 disposable tree에 적용하고 `sdl-video-events`, timer,
   cthreads, SoundKit 전용 회귀 프로그램으로 API 선택 근거를 남겼다.
3. 원본 SDL test와 외부 core-SDL 프로그램을 source 수정 없이 빌드해
   포트 전용 harness 밖의 호환성을 확인했다.
4. 최종 7단계 WindowServer sequence와 300초 audio/AV stress를 통과한 뒤
   source archive를 재현 가능하게 생성했다.

이 순서는 화면 표시와 AppKit event loop를 먼저 확정한 뒤 오디오/스레드를
독립 계측하는 방식으로 진행됐다. 당시 계획한 일부 별도 스파이크는
더 직접적인 `test/openstep/` regression으로 대체됐다.
