# SDL 1.2.15 원본 취득 기록

이 디렉터리의 `SDL-1.2.15/`는 포팅 전의 upstream pristine source tree다.
포트 수정은 이 tree에 직접 섞어 관리하지 않는다. 새 backend source는
`port/openstep/` overlay에, upstream bootstrap 삽입 diff는
`port/openstep/patches/`에 기록한다.

| 항목 | 값 |
|---|---|
| 프로젝트 | Simple DirectMedia Layer (SDL) |
| 버전 | 1.2.15 (SDL 1.2 최종 릴리스) |
| 취득일 | 2026-08-10 |
| 공식 배포 URL | `https://www.libsdl.org/release/SDL-1.2.15.tar.gz` |
| 아카이브 SHA-256 | `d6d316a793e5e348155f0dd93b979798933fb98aa1edebcc108829d6474aad00` |
| 아카이브 최상위 디렉터리 | `SDL-1.2.15/` |
| 라이선스 | GNU LGPL 2.1 (`SDL-1.2.15/COPYING`) |

검증 명령:

```sh
sha256sum SDL-1.2.15.tar.gz
tar -tzf SDL-1.2.15.tar.gz | head
```

원본 tarball은 저장소에 중복 보관하지 않는다. 위 URL, SHA-256 및 top-level
디렉터리 이름으로 동일한 pristine tree를 재생성할 수 있다.
