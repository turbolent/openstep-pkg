/* Replacement strnlen for hosts that lack it. */

#include <config.h>

#include <string.h>

size_t
rpl_strnlen (const char *s, size_t maxlen)
{
  const void *end = memchr (s, '\0', maxlen);
  return end ? (size_t) ((const char *) end - s) : maxlen;
}
